# Standalone PTAB extractor

A single-file, dependency-light port of this platform's PTAB (USPTO Patent Trial &
Appeal Board) data pipeline. **No Django, no database.** Copy `ptab_extractor.py` into
any project and use it as a module or a CLI.

## What it does

- **ODP client** — authenticated (`x-api-key`) HTTP client for the USPTO Open Data Portal,
  with 429 exponential backoff and a 30s timeout.
- **Proceeding search / detail** — search PTAB proceedings and fetch a single proceeding,
  including `flatten_proceeding()` which maps the nested ODP response to the flat field set
  the platform UI renders.
- **Documents / decisions** — list a trial's documents and fetch its decisions.
- **Counsel resolution** — downloads a trial's filed PDFs (Power of Attorney, Mandatory
  Notices, Petition §42.8 block, signature blocks, certificates of service, pro-hac motions),
  runs `pdftotext -layout`, and parses the real attorney roster (name / reg# / firm / email /
  phone) with four layout-specific parsers, then merges + dedupes across documents.

## Not included (by design)

The original platform links extracted attorneys to a ~53K-row USPTO practitioner table in
its database. This standalone version emits **raw parsed counsel** only — no roster lookup —
so it is portable. If your other project has a practitioner DB, match on
`registration_number` (or first/last name for pro-hac entries with no reg#) on your side.

## Setup

```bash
pip install -r requirements.txt          # just `requests`
# PDF text extraction needs poppler's pdftotext on PATH (recommended):
#   Debian/Ubuntu:  sudo apt install poppler-utils
#   macOS:          brew install poppler
# ...or `pip install pdfplumber` as a slower pure-Python fallback.

export USPTO_ODP_API_KEY=your_key_here   # get one at https://data.uspto.gov
```

## CLI

```bash
python ptab_extractor.py get       IPR2026-00341      # flattened + raw proceeding
python ptab_extractor.py get       IPR2026-00341 --raw
python ptab_extractor.py documents IPR2026-00341
python ptab_extractor.py decisions IPR2026-00341
python ptab_extractor.py counsel   IPR2026-00341      # roster from PDFs
python ptab_extractor.py search --patent 10000000 --type IPR --limit 20
python ptab_extractor.py search --query 'trialMetaData.petitionFilingDate:[2025-01-01 TO *]'
```

All commands print JSON to stdout. Add `-v` for debug logging on stderr.

## Desktop UI (Tkinter — stdlib, no pip)

A native GUI (`ptab_gui.py`) wraps the extractor. Four tabs:

- **Lookup by trial #** — Proceeding / Documents / Decisions / Counsel. Every result area
  toggles **Structured table ⇄ Raw JSON**, sorts on any column header (click), and supports
  right-click copy (cell / row / TSV). Double-click a document, decision, or counsel row (or
  select it and **Open PDF**) to download and open the source PDF.
- **Search proceedings** — filter by type, status, patent #, **petitioner / patent-owner
  names**, application #, and petition **filed-after / filed-before** dates; choose sort field
  & order. **◀ Prev / Next ▶** paginate; **Export CSV / JSON** with an optional *Include applied
  filters* toggle. Double-click a result to open it in the Lookup tab.
- **Litigation** — district-court & appellate patent cases from **CourtListener / RECAP**
  (free court data; USPTO ODP has none). Filter by source (District Court / Federal Circuit /
  Supreme Court / Federal Claims), case #, court id, cause of action (nature-of-suit 830 =
  Patent), plaintiff/defendant, judge, and filed-after/before dates. Table shows Case, Filed,
  Status, Court, Plaintiff, Defendant, Cause of Action, and Judge. **Pick…** chooses a court by
  name (from the `courts/` endpoint) instead of typing an id. **Double-click a case** for a
  details dialog with *accurate parties typed by side* (from `parties/`) and the resolved judge
  (from `people/`) — those two lookups need a token; without one it falls back to case-name
  parsing. Needs a free CourtListener token (Settings) for full function. Note: the columns
  **Plaintiff Entity Type, Industry, NPE Aggregator, Third-Party Financing** are proprietary
  (Unified Patents / Lex Machina) — no free API has them, so they stay blank. CourtListener
  is slow (~20–30s per query); the spinner shows progress.
- **Bulk names** — both the Search-proceedings and Litigation tabs have a **Bulk names…** button
  that opens a dialog: paste names and/or **Load file…** (.txt one-per-line, or .csv first column),
  choose **which party** each name is (PTAB: Petitioner / Patent owner; Litigation: Plaintiff /
  Defendant / Either), then Start. Names are deduped and processed **one at a time** with a live
  status row each (Queued → Searching… → ✓ N matches / — no match / ✗ error) and an overall N/N
  counter; **Stop** anytime. Double-click a name to view its matched cases. **Export** in three
  selectable modes: per-name with all matches, summary (name→count), or matched-names-only.
  (Litigation bulk is paced for the CourtListener rate limit and warns before large batches.)
- **Logs** — live log view (level filter, autoscroll, clear, open log file/folder). Everything
  is also written to a rotating **`ptab_gui.log`** (1 MB × 5 backups) next to the script.
- **Settings** — ODP API key & base URL, request tuning (timeout / retries / backoff), default
  sort/limit, and PDF-open behavior. Non-secret settings persist to **`ptab_gui_config.json`**;
  the **API key is never written to disk** (env var or per-session entry only).

Every ODP call runs on a background thread with an animated status spinner, so the window
never freezes.

```bash
python ptab_gui.py
```

The `tkinter` module is part of the Python stdlib, but on Linux the underlying Tk libraries
are a separate OS package:

```bash
sudo apt install python3-tk        # Debian/Ubuntu
sudo dnf install python3-tkinter   # Fedora
```

(Windows and macOS python.org builds already bundle Tk.) The ODP API key defaults from
`USPTO_ODP_API_KEY`, and the litigation token from `COURTLISTENER_API_TOKEN`; both can also
be typed into the Settings tab (neither is written to disk).

### Litigation data sources
The Litigation tab pulls live from **CourtListener / RECAP** (Free Law Project) — the one
free, documented API mirroring PACER, at `https://www.courtlistener.com/api/rest/v4/search/?type=r`
(free token from your CourtListener profile; rate-limited ~5/min, 50/hr, 125/day). Other
sources of the same data, for reference: PACER (authoritative but paid-per-page, no clean JSON
API), Unified Patents Portal (free web UI with proprietary NPE/industry enrichment but no
public API), and paid analytics services (Lex Machina, Docket Navigator, RPX, Docket Alarm).
A file-import path for such exports could be added later. Also usable standalone:

```bash
export COURTLISTENER_API_TOKEN=xxxxx
python litigation.py search --court txed --cause 830 --filed-after 2026-06-01
python litigation.py search --plaintiff "UpChat" --filed-after 2026-01-01 --summary
```

`ptab_gui.log` and `ptab_gui_config.json` are written to the script's folder (falling back to
the temp dir if it's read-only).

### Possible future enhancements (not yet built)
Cancel in-flight requests; keyboard shortcuts; dedicated decisions/appeals/interferences/
petitions **search** tabs (need new client query-builders); a live "rate-limited, retrying…"
status during 429 backoff; determinate per-document progress during counsel extraction.

## As a module

```python
from ptab_extractor import OdpClient, TrialService, flatten_proceeding, resolve_counsel

svc = TrialService(OdpClient(api_key="..."))       # or rely on USPTO_ODP_API_KEY

proc = svc.get_proceeding("IPR2026-00341")
fields = flatten_proceeding(proc)                  # flat dict the UI shows

counsel = resolve_counsel("IPR2026-00341", svc)    # list of counsel dicts
for c in counsel:
    print(c["side"], c["role"], c["name"], c["registration_number"], c["firm_name"])
```

## Notes

- Requires **Python 3.10+** (uses `X | None` / `list[str]` type syntax).
- ODP returns HTTP 404 for "no matching records" — the client returns `None` in that case.
- Counsel extraction is uncached and re-parses on every call, matching the platform's
  behavior (new attorney designations get filed as a case progresses).
- The structured ODP `counselName` field is unreliable, which is why counsel is parsed from
  the PDFs rather than read from the API response.
