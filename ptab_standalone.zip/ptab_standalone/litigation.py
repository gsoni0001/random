"""
Standalone patent-litigation extractor (district court, appeals, etc.).

Source: CourtListener / RECAP (Free Law Project) — the free, documented API that mirrors
PACER. USPTO ODP does NOT carry district-court litigation, so this is a separate client
from ptab_extractor.

Provides:
  * CourtListenerClient  — HTTP client (Token auth, 429 backoff, 30s timeout)
  * search_cases()       — RECAP docket search (type=r)
  * build_case_query()   — simple params -> CourtListener search query
  * summarize_case()     — one search record -> the flat columns a case table shows
  * extract_cases()      — pull the results list from a response

Auth: a free CourtListener API token (Authorization: Token <token>). Get one at
https://www.courtlistener.com/profile/ and set COURTLISTENER_API_TOKEN, or pass api_token=.

NOTE on columns: CourtListener supplies Case, Filing Date, Status, Court, parties, Cause of
Action (nature of suit) and Judge. Proprietary enrichment columns shown by commercial tools
(Plaintiff Entity Type, Industry, NPE Aggregator, Third-Party Financing) are NOT available
from any free API and come back blank.

CLI:
    export COURTLISTENER_API_TOKEN=xxxxx
    python litigation.py search --cause 830 --court txed --filed-after 2026-06-01 --limit 20
    python litigation.py search --plaintiff "UpChat" --filed-after 2026-01-01
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
import time
from typing import Any, Optional

import requests

logger = logging.getLogger("litigation")

DEFAULT_BASE_URL = "https://www.courtlistener.com/api/rest/v4"
PATENT_NATURE_OF_SUIT = "830"  # federal nature-of-suit code for Patent

# The user-facing "Source" groups map to CourtListener court ids (District Court = no court
# filter; patent NOS 830 is inherently district court). ITC 337 investigations are not in
# CourtListener.
SOURCE_COURT_IDS = {
    "District Court": "",        # no court filter — rely on nature of suit
    "Federal Circuit": "cafc",
    "Supreme Court": "scotus",
    "Federal Claims": "uscfc",
    "International Trade Commission": "",  # not covered by CourtListener
}
SOURCES = tuple(SOURCE_COURT_IDS.keys())

# A few common district court ids, for the Court filter hint.
COMMON_COURT_IDS = ("txed", "txwd", "ded", "njd", "cand", "cacd", "ilnd", "nysd", "vaed", "cafc")


class LitigationError(Exception):
    """Base exception for CourtListener API errors."""


class CourtListenerClient:
    """HTTP client for the CourtListener v4 REST API.

    - Token authentication (Authorization: Token <token>)
    - Exponential backoff on 429 (the Search API is rate-limited: ~5/min, 50/hr, 125/day)
    - 30s timeout
    """

    MAX_RETRIES = 3
    BACKOFF_BASE = 2
    TIMEOUT = 60  # CourtListener search is slow (often 20–30s per query)

    def __init__(self, api_token: str = "", base_url: str = "",
                 timeout: Optional[int] = None, max_retries: Optional[int] = None,
                 backoff_base: Optional[float] = None):
        self.api_token = api_token or os.environ.get("COURTLISTENER_API_TOKEN", "")
        self.base_url = base_url or os.environ.get("COURTLISTENER_BASE_URL", DEFAULT_BASE_URL)
        if timeout is not None:
            self.TIMEOUT = timeout
        if max_retries is not None:
            self.MAX_RETRIES = max_retries
        if backoff_base is not None:
            self.BACKOFF_BASE = backoff_base

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if self.api_token:
            headers["Authorization"] = f"Token {self.api_token}"
        return headers

    def get(self, path: str, params: Optional[dict] = None) -> Any:
        return self.get_url(f"{self.base_url}{path}", params=params)

    def get_url(self, url: str, params: Optional[dict] = None) -> Any:
        """GET an absolute URL (used to follow cursor-based next/previous pagination links)."""
        last_exc = None
        for attempt in range(self.MAX_RETRIES + 1):
            try:
                resp = requests.get(url, headers=self._headers(), params=params, timeout=self.TIMEOUT)
                if resp.status_code == 429:
                    last_exc = LitigationError("rate limited")
                    if attempt < self.MAX_RETRIES:  # don't sleep after the final attempt
                        wait = self.BACKOFF_BASE * (2 ** attempt)
                        logger.warning("CourtListener 429 rate-limited, retrying in %ds", wait)
                        time.sleep(wait)
                    continue
                if resp.status_code == 404:
                    return None
                resp.raise_for_status()
                return resp.json()
            except requests.exceptions.HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 429:
                    last_exc = exc
                    if attempt < self.MAX_RETRIES:
                        time.sleep(self.BACKOFF_BASE * (2 ** attempt))
                    continue
                logger.error("CourtListener HTTP error: %s", exc)
                raise LitigationError(f"CourtListener API error: {exc}") from exc
            except requests.exceptions.RequestException as exc:
                logger.error("CourtListener request failed: %s", exc)
                raise LitigationError(f"CourtListener request failed: {exc}") from exc
        raise LitigationError(f"CourtListener failed after {self.MAX_RETRIES} retries: {last_exc}")


def _q_term(field: str, value: str) -> str:
    """Fielded search term; multi-word values are phrase-quoted."""
    value = (value or "").strip()
    if not value:
        return ""
    return f'{field}:"{value}"' if " " in value else f"{field}:{value}"


def build_case_query(
    *,
    source: str = "District Court",
    case_number: str = "",
    court: str = "",
    cause_of_action: str = PATENT_NATURE_OF_SUIT,
    plaintiff: str = "",
    defendant: str = "",
    judge: str = "",
    search: str = "",
    filed_after: str = "",
    filed_before: str = "",
    order_by: str = "dateFiled desc",
    page_size: int = 20,  # accepted for CLI compat; CourtListener search is fixed at 20/page
) -> dict:
    """Build a CourtListener RECAP (type=r) search query from simple params.

    Court, date and nature-of-suit are dedicated GET params (verified against the live API);
    free-text and remaining fielded criteria are AND-ed into `q`. A numeric `cause_of_action`
    is treated as a nature-of-suit code (830 = Patent) and only applied to district-court
    searches — appellate dockets (CAFC, SCOTUS, Fed. Claims) carry no NOS code.
    """
    params: dict[str, Any] = {"type": "r", "order_by": order_by or "dateFiled desc"}

    court_id = court.strip() or SOURCE_COURT_IDS.get(source, "")
    if court_id:
        params["court"] = court_id
    if filed_after.strip():
        params["filed_after"] = filed_after.strip()
    if filed_before.strip():
        params["filed_before"] = filed_before.strip()

    coa = (cause_of_action or "").strip()
    q_parts = []
    if search.strip():
        q_parts.append(search.strip())
    if case_number.strip():
        q_parts.append(_q_term("docketNumber", case_number.strip()))
    if coa.isdigit():
        # NOS is a district-court concept; don't zero out appellate searches with it.
        if source == "District Court":
            params["nature_of_suit"] = coa
    elif coa:
        q_parts.append(_q_term("cause", coa))
    # CourtListener search can't distinguish plaintiff vs defendant side in the query, so both
    # narrow on party name.
    if plaintiff.strip():
        q_parts.append(_q_term("party", plaintiff.strip()))
    if defendant.strip():
        q_parts.append(_q_term("party", defendant.strip()))
    if judge.strip():
        q_parts.append(_q_term("assignedTo", judge.strip()))
    if q_parts:
        params["q"] = " AND ".join(q_parts)
    return params


def extract_cases(resp: Optional[dict]) -> list[dict]:
    """Pull the list of case records from a search response."""
    if not isinstance(resp, dict):
        return []
    results = resp.get("results")
    return results if isinstance(results, list) else []


_VS_RE = re.compile(r"\s+v\.?s?\.?\s+", re.I)  # " v. " / " v " / " vs. "


def _first(record: dict, *keys) -> Any:
    for k in keys:
        if record.get(k):
            return record[k]
    return ""


def _split_parties(case_name: str) -> tuple[str, str]:
    """Best-effort plaintiff/defendant from a 'X v. Y' case name (CourtListener search results
    don't type parties by side)."""
    if not case_name:
        return "", ""
    parts = _VS_RE.split(case_name, maxsplit=1)
    if len(parts) == 2:
        return parts[0].strip(), parts[1].strip()
    return case_name.strip(), ""


def summarize_case(record: dict) -> dict:
    """Flatten one CourtListener RECAP record to the columns a case table shows. The four
    proprietary columns are always blank (not available from a free source)."""
    record = record or {}
    case_name = str(_first(record, "caseName", "caseNameFull", "case_name") or "")
    plaintiff, defendant = _split_parties(case_name)
    terminated = _first(record, "dateTerminated", "date_terminated")
    return {
        "case_number": str(_first(record, "docketNumber", "docket_number") or ""),
        "filing_date": str(_first(record, "dateFiled", "date_filed") or "")[:10],
        "status": "Closed" if terminated else "Open",
        "court": str(_first(record, "court", "court_id", "court_exact") or ""),
        "plaintiff": plaintiff,
        "defendant": defendant,
        "cause_of_action": str(_first(record, "suitNature", "natureOfSuit", "cause") or ""),
        "judge": str(_first(record, "assignedTo", "assigned_to_str", "referredTo") or ""),
        "case_name": case_name,
        "docket_id": _first(record, "docket_id", "id") or "",
        "assigned_to_id": record.get("assigned_to_id") or "",
        "docket_url": str(_first(record, "docket_absolute_url", "absolute_url") or ""),
        # Proprietary — not available from CourtListener.
        "plaintiff_entity_type": "",
        "industry": "",
        "npe_aggregator": "",
        "third_party_financing": "",
    }


def search_cases(query: dict, client: Optional[CourtListenerClient] = None) -> Optional[dict]:
    """Run a RECAP docket search. `query` is a params dict (see build_case_query)."""
    client = client or CourtListenerClient()
    return client.get("/search/", params=query)


def strip_nested_documents(resp: Optional[dict]) -> Optional[dict]:
    """Drop the heavy nested `recap_documents` from each search result. The /search/ endpoint
    ignores server-side field selection, so this only lightens the payload we hold / export —
    it does not speed the query itself."""
    if isinstance(resp, dict):
        for r in resp.get("results") or []:
            if isinstance(r, dict):
                r.pop("recap_documents", None)
    return resp


# Court jurisdiction codes worth offering in a picker: Federal District, Federal Appellate,
# Federal Special (Court of Federal Claims lives here).
COURT_JURISDICTIONS = ("FD", "F", "FS")


def list_courts(client: Optional[CourtListenerClient] = None,
                jurisdictions=COURT_JURISDICTIONS, only_in_use: bool = True,
                max_pages: int = 30) -> list[dict]:
    """Fetch selectable courts (id + full_name) for a picker. Anonymous access is allowed.
    Deduped by id and sorted by name."""
    client = client or CourtListenerClient()
    out: list[dict] = []
    seen: set[str] = set()
    for jur in jurisdictions:
        url: Optional[str] = f"{client.base_url}/courts/"
        params: Optional[dict] = {"jurisdiction": jur, "page_size": 100}
        pages = 0
        while url and pages < max_pages:
            resp = client.get_url(url, params=params)
            params = None  # `next` already carries the querystring
            if not resp:
                break
            for c in resp.get("results") or []:
                cid = c.get("id")
                if not cid or cid in seen:
                    continue
                if only_in_use and not c.get("in_use"):
                    continue
                seen.add(cid)
                out.append({"id": cid,
                            "full_name": c.get("full_name") or c.get("short_name") or cid,
                            "jurisdiction": c.get("jurisdiction")})
            url = resp.get("next")
            pages += 1
    out.sort(key=lambda c: c["full_name"])
    return out


def get_parties(client: Optional[CourtListenerClient], docket_id, max_pages: int = 10) -> dict:
    """Fetch a docket's parties grouped by side. Requires a token (the /parties/ endpoint is
    not open). Returns {'Plaintiff': [...], 'Defendant': [...], 'Other': [...]}."""
    client = client or CourtListenerClient()
    groups: dict[str, list[str]] = {"Plaintiff": [], "Defendant": [], "Other": []}
    url: Optional[str] = f"{client.base_url}/parties/"
    params: Optional[dict] = {"docket": docket_id, "page_size": 100}
    pages = 0
    while url and pages < max_pages:
        resp = client.get_url(url, params=params)
        params = None
        if not resp:
            break
        for p in resp.get("results") or []:
            name = (p.get("name") or "").strip()
            if not name:
                continue
            types = " ".join((pt.get("name") or "") for pt in (p.get("party_types") or [])).lower()
            bucket = ("Plaintiff" if "plaintiff" in types
                      else "Defendant" if "defendant" in types else "Other")
            groups[bucket].append(name)
        url = resp.get("next")
        pages += 1
    return groups


def get_judge(client: Optional[CourtListenerClient], person_id) -> str:
    """Resolve an assigned-judge person id to a full name (requires a token)."""
    if not person_id:
        return ""
    client = client or CourtListenerClient()
    resp = client.get(f"/people/{person_id}/")
    if not isinstance(resp, dict):
        return ""
    parts = [resp.get("name_first"), resp.get("name_middle"), resp.get("name_last")]
    name = " ".join(p for p in parts if p)
    suffix = resp.get("name_suffix")
    return f"{name} {suffix}".strip() if suffix else name.strip()


# =============================================================================
# CLI
# =============================================================================
def _emit(obj: Any) -> None:
    json.dump(obj, sys.stdout, indent=2, ensure_ascii=False)
    sys.stdout.write("\n")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Standalone patent-litigation search (CourtListener/RECAP).")
    parser.add_argument("--token", default="", help="CourtListener API token (else COURTLISTENER_API_TOKEN)")
    parser.add_argument("--base-url", default="", help="API base URL (else COURTLISTENER_BASE_URL)")
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)

    ps = sub.add_parser("search", help="search patent-litigation cases")
    ps.add_argument("--source", default="District Court", choices=list(SOURCES))
    ps.add_argument("--case", dest="case_number", default="", help="docket number, e.g. 2:26-cv-00508")
    ps.add_argument("--court", default="", help="court id, e.g. txed / ded / cafc")
    ps.add_argument("--cause", default=PATENT_NATURE_OF_SUIT, help="nature-of-suit code (830) or cause text")
    ps.add_argument("--plaintiff", default="")
    ps.add_argument("--defendant", default="")
    ps.add_argument("--judge", default="")
    ps.add_argument("--search", default="", help="free-text query")
    ps.add_argument("--filed-after", default="", help="YYYY-MM-DD")
    ps.add_argument("--filed-before", default="", help="YYYY-MM-DD")
    ps.add_argument("--order", default="dateFiled desc", help="order_by (e.g. 'dateFiled desc')")
    ps.add_argument("--limit", type=int, default=20, help="page size")
    ps.add_argument("--summary", action="store_true", help="emit flattened rows instead of raw response")

    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING,
                        format="%(levelname)s %(name)s: %(message)s", stream=sys.stderr)

    client = CourtListenerClient(api_token=args.token, base_url=args.base_url)
    if not client.api_token:
        sys.stderr.write("warning: no API token (pass --token or COURTLISTENER_API_TOKEN)\n")

    if args.command == "search":
        query = build_case_query(
            source=args.source, case_number=args.case_number, court=args.court,
            cause_of_action=args.cause, plaintiff=args.plaintiff, defendant=args.defendant,
            judge=args.judge, search=args.search, filed_after=args.filed_after,
            filed_before=args.filed_before, order_by=args.order, page_size=args.limit,
        )
        try:
            resp = search_cases(query, client)
        except LitigationError as exc:
            sys.stderr.write(f"error: {exc}\n")
            return 1
        if args.summary:
            _emit([summarize_case(r) for r in extract_cases(resp)])
        else:
            _emit(resp)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
