"""
Standalone PTAB (USPTO Patent Trial & Appeal Board) data extractor.

Self-contained port of the patent-analytics-platform PTAB pipeline — NO Django, NO
database. Talks directly to the USPTO Open Data Portal (ODP) API and extracts counsel
from case PDFs.

Provides:
  * OdpClient            — HTTP client (x-api-key auth, 429 backoff, 30s timeout)
  * TrialService         — thin wrappers over the ODP PTAB trial endpoints
  * flatten_proceeding() — nested ODP proceeding response -> flat field dict (as the UI shows)
  * resolve_counsel()    — download a trial's PDFs, run pdftotext, parse attorney rosters
                           (name / reg# / firm / email / phone) with 4 layout parsers + merge

Usage as a module:
    from ptab_extractor import OdpClient, TrialService, flatten_proceeding, resolve_counsel

    svc = TrialService(OdpClient(api_key="..."))          # or set USPTO_ODP_API_KEY
    proc = svc.get_proceeding("IPR2026-00341")
    print(flatten_proceeding(proc))
    print(resolve_counsel("IPR2026-00341", svc))

Usage as a CLI:
    export USPTO_ODP_API_KEY=xxxxx
    python ptab_extractor.py get       IPR2026-00341
    python ptab_extractor.py documents IPR2026-00341
    python ptab_extractor.py decisions IPR2026-00341
    python ptab_extractor.py counsel   IPR2026-00341
    python ptab_extractor.py search --patent 10000000 --type IPR --limit 20
    python ptab_extractor.py search --query 'trialMetaData.petitionFilingDate:[2025-01-01 TO *]'

Requirements: Python 3.10+, `requests`. PDF text needs `pdftotext` (poppler-utils) on PATH,
or `pdfplumber` installed as a fallback. Counsel extraction is a no-op without one of them.

Roster linking (matching extracted attorneys to a practitioner database) is intentionally
NOT included — this emits raw parsed counsel, portable to any project.
"""

from __future__ import annotations

import argparse
import io
import json
import logging
import os
import re
import subprocess
import sys
import time
from datetime import date
from typing import Any, Callable, Optional

import requests

logger = logging.getLogger("ptab_extractor")

DEFAULT_BASE_URL = "https://api.uspto.gov/api/v1"


# =============================================================================
# ODP HTTP client
# =============================================================================
class OdpError(Exception):
    """Base exception for ODP API errors."""


class OdpClient:
    """
    Reusable HTTP client for the USPTO Open Data Portal API.

    - x-api-key authentication (from arg or USPTO_ODP_API_KEY env var)
    - Exponential backoff on 429 (rate limit)
    - 30s timeout
    - ODP returns 404 for "no matching records" -> treated as None
    """

    MAX_RETRIES = 3
    BACKOFF_BASE = 2  # seconds
    TIMEOUT = 30

    def __init__(self, api_key: str = "", base_url: str = "",
                 timeout: Optional[int] = None, max_retries: Optional[int] = None,
                 backoff_base: Optional[float] = None):
        self.api_key = api_key or os.environ.get("USPTO_ODP_API_KEY", "")
        self.base_url = base_url or os.environ.get("USPTO_ODP_BASE_URL", DEFAULT_BASE_URL)
        # Optional per-instance overrides shadow the class defaults (read by _request unchanged).
        if timeout is not None:
            self.TIMEOUT = timeout
        if max_retries is not None:
            self.MAX_RETRIES = max_retries
        if backoff_base is not None:
            self.BACKOFF_BASE = backoff_base

    def _headers(self, include_content_type: bool = False) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if include_content_type:
            headers["Content-Type"] = "application/json"
        if self.api_key:
            headers["x-api-key"] = self.api_key
        return headers

    def get(self, path: str, params: Optional[dict] = None) -> Any:
        return self._request("GET", f"{self.base_url}{path}", params=params)

    def post(self, path: str, body: Optional[dict] = None) -> Any:
        return self._request("POST", f"{self.base_url}{path}", json_body=body)

    def _request(
        self,
        method: str,
        url: str,
        params: Optional[dict] = None,
        json_body: Optional[dict] = None,
    ) -> Any:
        last_exc = None
        for attempt in range(self.MAX_RETRIES + 1):
            try:
                logger.debug("ODP %s %s attempt=%d", method, url, attempt)
                resp = requests.request(
                    method,
                    url,
                    headers=self._headers(include_content_type=method not in ("GET", "HEAD", "DELETE")),
                    params=params,
                    json=json_body,
                    timeout=self.TIMEOUT,
                )
                if resp.status_code == 429:
                    last_exc = OdpError("rate limited")
                    if attempt < self.MAX_RETRIES:  # don't sleep after the final attempt
                        wait = self.BACKOFF_BASE * (2 ** attempt)
                        logger.warning("ODP 429 rate-limited, retrying in %ds", wait)
                        time.sleep(wait)
                    continue
                # ODP returns 404 for "no matching records" — treat as empty
                if resp.status_code == 404:
                    logger.debug("ODP 404 — no matching records for %s", url)
                    return None
                resp.raise_for_status()
                return resp.json()
            except requests.exceptions.HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 429:
                    last_exc = exc
                    if attempt < self.MAX_RETRIES:
                        logger.warning("ODP 429 rate-limited, retrying")
                        time.sleep(self.BACKOFF_BASE * (2 ** attempt))
                    continue
                logger.error("ODP HTTP error: %s", exc)
                raise OdpError(f"ODP API error: {exc}") from exc
            except requests.exceptions.RequestException as exc:
                logger.error("ODP request failed: %s", exc)
                raise OdpError(f"ODP request failed: {exc}") from exc
        raise OdpError(f"ODP API failed after {self.MAX_RETRIES} retries: {last_exc}")


# =============================================================================
# Trial service — PTAB endpoints
# =============================================================================
class TrialService:
    """Wrappers over the ODP PTAB trial endpoints (proceedings, decisions, documents)."""

    def __init__(self, client: Optional[OdpClient] = None):
        self.client = client or OdpClient()

    # -- Proceedings --
    def search_proceedings(self, query: dict) -> dict:
        return self.client.post("/patent/trials/proceedings/search", query)

    def get_proceeding(self, trial_number: str) -> Optional[dict]:
        """Fetch a single proceeding, unwrapping ODP's patentTrialProceedingDataBag[0]
        (the shape the UI consumes)."""
        data = self.client.get(f"/patent/trials/proceedings/{trial_number}")
        return _unwrap(data, "patentTrialProceedingDataBag")

    # -- Decisions --
    def search_decisions(self, query: dict) -> dict:
        return self.client.post("/patent/trials/decisions/search", query)

    def get_proceeding_decisions(self, trial_number: str) -> Optional[dict]:
        return self.client.get(f"/patent/trials/{trial_number}/decisions")

    # -- Documents --
    def get_trial_documents(self, trial_number: str) -> Optional[dict]:
        return self.client.get(f"/patent/trials/{trial_number}/documents")


def _unwrap(data: Optional[dict], bag_key: str) -> Optional[dict]:
    """Unwrap an ODP `...DataBag` array to its first element."""
    if not isinstance(data, dict):
        return data
    bag = data.get(bag_key)
    if isinstance(bag, list) and bag:
        return bag[0]
    return data


# =============================================================================
# ODP proceeding -> flat field dict  (as displayed on the UI)
# =============================================================================
# ODP trialTypeCode values may be "IPR"/"PGR"/"CBM"/"DER" or numeric codes.
_TRIAL_TYPE_MAP = {
    "IPR": "IPR", "PGR": "PGR", "CBM": "CBM", "DER": "DER",
    "102": "IPR", "321": "PGR", "911": "CBM",
}


def _parse_date(val) -> Optional[str]:
    """Parse an ODP date to an ISO 'YYYY-MM-DD' string (or None). Kept as a string so the
    output is JSON-serializable."""
    if not val:
        return None
    try:
        return date.fromisoformat(str(val)[:10]).isoformat()
    except (ValueError, TypeError):
        return None


def flatten_proceeding(odp_data: dict) -> dict:
    """Map a nested ODP proceeding response -> flat field dict.

    Mirrors the platform's TrackedProceeding field extraction: it flattens
    trialMetaData / patentOwnerData / (regular|derivation)PetitionerData into the
    columns the UI renders.
    """
    odp_data = odp_data or {}
    meta = odp_data.get("trialMetaData") or odp_data.get("proceedingData") or {}
    owner = odp_data.get("patentOwnerData") or {}
    petitioner = (
        odp_data.get("regularPetitionerData")
        or odp_data.get("derivationPetitionerData")
        or {}
    )

    raw_type = str(meta.get("trialTypeCode") or odp_data.get("trialTypeCode") or "")
    proc_type = _TRIAL_TYPE_MAP.get(raw_type.upper(), raw_type.upper())
    if proc_type not in ("IPR", "PGR", "CBM", "DER"):
        proc_type = ""

    # Prefer petitionFilingDate — accordedFilingDate can have ODP typos (e.g. 2033 vs 2023).
    filing = _parse_date(meta.get("petitionFilingDate") or meta.get("accordedFilingDate"))

    return {
        "trial_number": str(meta.get("trialNumber") or odp_data.get("trialNumber") or ""),
        "proceeding_type": proc_type,
        "status": str(meta.get("trialStatusCategory") or ""),
        # Patent under challenge
        "patent_number": str(owner.get("patentNumber") or ""),
        "application_number": str(owner.get("applicationNumberText") or ""),
        "patent_owner": str(owner.get("patentOwnerName") or owner.get("realPartyInInterestName") or ""),
        "real_party_respondent": str(owner.get("realPartyInInterestName") or ""),
        "patent_owner_counsel": str(owner.get("counselName") or ""),
        "inventor_name": str(owner.get("inventorName") or ""),
        "grant_date": _parse_date(owner.get("grantDate")),
        "group_art_unit": str(owner.get("groupArtUnitNumber") or ""),
        "technology_center": str(owner.get("technologyCenterNumber") or ""),
        # Petitioner
        "petitioner": str(petitioner.get("realPartyInInterestName") or petitioner.get("patentOwnerName") or ""),
        "real_party_petitioner": str(petitioner.get("realPartyInInterestName") or ""),
        "petitioner_counsel": str(petitioner.get("counselName") or ""),
        # Dates
        "filing_date": filing,
        "accorded_filing_date": _parse_date(meta.get("accordedFilingDate")),
        "petition_filing_date": _parse_date(meta.get("petitionFilingDate")),
        "institution_decision_date": _parse_date(meta.get("institutionDecisionDate")),
        "final_written_decision_date": _parse_date(
            meta.get("latestDecisionDate") or meta.get("finalWrittenDecisionDate")
        ),
        "termination_date": _parse_date(meta.get("terminationDate")),
        "decision_date": _parse_date(meta.get("latestDecisionDate") or meta.get("terminationDate")),
    }


# Sort fields the ODP proceedings search accepts (mirrors the platform's search config).
PROCEEDING_SORT_FIELDS = (
    "trialMetaData.petitionFilingDate",
    "trialMetaData.institutionDecisionDate",
    "trialMetaData.latestDecisionDate",
    "trialNumber",
)
# Status values ODP recognizes for trialStatusCategory.
PROCEEDING_STATUSES = (
    "Instituted",
    "Denied Institution",
    "Terminated - Adverse Judgment",
    "Terminated - Settlement",
    "Completed",
    "Pending",
)


def _field_q(field: str, value: str) -> str:
    """Lucene field qualifier for partial/party-name matching. Multi-word values are phrase-quoted."""
    value = (value or "").strip()
    if not value:
        return ""
    escaped = f'"{value}"' if " " in value else value
    return f"{field}:{escaped}"


def _date_range_q(field: str, date_from: str, date_to: str) -> str:
    """ODP rejects rangeFilters on date fields (400) — express ranges as Lucene `field:[from TO to]`."""
    date_from = (date_from or "").strip()
    date_to = (date_to or "").strip()
    if not date_from and not date_to:
        return ""
    return f"{field}:[{date_from or '*'} TO {date_to or '*'}]"


def build_proceeding_search(
    *,
    patent_number: str = "",
    application_number: str = "",
    proceeding_type: str = "",
    status: str = "",
    petitioner_name: str = "",
    patent_owner_name: str = "",
    search: str = "",
    filed_after: str = "",
    filed_before: str = "",
    query: str = "",
    sort_field: str = "trialMetaData.petitionFilingDate",
    sort_order: str = "desc",
    offset: int = 0,
    limit: int = 25,
) -> dict:
    """Build an ODP proceedings/search body, mirroring the platform's proven query builder.

    Exact/enum criteria go into `filters`; free-text, party names and date ranges are AND-ed
    into a Lucene `q` string (ODP 400s on rangeFilters for dates). Pass `query` to supply a
    fully-formed Lucene `q` yourself — it is combined (AND) with any structured params.
    """
    body: dict[str, Any] = {
        "pagination": {"offset": int(offset), "limit": int(limit)},
        "sort": [{"field": sort_field or "trialMetaData.petitionFilingDate",
                  "order": "asc" if str(sort_order).lower() == "asc" else "desc"}],
    }

    filters = []
    if proceeding_type:
        filters.append({"name": "trialMetaData.trialTypeCode", "value": [proceeding_type]})
    if status:
        filters.append({"name": "trialMetaData.trialStatusCategory", "value": [status]})
    if patent_number:
        filters.append({"name": "patentOwnerData.patentNumber", "value": [str(patent_number)]})
    if application_number:
        filters.append({"name": "patentOwnerData.applicationNumberText", "value": [str(application_number)]})
    if filters:
        body["filters"] = filters

    q_parts = [p for p in (
        (query or "").strip(),
        (search or "").strip(),
        _field_q("regularPetitionerData.realPartyInInterestName", petitioner_name),
        _field_q("patentOwnerData.realPartyInInterestName", patent_owner_name),
        _date_range_q("trialMetaData.petitionFilingDate", filed_after, filed_before),
    ) if p]
    if q_parts:
        body["q"] = " AND ".join(q_parts)
    return body


# Top-level array keys an ODP proceedings-search response may use (primary + observed fallbacks).
_PROCEEDING_BAG_KEYS = ("patentTrialProceedingDataBag", "results", "ptabTrialNumArr", "trialArr")


def extract_proceedings(resp: Optional[dict]) -> list[dict]:
    """Pull the list of proceeding records out of a search response, whatever key it used."""
    if not isinstance(resp, dict):
        return []
    for key in _PROCEEDING_BAG_KEYS:
        bag = resp.get(key)
        if isinstance(bag, list):
            return bag
    return []


# Columns for a compact search-results table, in display order: (label, extractor).
def summarize_proceeding(record: dict) -> dict:
    """Flatten one proceeding search record to the key columns a results table shows."""
    flat = flatten_proceeding(record or {})
    return {
        "trial_number": flat["trial_number"] or str((record or {}).get("trialNumber") or ""),
        "type": flat["proceeding_type"],
        "status": flat["status"],
        "patent_number": flat["patent_number"],
        "petitioner": flat["petitioner"],
        "patent_owner": flat["patent_owner"],
        "filing_date": flat["filing_date"],
        "institution_date": flat["institution_decision_date"],
        "decision_date": flat["final_written_decision_date"] or flat["decision_date"],
    }


def download_document_pdf(client: "OdpClient", file_download_uri: str) -> bytes:
    """Fetch a PTAB document's PDF bytes, replicating the platform's proxy flow:
    GET the ODP fileDownloadURI with the API key (no auto-redirect); if it 302s to a signed
    CloudFront URL, follow that WITHOUT the key. Raises OdpError on failure or an HTML body
    (some exhibits aren't indexed yet)."""
    if not file_download_uri:
        raise OdpError("document has no fileDownloadURI")
    headers = {"x-api-key": client.api_key} if client.api_key else {}
    try:
        resp = requests.get(file_download_uri, headers=headers, allow_redirects=False, timeout=60)
        if resp.status_code in (301, 302, 303, 307, 308):
            location = resp.headers.get("Location")
            if not location:
                raise OdpError("redirect without Location header")
            resp = requests.get(location, timeout=120)  # signed URL — no API key
        resp.raise_for_status()
    except requests.RequestException as exc:
        raise OdpError(f"document download failed: {exc}") from exc
    if "text/html" in (resp.headers.get("Content-Type") or "").lower():
        raise OdpError("document not available (server returned HTML, not a PDF)")
    return resp.content


# =============================================================================
# Counsel extraction from case PDFs
# =============================================================================
# --- regexes ---
ROLE_LABEL_RE = re.compile(r"(Lead Counsel|Back[\-\s]?up Counsel|Backup Counsel)", re.I)
REG_RE = re.compile(r"Reg(?:istration)?\.?\s*No\.?\s*([\d,]{4,})", re.I)
EMAIL_RE = re.compile(r"[\w.\-+]+@[\w.\-]+\.\w+")
PHONE_RE = re.compile(r"(?:Telephone|Tel|Phone)[:.]?\s*([\d()\-.\s]{7,}\d)", re.I)
PRO_HAC_RE = re.compile(r"pro\s+hac\s+vice", re.I)
_FIRM_RE = re.compile(r"\b(LLP|LLC|PLLC|P\.?\s?C\.?|L\.?L\.?P\.?)\b")
_COMPANY_RE = re.compile(r"\b(Inc|Corp|Co|Ltd|Company|Systems|Technologies|Holdings|GmbH|N\.?V|S\.?A|AG)\b", re.I)
_NAME_BAD = ("service", "notice", "information", "counsel", "petitioner", "patent owner")


# --- PDF text ---
def _pdf_to_text(content: bytes) -> str:
    """Extract text, preferring poppler's `pdftotext -layout` (keeps the counsel columns
    aligned). Falls back to pdfplumber."""
    try:
        proc = subprocess.run(
            ["pdftotext", "-layout", "-", "-"],
            input=content, capture_output=True, timeout=60,
        )
        if proc.returncode == 0 and proc.stdout:
            return proc.stdout.decode("utf-8", "replace")
    except (FileNotFoundError, subprocess.SubprocessError) as exc:
        logger.warning("pdftotext unavailable (%s); trying pdfplumber", exc)
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            return "\n".join((p.extract_text() or "") for p in pdf.pages)
    except Exception as exc:
        logger.warning("pdfplumber extraction failed: %s", exc)
        return ""


def _slice_notices(text: str) -> str:
    """Isolate the §42.8 counsel designation in a long Petition: the FIRST Lead/Back-Up Counsel
    label that has a 'Reg. No.' close after it. Avoids parsing claim-chart text as names."""
    for m in ROLE_LABEL_RE.finditer(text):
        if REG_RE.search(text[m.start(): m.start() + 600]):
            return text[max(0, m.start() - 300): m.start() + 3000]
    return ""


# --- parsing ---
def _is_name_line(s: str) -> bool:
    if not s or len(s) > 60:
        return False
    low = s.lower()
    if any(bad in low for bad in _NAME_BAD):
        return False
    if (s.isupper() or ":" in s or "@" in s or ".." in s or re.search(r"\d", s)
            or _FIRM_RE.search(s) or _COMPANY_RE.search(s)):
        return False
    tokens = [t for t in re.split(r"[\s,]+", s) if t and t[0].isalpha()]
    if not (2 <= len(tokens) <= 5 and all(t[0].isupper() for t in tokens[:2])):
        return False
    # Reject outline headings whose first token is a bare initial ("A. Kangasvieri").
    return len(tokens[0].rstrip(".")) >= 2


def _role_from_label(label: str) -> str:
    return "lead" if "lead" in label.lower() else "backup"


def _clean_reg(raw: str) -> str:
    """Digits only, bounded to a plausible USPTO registration number (3–6 digits)."""
    d = re.sub(r"\D", "", raw or "")
    return d if 3 <= len(d) <= 6 else ""


def _clean_firm(s: str) -> str:
    """Strip a leading field label ("Address:", "Email:", "Tel:") from a candidate firm line."""
    return re.sub(r"^\s*(Address|Email|E-mail|Tel\w*|Phone|Fax|Counsel)\s*:?\s*", "", s or "",
                  flags=re.I).strip().strip(":").strip()


def _counsel_section(text: str) -> list[str]:
    """Lines from the first counsel role label to the certificate of service / signature block."""
    lines = text.splitlines()
    start = next((i for i, l in enumerate(lines) if ROLE_LABEL_RE.search(l)), None)
    if start is None:
        return []
    end = len(lines)
    terminator = re.compile(
        r"CERTIFICATE OF SERVICE|Respectfully submitted|Company Data|/s/"
        r"|^\s*DATED?\b|^\s*Name\s*:|^\s*Title\s*:|^\s*Signature\s*:",
        re.I,
    )
    for i in range(start + 1, len(lines)):
        if terminator.search(lines[i]):
            end = i
            break
    return lines[start:end]


def _split_two_columns(section: list[str]) -> Optional[tuple[list[str], list[str]]]:
    """If the section has a 'Lead Counsel … Backup Counsel' header row, split each line at the
    column gutter into (left, right) sub-columns. Returns None for single-column / inline."""
    header = None
    for l in section:
        labels = ROLE_LABEL_RE.findall(l)
        if (len(labels) >= 2 and any("lead" in x.lower() for x in labels)
                and any("back" in x.lower() for x in labels)):
            header = section.index(l)
            break
    if header is None:
        return None

    body = [l for l in section[header + 1:] if l.strip()]
    if len(body) < 3:
        return None
    maxlen = max(len(l) for l in body)
    n = len(body)

    def is_gutter(c: int) -> bool:
        return sum(1 for l in body if c >= len(l) or l[c] == " ") >= 0.9 * n

    runs, c = [], 0
    while c < maxlen:
        if is_gutter(c):
            run_start = c
            while c < maxlen and is_gutter(c):
                c += 1
            runs.append((run_start, c))
        else:
            c += 1
    interior = [(s, e) for (s, e) in runs if s > 12 and e < maxlen and e - s >= 2]
    if not interior:
        return None
    _, split = max(interior, key=lambda r: r[1] - r[0])  # right column starts at `split`

    rows = section[header + 1:]
    left = ["Lead Counsel"] + [l[:split] for l in rows]
    right = ["Backup Counsel"] + [l[split:] for l in rows]
    return left, right


def _parse_records(lines: list[str], default_role: Optional[str]) -> list[dict]:
    """Group lines into per-attorney records and extract reg#, firm, email, phone."""
    blocks: list[tuple[str, list[str]]] = []
    cur: Optional[list[str]] = None
    cur_role = default_role or "other"
    pending_role = default_role or "other"

    for raw in lines:
        s = raw.strip()
        if not s:
            continue
        role_here = None
        m = ROLE_LABEL_RE.match(s)
        if m:
            pending_role = role_here = _role_from_label(m.group(1))
            s = s[m.end():].lstrip(":").strip()  # "Lead Counsel: Jane Doe" → "Jane Doe"
            if not s:
                continue
        name_candidate = s.split("(")[0].strip().rstrip(",").strip()
        if _is_name_line(name_candidate):
            if cur is not None:
                blocks.append((cur_role, cur))
            cur = [s]
            cur_role = role_here or pending_role or "other"
        elif cur is not None:
            cur.append(s)
    if cur is not None:
        blocks.append((cur_role, cur))

    entries: list[dict] = []
    for role, blk in blocks:
        text = "\n".join(blk)
        name = blk[0].split("(")[0].strip().rstrip(",").strip()
        reg_m = REG_RE.search(text)
        reg = _clean_reg(reg_m.group(1)) if reg_m else ""
        email_m = EMAIL_RE.search(text)
        phone_m = PHONE_RE.search(text)
        pro_hac = bool(PRO_HAC_RE.search(text))

        firm = ""
        for ln in blk[1:]:
            if EMAIL_RE.search(ln) or PHONE_RE.search(ln) or REG_RE.search(ln) or PRO_HAC_RE.search(ln):
                continue
            if re.match(r"^\d", ln) or re.search(r"\b[A-Z]{2}\.?\s*\d{5}", ln):  # street / city,ST zip
                continue
            cf = _clean_firm(ln)
            if len(cf) > 2:
                firm = cf
                break

        entries.append({
            "role": "pro_hac" if pro_hac else role,
            "name": name,
            "registration_number": reg,
            "firm_name": firm[:255],
            "email": (email_m.group(0) if email_m else "")[:255],
            "phone": (phone_m.group(1).strip() if phone_m else "")[:50],
            "pro_hac": pro_hac,
        })
    return entries


def _parse_counsel(text: str, side: Optional[str]) -> list[dict]:
    """Parse the counsel block(s) of a POA / Mandatory-Notices PDF (either layout)."""
    section = _counsel_section(text)
    if not section:
        return []

    cols = _split_two_columns(section)
    if cols:
        left, right = cols
        raw_entries = _parse_records(left, "lead") + _parse_records(right, "backup")
    else:
        raw_entries = _parse_records(section, None)

    entries, seen = [], set()
    for e in raw_entries:
        key = e["name"].lower()
        if not e["name"] or key in seen:
            continue
        seen.add(key)
        e["side"] = side
        entries.append(e)
    return entries


# --- helpers shared by parsers / merge ---
def _is_alias_email(email: str) -> bool:
    """Shared/matter-specific mailbox (e.g. PH-Resmed-Fractus-IPR@…) — never personal."""
    if not email or "@" not in email:
        return True
    local = email.split("@")[0].lower()
    if local.count("-") >= 2 or local.count(".") >= 3:
        return True
    return any(tok in local for tok in ("ipr", "pgr", "docket", "team", "litig", "patent", "service"))


def _split_name(name: str) -> tuple[str, str]:
    if "," in name:  # "Last, First"
        last, first = name.split(",", 1)
        return first.strip().split(" ")[0], last.strip()
    parts = [p for p in name.split() if p]
    if len(parts) >= 2:
        return parts[0], parts[-1]
    return (parts[0] if parts else ""), ""


def _looks_like_firm(name: str) -> bool:
    """Guard against mis-parsed prose ("In an Office Action dated…") becoming a firm name."""
    name = (name or "").strip()
    if not name or len(name) > 70 or re.search(r"\d", name):
        return False
    if _FIRM_RE.search(name):
        return True
    words = name.split()
    prose = {"in", "an", "the", "dated", "office", "action", "on", "of", "for", "to", "is", "are",
             "was", "contact", "information", "lead", "backup", "counsel", "and", "following"}
    return (len(words) <= 6 and name[0].isupper()
            and not any(w.lower().strip(",") in prose for w in words))


# --- document selection ---
def _side_from_text(text: str) -> Optional[str]:
    low = text.lower()
    if "patent owner" in low or "respondent" in low:
        return "patent_owner"
    if "petitioner" in low:
        return "petitioner"
    return None


def _side_from_party(category: str) -> Optional[str]:
    cat = (category or "").upper()
    if "PETITION" in cat:
        return "petitioner"
    if "OWNER" in cat or "RESPOND" in cat:
        return "patent_owner"
    return None


def _classify_documents(docs: list[dict]) -> list[dict]:
    """Build the list of parse jobs across all counsel-bearing documents. Board-issued docs and
    exhibits are skipped. A job = {kind, side, dd, date} where kind ∈ {block, signature, cos, pro_hac}."""
    jobs: list[dict] = []
    latest: dict[str, dict] = {}  # category -> most-recently-filed dd (for POPR / RESPONSE)

    for d in docs:
        dd = d.get("documentData") or {}
        party = (dd.get("filingPartyCategory") or "").upper()
        cat = (dd.get("documentCategory") or "").upper()
        if "BOARD" in party or cat == "EXHIBIT":
            continue
        blob = f"{dd.get('documentTitleText') or ''} {dd.get('documentName') or ''}".lower()
        side = _side_from_party(party) or _side_from_text(blob)
        dt = dd.get("documentFilingDate") or ""

        if "power of attorney" in blob or "mandatory notice" in blob:
            jobs.append({"kind": "block", "side": side, "dd": dd, "date": dt})
        elif cat == "PETITION":
            jobs.append({"kind": "block", "side": side or "petitioner", "dd": dd, "date": dt})
            jobs.append({"kind": "cos", "side": None, "dd": dd, "date": dt})
        elif cat in ("POPR", "RESPONSE"):
            prev = latest.get(cat)
            if prev is None or dt > (prev.get("documentFilingDate") or ""):
                latest[cat] = dd
        elif cat == "MOTION" and "joinder" in blob:
            jobs.append({"kind": "cos", "side": None, "dd": dd, "date": dt})

    # Latest patent-owner response paper: signature → PO counsel, COS → opposing counsel.
    for cat, dd in latest.items():
        side = _side_from_party(dd.get("filingPartyCategory") or "") or "patent_owner"
        dt = dd.get("documentFilingDate") or ""
        jobs.append({"kind": "signature", "side": side, "dd": dd, "date": dt})
        jobs.append({"kind": "cos", "side": None, "dd": dd, "date": dt})
    return jobs


# --- signature block ---
def _parse_signature_block(text: str, side: Optional[str]) -> list[dict]:
    """Extract the filing party's signing counsel from the block after the last `/s/` or
    `Respectfully submitted`."""
    anchors = list(re.finditer(r"/s/|Respectfully submitted", text, re.I))
    if not anchors:
        return []
    block = text[anchors[-1].start():anchors[-1].start() + 700]
    lines = [l.strip() for l in block.splitlines() if l.strip()]

    name = ""
    for l in lines:
        cand = re.sub(r"^/s/\s*", "", l, flags=re.I).split("(")[0].split(",")[0].strip()
        if _is_name_line(cand):
            name = cand
            break
    if not name:
        return []

    reg_m = REG_RE.search(block)
    email_m = EMAIL_RE.search(block)
    phone_m = PHONE_RE.search(block)
    firm = next((_clean_firm(l.split("(")[0]) for l in lines
                 if _FIRM_RE.search(l) and not EMAIL_RE.search(l) and not REG_RE.search(l)), "")

    low = block.lower()
    resolved_side = ("patent_owner" if re.search(r"(?:attorney|counsel)s?\s+for\s+(?:the\s+)?patent owner", low)
                     else "petitioner" if re.search(r"(?:attorney|counsel)s?\s+for\s+(?:the\s+)?petitioner", low)
                     else side)
    if resolved_side is None:
        return []
    return [{
        "side": resolved_side, "role": "lead", "name": name,
        "registration_number": _clean_reg(reg_m.group(1)) if reg_m else "",
        "firm_name": firm[:255],
        "email": (email_m.group(0) if email_m else "")[:255],
        "phone": (phone_m.group(1).strip() if phone_m else "")[:50],
        "pro_hac": False,
    }]


def _parse_pro_hac_motion(title: str, side: Optional[str]) -> list[dict]:
    """The PHV motion names the (usually unregistered) back-up counsel in its title."""
    m = re.search(r"pro\s+hac\s+vice\s+(?:admission|recognition)\s+of\s+([A-Z][\w.\-’']+(?:\s+[A-Z][\w.\-’']+){1,3})",
                  title, re.I)
    if not m or side is None or not _is_name_line(m.group(1)):
        return []
    return [{
        "side": side, "role": "pro_hac", "name": m.group(1).strip(),
        "registration_number": "", "firm_name": "", "email": "", "phone": "", "pro_hac": True,
    }]


# --- Certificate of Service parsing ---
_COS_DASH = r"[—–-]"  # em dash, en dash, hyphen
_COS_ATTY_RE = re.compile(
    r"^([A-Z][A-Za-z.\-'’]+(?:\s+[A-Z][A-Za-z.\-'’]+){1,3})\s*"
    + _COS_DASH + r"\s*([\w.\-+]+@[\w.\-]+\.\w+)"
)
_COS_NAMEREG_RE = re.compile(
    r"([A-Z][A-Za-z.\-'’]+(?:\s+[A-Z][A-Za-z.\-'’]+){1,3}),?\s+Reg\.?\s*No\.?\s*(\d[\d,\s]*\d|\d)"
)


def _email_for(name: str, emails: list[str]) -> str:
    """Best-effort: match an attorney to the service email whose local-part contains their surname."""
    parts = [p.strip(".'’-").lower() for p in re.split(r"[\s,]+", name) if p and p[0].isalpha()]
    if not parts:
        return ""
    last = parts[-1]
    for e in emails:
        local = e.split("@")[0].lower()
        if len(last) >= 3 and last in local:
            return e
    return ""


def _first_firm(lines: list[str]) -> str:
    for l in lines:
        if EMAIL_RE.search(l) or REG_RE.search(l):
            continue
        m = re.search(r"(.+?(?:LLP|LLC|PLLC|L\.?L\.?P\.?))(?:\s|$)", l)
        if m:
            return _clean_firm(m.group(1))
    return ""


def _parse_certificate_of_service(text: str) -> list[dict]:
    up = text.upper()
    start = up.rfind("CERTIFICATE OF SERVICE")
    if start == -1:
        m0 = re.search(r"^\s*Counsel\s+for\b", text, re.I | re.M)
        if not m0:
            return []
        start = m0.start()
    region = text[start:]
    term = re.search(r"\n\s*Dated\s*:|\n\s*By\s*:\s*/|\n\s*/s/", region, re.I)
    if term:
        region = region[:term.start()]

    # Split into "Counsel for <party> [— Firm]:" groups.
    groups: list[dict] = []
    cur: Optional[dict] = None
    awaiting_firm_wrap = False
    for raw in region.splitlines():
        s = raw.strip()
        if not s:
            continue
        if awaiting_firm_wrap and cur is not None:
            cur["firm"] = f"{cur['firm']} {s.rstrip(':')}".strip()
            awaiting_firm_wrap = not s.endswith(":")
            continue
        hm = re.match(r"Counsel\s+for\s+(.+)$", s, re.I)
        if hm:
            head = hm.group(1)
            low = head.lower()
            side = ("patent_owner" if any(t in low for t in ("patent owner", "patentee", "respondent"))
                    else "petitioner" if "petitioner" in low else None)
            parts = re.split(_COS_DASH, head)
            firm = parts[-1].strip().rstrip(":").strip() if len(parts) > 1 else ""
            cur = {"side": side, "firm": firm, "body": []}
            groups.append(cur)
            awaiting_firm_wrap = len(parts) > 1 and not s.endswith(":")
            continue
        if cur is not None:
            cur["body"].append(s)

    entries: list[dict] = []
    for g in groups:
        if not g["side"]:
            continue
        body = "\n".join(g["body"])
        emails = EMAIL_RE.findall(body)
        firm = g["firm"] or _first_firm(g["body"])
        seen: set[str] = set()

        def add(name, reg, email):
            key = name.lower()
            if key in seen:
                return
            seen.add(key)
            entries.append({
                "side": g["side"], "role": "other", "name": name,
                "registration_number": reg, "firm_name": firm[:255],
                "email": email[:255], "phone": "", "pro_hac": False,
            })

        for m in _COS_NAMEREG_RE.finditer(body):            # (b) reg form
            nm = m.group(1).strip()
            add(nm, _clean_reg(m.group(2)), _email_for(nm, emails))
        for raw in g["body"]:                                # (a) joinder form
            am = _COS_ATTY_RE.match(raw)
            if am:
                add(am.group(1).strip(), "", am.group(2).strip())
    return entries


# --- orchestration ---
def _download_text(dd: dict, api_key: str, cache: dict) -> str:
    # Key the cache on the download URI (falling back to the identifier); a missing
    # documentIdentifier must not collapse distinct documents onto a single None key.
    did = dd.get("fileDownloadURI") or dd.get("documentIdentifier")
    if did in cache:
        return cache[did]
    text = ""
    url = dd.get("fileDownloadURI")
    if url:
        try:
            resp = requests.get(url, headers={"x-api-key": api_key} if api_key else {}, timeout=60)
            resp.raise_for_status()
            text = _pdf_to_text(resp.content)
        except requests.RequestException as exc:
            logger.warning("Counsel doc download failed (%s): %s", did, exc)
    cache[did] = text
    return text


_ROLE_PRI = {"lead": 0, "backup": 1, "pro_hac": 2, "other": 3}


def _norm_key(name: str) -> str:
    first, last = _split_name(name)
    return f"{first} {last}".lower().strip()


def _merge_entries(collected: list[tuple[dict, dict, str]]) -> list[tuple[dict, dict]]:
    """Merge counsel found across many documents. Key on (side, first+last). Fill blank fields from
    any source, keep the most specific role, prefer the fuller name, attribute to the reg-bearing
    (or latest) source document."""
    merged: dict[tuple, dict] = {}
    for entry, dd, dt in sorted(collected, key=lambda x: x[2]):  # oldest first → latest wins on source
        key = (entry["side"], _norm_key(entry["name"]))
        if key not in merged:
            merged[key] = {"entry": dict(entry), "dd": dd}
            continue
        cur = merged[key]
        ce = cur["entry"]
        for f in ("registration_number", "email", "phone", "firm_name"):
            if not ce.get(f) and entry.get(f):
                ce[f] = entry[f]
        if _ROLE_PRI.get(entry["role"], 9) < _ROLE_PRI.get(ce["role"], 9):
            ce["role"] = entry["role"]
        if len(entry["name"]) > len(ce["name"]):
            ce["name"] = entry["name"]
        if entry.get("registration_number"):  # reg-bearing doc is the most authoritative source
            cur["dd"] = dd
    return [(v["entry"], v["dd"]) for v in merged.values()]


def resolve_counsel(trial_number: str, service: Optional[TrialService] = None) -> list[dict]:
    """Extract the attorney roster for a PTAB trial directly from its filed PDFs.

    Parses every counsel-bearing document (POA / Mandatory Notices / Petition §42.8 block,
    signature blocks, certificates of service, pro-hac motions), then merges + dedupes across
    them. Returns a list of counsel dicts (raw — no practitioner-DB linking):

        {
          "trial_number", "side", "role", "name",
          "registration_number", "firm_name", "email", "phone", "pro_hac",
          "source_document_identifier", "source_document_name",
        }
    """
    trial_number = (trial_number or "").strip()
    svc = service or TrialService()

    doc_resp = svc.get_trial_documents(trial_number) or {}
    docs = doc_resp.get("patentTrialDocumentDataBag") or []
    api_key = svc.client.api_key
    text_cache: dict = {}

    collected: list[tuple[dict, dict, str]] = []  # (entry, source_doc, date)
    for job in _classify_documents(docs):
        dd, kind, side = job["dd"], job["kind"], job["side"]
        if kind == "pro_hac":
            entries = _parse_pro_hac_motion(dd.get("documentTitleText") or "", side)
        else:
            text = _download_text(dd, api_key, text_cache)
            if not text:
                continue
            if kind == "block":
                body = _slice_notices(text) if (dd.get("documentCategory") or "").upper() == "PETITION" else text
                entries = _parse_counsel(body, side)
            elif kind == "signature":
                entries = _parse_signature_block(text, side)
            elif kind == "cos":
                entries = _parse_certificate_of_service(text)
            else:
                entries = []
        for entry in entries:
            if entry.get("side"):
                collected.append((entry, dd, job["date"]))

    # Final garbage net: a real counsel entry always carries a registration number or an email.
    # Anything without either is mis-parsed prose (claim-chart names, headings) — drop it.
    parsed = [(e, dd) for (e, dd) in _merge_entries(collected)
              if e.get("registration_number") or (e.get("email") and "@" in e["email"])]

    results: list[dict] = []
    for entry, dd in parsed:
        results.append({
            "trial_number": trial_number,
            "side": entry["side"],
            "role": entry["role"],
            "name": entry["name"],
            "registration_number": entry["registration_number"],
            "firm_name": entry["firm_name"] if _looks_like_firm(entry["firm_name"]) else "",
            "email": entry["email"],
            "phone": entry["phone"],
            "pro_hac": entry.get("pro_hac", False),
            "source_document_identifier": str(dd.get("documentIdentifier") or ""),
            "source_document_name": (dd.get("documentName") or "")[:300],
            "source_document_uri": dd.get("fileDownloadURI") or "",
        })
    return results


# =============================================================================
# CLI
# =============================================================================
def _emit(obj: Any) -> None:
    json.dump(obj, sys.stdout, indent=2, ensure_ascii=False)
    sys.stdout.write("\n")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Standalone USPTO PTAB extractor (proceedings, documents, decisions, counsel).",
    )
    parser.add_argument("--api-key", default="", help="ODP API key (else USPTO_ODP_API_KEY env var)")
    parser.add_argument("--base-url", default="", help="ODP base URL (else USPTO_ODP_BASE_URL env var)")
    parser.add_argument("-v", "--verbose", action="store_true", help="log to stderr")
    sub = parser.add_subparsers(dest="command", required=True)

    p_get = sub.add_parser("get", help="fetch a proceeding (raw + flattened)")
    p_get.add_argument("trial_number")
    p_get.add_argument("--raw", action="store_true", help="emit raw ODP response only")

    p_docs = sub.add_parser("documents", help="list a trial's documents")
    p_docs.add_argument("trial_number")

    p_dec = sub.add_parser("decisions", help="fetch a trial's decisions")
    p_dec.add_argument("trial_number")

    p_counsel = sub.add_parser("counsel", help="extract counsel roster from case PDFs")
    p_counsel.add_argument("trial_number")

    p_search = sub.add_parser("search", help="search proceedings")
    p_search.add_argument("--query", default="", help="raw Lucene query (q)")
    p_search.add_argument("--search", default="", help="free-text search")
    p_search.add_argument("--patent", default="", help="patent number filter")
    p_search.add_argument("--application", default="", help="application number filter")
    p_search.add_argument("--type", default="", help="proceeding type (IPR/PGR/CBM/DER)")
    p_search.add_argument("--status", default="", help=f"status ({', '.join(PROCEEDING_STATUSES)})")
    p_search.add_argument("--petitioner", default="", help="petitioner party name")
    p_search.add_argument("--patent-owner", default="", help="patent owner party name")
    p_search.add_argument("--filed-after", default="", help="petition filed on/after YYYY-MM-DD")
    p_search.add_argument("--filed-before", default="", help="petition filed on/before YYYY-MM-DD")
    p_search.add_argument("--sort", default="trialMetaData.petitionFilingDate", help="sort field")
    p_search.add_argument("--order", default="desc", choices=["asc", "desc"], help="sort order")
    p_search.add_argument("--offset", type=int, default=0)
    p_search.add_argument("--limit", type=int, default=25)

    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )

    client = OdpClient(api_key=args.api_key, base_url=args.base_url)
    if not client.api_key:
        sys.stderr.write("warning: no API key set (pass --api-key or USPTO_ODP_API_KEY)\n")
    svc = TrialService(client)

    try:
        if args.command == "get":
            proc = svc.get_proceeding(args.trial_number)
            if args.raw:
                _emit(proc)
            else:
                _emit({"flattened": flatten_proceeding(proc or {}), "raw": proc})
        elif args.command == "documents":
            _emit(svc.get_trial_documents(args.trial_number))
        elif args.command == "decisions":
            _emit(svc.get_proceeding_decisions(args.trial_number))
        elif args.command == "counsel":
            _emit(resolve_counsel(args.trial_number, svc))
        elif args.command == "search":
            body = build_proceeding_search(
                patent_number=args.patent,
                application_number=args.application,
                proceeding_type=args.type,
                status=args.status,
                petitioner_name=args.petitioner,
                patent_owner_name=args.patent_owner,
                search=args.search,
                filed_after=args.filed_after,
                filed_before=args.filed_before,
                query=args.query,
                sort_field=args.sort,
                sort_order=args.order,
                offset=args.offset,
                limit=args.limit,
            )
            _emit(svc.search_proceedings(body))
    except OdpError as exc:
        sys.stderr.write(f"error: {exc}\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
