"""
Native (Tkinter) desktop UI for the standalone PTAB extractor.

Uses only the Python standard library — tkinter / ttk / scrolledtext / filedialog /
messagebox / logging. No third-party GUI dependency. It is a thin front end over
`ptab_extractor`: every ODP call runs on a background thread so the window never freezes,
and results (and log records) are posted back to the Tk main loop via queues.

Tabs:
    * Lookup by trial #  — Proceeding / Documents / Decisions / Counsel.
    * Search proceedings — filter by type, status, patent #, party names, dates; paginate; export.
    * Logs               — live log view; also written to a rotating file next to this script.
    * Settings           — ODP connection, request tuning, defaults; persisted (except the API key).

Every result area toggles Structured table / Raw JSON, supports click-header sorting and
right-click copy. Document / decision rows open their PDF on double-click.

Run:
    python ptab_gui.py

Requirements:
    * Python 3.10+
    * The Tk binding for Python (stdlib `tkinter`, but Tk libs are a separate OS package):
          Debian/Ubuntu:  sudo apt install python3-tk
          Fedora:         sudo dnf install python3-tkinter
    * See ptab_extractor.py for the ODP API key + pdftotext requirements.
"""

from __future__ import annotations

import csv
import json
import logging
import logging.handlers
import os
import queue
import shutil
import subprocess
import tempfile
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Callable, Optional

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

import ptab_extractor as ptab
import litigation

# --- paths (same folder as this script, with a read-only fallback) ---
try:
    _SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    if not os.access(_SCRIPT_DIR, os.W_OK):
        raise OSError
    DATA_DIR = _SCRIPT_DIR
except OSError:
    DATA_DIR = tempfile.gettempdir()

LOG_PATH = os.path.join(DATA_DIR, "ptab_gui.log")
CONFIG_PATH = os.path.join(DATA_DIR, "ptab_gui_config.json")

# Non-secret settings persisted to CONFIG_PATH. The API key is deliberately excluded.
_CONFIG_KEYS = ("base_url", "log_level", "timeout", "max_retries", "backoff_base",
                "sort_field", "sort_order", "limit", "open_pdf", "geometry")
_DEFAULTS = {
    "base_url": ptab.DEFAULT_BASE_URL,
    "log_level": "INFO",
    "timeout": "30",
    "max_retries": "3",
    "backoff_base": "2",
    "sort_field": "trialMetaData.petitionFilingDate",
    "sort_order": "desc",
    "limit": "25",
    "open_pdf": True,
    "geometry": "1120x780",
}


def _open_path(path: str) -> None:
    """Open a file or folder with the OS default handler (stdlib-only, Windows-safe)."""
    try:
        webbrowser.open(Path(path).as_uri())
    except Exception:
        webbrowser.open("file://" + path)


# =============================================================================
# Logging → Tk (thread-safe via a queue drained on the main loop)
# =============================================================================
class QueueLogHandler(logging.Handler):
    """Formats each record and drops it on a queue; the Tk main loop renders it.
    emit() may run on a worker thread, so it never touches widgets."""

    def __init__(self, log_queue: "queue.Queue[tuple[str, str]]"):
        super().__init__()
        self.log_queue = log_queue

    def emit(self, record):
        try:
            self.log_queue.put_nowait((self.format(record), record.levelname))
        except Exception:
            self.handleError(record)


# =============================================================================
# Small reusable widgets
# =============================================================================
class Tooltip:
    """Lightweight hover tooltip (native Toplevel — no dependencies)."""

    def __init__(self, widget: tk.Widget, text: str, delay: int = 500):
        self.widget = widget
        self.text = text
        self.delay = delay
        self._after_id: Optional[str] = None
        self._tip: Optional[tk.Toplevel] = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _event=None):
        self._cancel()
        self._after_id = self.widget.after(self.delay, self._show)

    def _cancel(self):
        if self._after_id:
            self.widget.after_cancel(self._after_id)
            self._after_id = None

    def _show(self):
        if self._tip or not self.text:
            return
        x = self.widget.winfo_rootx() + 12
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self._tip = tk.Toplevel(self.widget)
        self._tip.wm_overrideredirect(True)
        self._tip.wm_geometry(f"+{x}+{y}")
        ttk.Label(self._tip, text=self.text, background="#ffffe0", relief="solid",
                  borderwidth=1, padding=(6, 3), justify="left", wraplength=320).pack()

    def _hide(self, _event=None):
        self._cancel()
        if self._tip:
            self._tip.destroy()
            self._tip = None


def _sort_key(value: Any):
    """Numeric-aware sort key so '10' > '9' and dates/strings still order sensibly."""
    s = "" if value is None else str(value)
    try:
        return (0, float(s.replace(",", "")))
    except ValueError:
        return (1, s.lower())


class ResultPane(ttk.Frame):
    """A result area that switches between a Structured (Treeview) view and a Raw-JSON view.
    Supports click-header sorting and right-click copy. Optional on_row_open(meta) fires on
    double-click of a structured row (meta is the per-row payload)."""

    def __init__(self, parent, on_row_open: Optional[Callable[[Any], None]] = None):
        super().__init__(parent)
        self.on_row_open = on_row_open
        self._payload: Any = None
        self._columns: list[str] = []
        self._rows: list[list[Any]] = []
        self._row_meta: list[Any] = []
        self._sort_col: Optional[str] = None
        self._sort_desc = False
        self._empty_hint = ""

        toolbar = ttk.Frame(self)
        toolbar.pack(fill="x", pady=(0, 4))
        ttk.Label(toolbar, text="View:").pack(side="left")
        self.view_var = tk.StringVar(value="structured")
        ttk.Radiobutton(toolbar, text="Structured", value="structured",
                        variable=self.view_var, command=self._apply_view).pack(side="left", padx=2)
        ttk.Radiobutton(toolbar, text="Raw JSON", value="raw",
                        variable=self.view_var, command=self._apply_view).pack(side="left", padx=2)
        self.count_var = tk.StringVar(value="")
        ttk.Label(toolbar, textvariable=self.count_var, foreground="#555").pack(side="right")

        self._body = ttk.Frame(self)
        self._body.pack(fill="both", expand=True)

        # Structured (table) view
        self._table_frame = ttk.Frame(self._body)
        self.tree = ttk.Treeview(self._table_frame, show="headings")
        vsb = ttk.Scrollbar(self._table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(self._table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self._table_frame.rowconfigure(0, weight=1)
        self._table_frame.columnconfigure(0, weight=1)
        self.tree.bind("<Double-1>", self._on_double)

        # Right-click copy menu
        self._menu = tk.Menu(self.tree, tearoff=0)
        self._menu.add_command(label="Copy cell", command=self._copy_cell)
        self._menu.add_command(label="Copy row", command=self._copy_row)
        self._menu.add_command(label="Copy selection (TSV)", command=self._copy_selection)
        self.tree.bind("<Button-3>", self._popup_menu)
        self._menu_event = None

        # Raw JSON view
        self.text = scrolledtext.ScrolledText(self._body, wrap="none", font=("Courier", 10))

        self._apply_view()

    # -- view switching --
    def _apply_view(self):
        self._table_frame.pack_forget()
        self.text.pack_forget()
        if self.view_var.get() == "raw":
            self.text.pack(fill="both", expand=True)
        else:
            self._table_frame.pack(fill="both", expand=True)

    def _on_double(self, _event):
        if not self.on_row_open:
            return
        sel = self.tree.selection()
        if not sel:
            return
        idx = self.tree.index(sel[0])
        if 0 <= idx < len(self._row_meta):
            self.on_row_open(self._row_meta[idx])

    # -- copy --
    def _popup_menu(self, event):
        self._menu_event = event
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
        try:
            self._menu.tk_popup(event.x_root, event.y_root)
        finally:
            self._menu.grab_release()

    def _selected_values(self) -> Optional[list[str]]:
        sel = self.tree.selection()
        if not sel:
            return None
        return [str(v) for v in self.tree.item(sel[0], "values")]

    def _copy_cell(self):
        vals = self._selected_values()
        if not vals or self._menu_event is None:
            return
        col = self.tree.identify_column(self._menu_event.x)  # '#N'
        try:
            i = int(col[1:]) - 1
        except ValueError:
            i = 0
        if 0 <= i < len(vals):
            self._to_clipboard(vals[i])

    def _copy_row(self):
        vals = self._selected_values()
        if vals:
            self._to_clipboard("\t".join(vals))

    def _copy_selection(self):
        lines = ["\t".join(self._columns)]
        for item in self.tree.selection():
            lines.append("\t".join(str(v) for v in self.tree.item(item, "values")))
        if len(lines) > 1:
            self._to_clipboard("\n".join(lines))

    def _to_clipboard(self, text: str):
        self.clipboard_clear()
        self.clipboard_append(text)

    # -- sorting --
    def _sort_by(self, col: str):
        if self._sort_col == col:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_col, self._sort_desc = col, False
        i = self._columns.index(col)
        order = sorted(range(len(self._rows)),
                       key=lambda r: _sort_key(self._rows[r][i]), reverse=self._sort_desc)
        self._rows = [self._rows[r] for r in order]
        self._row_meta = [self._row_meta[r] for r in order]
        self._render_rows()
        for c in self._columns:
            arrow = (" ▼" if self._sort_desc else " ▲") if c == col else ""
            self.tree.heading(c, text=c + arrow)

    # -- populate --
    def show_table(self, columns: list[str], rows: list[list[Any]], payload: Any,
                   row_meta: Optional[list[Any]] = None, count_label: str = "",
                   empty_hint: str = ""):
        self._payload = payload
        self._columns = columns
        self._rows = rows
        self._row_meta = row_meta or [None] * len(rows)
        self._sort_col = None
        self._empty_hint = empty_hint
        self.count_var.set(count_label or (f"{len(rows)} row(s)" if rows else (empty_hint or "no rows")))

        self.tree["columns"] = columns
        for c in columns:
            self.tree.heading(c, text=c, command=lambda col=c: self._sort_by(col))
            self.tree.column(c, width=max(80, min(300, 11 * len(c) + 20)), anchor="w", stretch=True)
        self._render_rows()

        self.text.delete("1.0", "end")
        self.text.insert("1.0", json.dumps(payload, indent=2, ensure_ascii=False))

    def _render_rows(self):
        self.tree.delete(*self.tree.get_children())
        for r in self._rows:
            self.tree.insert("", "end", values=[("" if v is None else v) for v in r])

    @property
    def payload(self) -> Any:
        return self._payload

    @property
    def columns(self) -> list[str]:
        return self._columns

    @property
    def rows(self) -> list[list[Any]]:
        return self._rows


class BulkDialog(tk.Toplevel):
    """Reusable bulk-name runner used by the PTAB and Litigation tabs.

    Names come from pasted text and/or a loaded file. Each name is processed sequentially on a
    worker thread via `run_one(name, search_as, client)` (returns a list of match dicts), with
    per-name status posted back to the Tk main loop through the app's result queue. Output can be
    exported three ways, selectable in the UI.
    """

    OUTPUT_PER_NAME = "Per-name results + export all matches"
    OUTPUT_SUMMARY = "Summary (name → count)"
    OUTPUT_MATCHED = "Matched names only"
    OUTPUT_MODES = (OUTPUT_PER_NAME, OUTPUT_SUMMARY, OUTPUT_MATCHED)

    def __init__(self, app: "PtabApp", title: str, search_as_options: list[str],
                 run_one: Callable[[str, str, Any], list[dict]],
                 match_columns: list[tuple[str, str]], client_factory: Callable[[], Any],
                 credential_label: str, has_credential: Callable[[], bool], pace_seconds: float = 0):
        super().__init__(app.root)
        self.app = app
        self.run_one = run_one
        self.match_columns = match_columns
        self.client_factory = client_factory
        self.credential_label = credential_label
        self.has_credential = has_credential
        self.pace_seconds = pace_seconds
        self._alive = True
        self._stop = threading.Event()
        self.results: dict[str, list[dict]] = {}
        self._row_ids: dict[str, str] = {}

        self.title(title)
        self.geometry("760x640")
        self.transient(app.root)
        self.protocol("WM_DELETE_WINDOW", self._close)

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=8)
        ttk.Label(top, text="Search names as:").pack(side="left")
        self.search_as_var = tk.StringVar(value=search_as_options[0])
        ttk.Combobox(top, textvariable=self.search_as_var, values=list(search_as_options),
                     state="readonly", width=16).pack(side="left", padx=6)
        ttk.Button(top, text="Load file…", command=self._load_file).pack(side="left", padx=6)
        Tooltip(top, "Paste names below and/or load a .txt (one per line) or .csv (first column).")

        io = ttk.LabelFrame(self, text="Names (one per line)")
        io.pack(fill="both", expand=False, padx=10, pady=(0, 8))
        self.names_text = scrolledtext.ScrolledText(io, height=7, font=("Courier", 9))
        self.names_text.pack(fill="both", expand=True, padx=6, pady=6)

        om = ttk.Frame(self)
        om.pack(fill="x", padx=10)
        ttk.Label(om, text="Output:").pack(side="left")
        self.mode_var = tk.StringVar(value=self.OUTPUT_PER_NAME)
        ttk.Combobox(om, textvariable=self.mode_var, values=list(self.OUTPUT_MODES),
                     state="readonly", width=38).pack(side="left", padx=6)

        ctl = ttk.Frame(self)
        ctl.pack(fill="x", padx=10, pady=8)
        self.start_btn = ttk.Button(ctl, text="Start", command=self._start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(ctl, text="Stop", command=self._stop_now, state="disabled")
        self.stop_btn.pack(side="left", padx=6)
        self.export_btn = ttk.Button(ctl, text="Export…", command=self._export, state="disabled")
        self.export_btn.pack(side="right")
        self.progress_var = tk.StringVar(value="")
        ttk.Label(ctl, textvariable=self.progress_var, foreground="#555").pack(side="left", padx=10)

        tf = ttk.Frame(self)
        tf.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.tree = ttk.Treeview(tf, columns=("name", "status", "matches"), show="headings")
        for c, w in (("name", 380), ("status", 210), ("matches", 80)):
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=w, anchor="w")
        vsb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        tf.rowconfigure(0, weight=1)
        tf.columnconfigure(0, weight=1)
        self.tree.bind("<Double-1>", self._view_matches)
        ttk.Label(self, text="Double-click a row to view that name's matches.",
                  foreground="#666").pack(anchor="w", padx=10, pady=(0, 8))

    # -- input --
    @staticmethod
    def _parse_names(content: str, csv_first_col: bool = False) -> list[str]:
        names = []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if csv_first_col and "," in line:
                line = line.split(",")[0].strip().strip('"')
            names.append(line)
        return names

    def _load_file(self):
        path = filedialog.askopenfilename(
            filetypes=[("Text/CSV", "*.txt *.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as fh:
                content = fh.read()
        except OSError as exc:
            messagebox.showerror("Read failed", str(exc))
            return
        names = self._parse_names(content, csv_first_col=path.lower().endswith(".csv"))
        existing = self.names_text.get("1.0", "end").strip()
        self.names_text.insert("end", ("\n" if existing else "") + "\n".join(names))

    def _names(self) -> list[str]:
        seen, out = set(), []
        for n in self._parse_names(self.names_text.get("1.0", "end")):
            k = n.lower()
            if k not in seen:
                seen.add(k)
                out.append(n)
        return out

    # -- run --
    def _start(self):
        if not self.has_credential():
            if not messagebox.askyesno("No credential",
                                       f"No {self.credential_label} set — searches will likely fail.\n"
                                       "Continue anyway?"):
                return
        names = self._names()
        if not names:
            messagebox.showinfo("No names", "Paste or load some names first.")
            return
        if self.pace_seconds and len(names) > 10:
            if not messagebox.askyesno(
                    "Large batch",
                    f"{len(names)} names against a rate-limited, slow API (~{self.pace_seconds}s+ "
                    "pacing plus 20–30s per query). This can take a long time and hit daily caps.\n\n"
                    "Continue?"):
                return
        self.results = {}
        self.tree.delete(*self.tree.get_children())
        self._row_ids = {n: self.tree.insert("", "end", values=(n, "Queued", "")) for n in names}
        self._stop.clear()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.export_btn.configure(state="disabled")
        client = self.client_factory()  # built on the main thread (reads Tk vars)
        search_as = self.search_as_var.get()
        threading.Thread(target=self._run, args=(names, search_as, client), daemon=True).start()

    def _run(self, names: list[str], search_as: str, client: Any):
        total = len(names)
        for i, name in enumerate(names, 1):
            if self._stop.is_set():
                self._post(self._done, i - 1, total, True)
                return
            self._post(self._set_status, name, "Searching…", "")
            self._post(self._progress, i, total)
            try:
                matches = self.run_one(name, search_as, client) or []
                self.results[name] = matches
                self._post(self._set_status, name,
                           f"✓ {len(matches)} match(es)" if matches else "— no match", str(len(matches)))
            except Exception as exc:  # noqa: BLE001 — record per-name failure, keep going
                self.app.log.warning("Bulk %r failed: %s", name, exc)
                self._post(self._set_status, name, f"✗ {type(exc).__name__}", "err")
            if self.pace_seconds and i < total and not self._stop.is_set():
                time.sleep(self.pace_seconds)
        self._post(self._done, total, total, False)

    # -- main-thread callbacks (posted via app queue) --
    def _post(self, fn, *args):
        if self._alive:
            self.app._results.put((fn, args))

    def _set_status(self, name, status, matches):
        iid = self._row_ids.get(name)
        if self._alive and iid and self.tree.exists(iid):
            self.tree.item(iid, values=(name, status, matches))

    def _progress(self, i, total):
        if self._alive:
            self.progress_var.set(f"{i}/{total}")

    def _done(self, done_count, total, stopped):
        if not self._alive:
            return
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.export_btn.configure(state="normal")
        matched = sum(1 for v in self.results.values() if v)
        self.progress_var.set(
            f"{'Stopped' if stopped else 'Done'} — {done_count}/{total} processed, {matched} matched")
        self.app.log.info("Bulk finished: %d/%d processed, %d matched", done_count, total, matched)

    def _stop_now(self):
        self._stop.set()
        self.stop_btn.configure(state="disabled")

    def _close(self):
        self._alive = False
        self._stop.set()
        self.destroy()

    # -- results --
    def _view_matches(self, _evt):
        sel = self.tree.selection()
        if not sel:
            return
        name = self.tree.item(sel[0], "values")[0]
        matches = self.results.get(name) or []
        if not matches:
            messagebox.showinfo("No matches", f"No results for {name!r}.")
            return
        win = tk.Toplevel(self)
        win.title(f"Matches — {name}")
        win.geometry("860x420")
        cols = [h for h, _ in self.match_columns]
        tv = ttk.Treeview(win, columns=cols, show="headings")
        for h, _ in self.match_columns:
            tv.heading(h, text=h)
            tv.column(h, width=130, anchor="w")
        for m in matches:
            tv.insert("", "end", values=[m.get(k, "") for _, k in self.match_columns])
        vsb = ttk.Scrollbar(win, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        tv.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

    def _export(self):
        if not self.results:
            messagebox.showinfo("Nothing to export", "Run a batch first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                            filetypes=[("CSV", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        mode = self.mode_var.get()
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            if mode == self.OUTPUT_SUMMARY:
                writer.writerow(["name", "match_count"])
                for name, matches in self.results.items():
                    writer.writerow([name, len(matches)])
            elif mode == self.OUTPUT_MATCHED:
                writer.writerow(["matched_name", "match_count"])
                for name, matches in self.results.items():
                    if matches:
                        writer.writerow([name, len(matches)])
            else:  # per-name + all matches
                writer.writerow(["query_name"] + [h for h, _ in self.match_columns])
                for name, matches in self.results.items():
                    for m in matches:
                        writer.writerow([name] + [m.get(k, "") for _, k in self.match_columns])
        self.app.log.info("Bulk export (%s) → %s", mode, path)
        self.progress_var.set(f"Exported → {path}")


# =============================================================================
# Main application
# =============================================================================
class PtabApp:
    SPINNER = "|/-\\"

    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("PTAB Extractor")
        self.log = logging.getLogger("ptab_gui")

        self._config = self._load_config()
        self._results: "queue.Queue[tuple[Callable, tuple]]" = queue.Queue()
        self._log_queue: "queue.Queue[tuple[str, str]]" = queue.Queue()
        self._busy = False
        self._spin_after: Optional[str] = None
        self._spin_frame = 0
        self._busy_msg = ""
        self._last_search_body: dict = {}
        self._last_result_count = 0
        self._pdf_tmpdir: Optional[str] = None  # lazily created; removed on close

        root.geometry(self._config.get("geometry") or _DEFAULTS["geometry"])
        root.minsize(860, 580)

        self._build_notebook()
        self._build_statusbar()
        self._setup_logging()

        root.protocol("WM_DELETE_WINDOW", self._on_close)
        root.report_callback_exception = self._on_tk_exception
        self.root.after(100, self._drain_queue)
        self.log.info("PTAB Extractor started. Logging to %s", LOG_PATH)

    # ------------------------------------------------------------------ config
    def _load_config(self) -> dict:
        cfg = dict(_DEFAULTS)
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            cfg.update({k: data[k] for k in _CONFIG_KEYS if k in data})
        except (OSError, ValueError, json.JSONDecodeError):
            pass
        return cfg

    def _save_config(self):
        data = {
            "base_url": self.base_url_var.get().strip(),
            "log_level": self.log_level_var.get(),
            "timeout": self.timeout_var.get().strip(),
            "max_retries": self.retries_var.get().strip(),
            "backoff_base": self.backoff_var.get().strip(),
            "sort_field": self.search_vars["sort_field"].get(),
            "sort_order": self.search_vars["sort_order"].get(),
            "limit": self.search_vars["limit"].get().strip(),
            "open_pdf": bool(self.open_pdf_var.get()),
            "geometry": self.root.geometry(),
        }
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2)
            self.log.info("Settings saved to %s", CONFIG_PATH)
            self.status_var.set("Settings saved.")
        except OSError as exc:
            self.log.error("Could not save settings: %s", exc)
            messagebox.showerror("Save failed", str(exc))

    def _on_close(self):
        try:
            self._save_config()
        finally:
            if self._pdf_tmpdir:
                shutil.rmtree(self._pdf_tmpdir, ignore_errors=True)
            self.root.destroy()

    # ------------------------------------------------------------------ logging
    def _setup_logging(self):
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)
        fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")

        if not any(getattr(h, "_ptab_gui", False) for h in root_logger.handlers):
            qh = QueueLogHandler(self._log_queue)
            qh.setFormatter(fmt)
            qh.setLevel(getattr(logging, self._config.get("log_level", "INFO"), logging.INFO))
            qh._ptab_gui = True
            root_logger.addHandler(qh)
            self._queue_handler = qh

            try:
                fh = logging.handlers.RotatingFileHandler(
                    LOG_PATH, maxBytes=1_000_000, backupCount=5, encoding="utf-8")
                fh.setFormatter(fmt)
                fh.setLevel(logging.DEBUG)
                fh._ptab_gui = True
                root_logger.addHandler(fh)
            except OSError as exc:
                self.log.warning("File logging disabled (%s)", exc)
        else:
            self._queue_handler = next(
                (h for h in root_logger.handlers
                 if getattr(h, "_ptab_gui", False) and isinstance(h, QueueLogHandler)), None)

    def _on_tk_exception(self, exc, val, tb):
        self.log.exception("Unhandled Tk callback error", exc_info=(exc, val, tb))

    # ------------------------------------------------------------------ layout
    def _build_notebook(self):
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=8, pady=(8, 4))
        self._build_lookup_tab(self.nb)      # index 0 — keep first (nb.select(0) relies on it)
        self._build_search_tab(self.nb)
        self._build_litigation_tab(self.nb)
        self._build_logs_tab(self.nb)
        self._build_settings_tab(self.nb)

    def _build_lookup_tab(self, nb: ttk.Notebook):
        tab = ttk.Frame(nb)
        nb.add(tab, text="Lookup by trial #")

        top = ttk.Frame(tab)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="Trial number:").pack(side="left")
        self.trial_var = tk.StringVar(value="IPR2026-00341")
        entry = ttk.Entry(top, textvariable=self.trial_var, width=22)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda _e: self.on_proceeding())
        Tooltip(entry, "PTAB trial number, e.g. IPR2023-01234 / PGR2024-00012")

        self._lookup_buttons = [
            ttk.Button(top, text="Proceeding", command=self.on_proceeding),
            ttk.Button(top, text="Documents", command=self.on_documents),
            ttk.Button(top, text="Decisions", command=self.on_decisions),
            ttk.Button(top, text="Counsel", command=self.on_counsel),
        ]
        for b in self._lookup_buttons:
            b.pack(side="left", padx=3)
        Tooltip(self._lookup_buttons[1], "Double-click a document row (or select it and Open PDF) "
                                         "to download and open the PDF.")
        Tooltip(self._lookup_buttons[3], "Downloads the case PDFs and parses the attorney roster. "
                                         "Needs pdftotext (poppler) installed.")

        self.lookup_pane = ResultPane(tab, on_row_open=self._open_pdf_from_meta)
        self.lookup_pane.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        bottom = ttk.Frame(tab)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        self.open_pdf_btn = ttk.Button(bottom, text="Open PDF", command=self._open_selected_pdf,
                                       state="disabled")
        self.open_pdf_btn.pack(side="left")
        Tooltip(self.open_pdf_btn, "Open the selected row's PDF (Documents, Decisions & Counsel source docs).")
        ttk.Button(bottom, text="Save JSON…",
                   command=lambda: self._save_json(self.lookup_pane.payload)).pack(side="right")

    def _build_search_tab(self, nb: ttk.Notebook):
        tab = ttk.Frame(nb)
        nb.add(tab, text="Search proceedings")

        form = ttk.LabelFrame(tab, text="Filters")
        form.pack(fill="x", padx=8, pady=8)

        self.search_vars = {k: tk.StringVar() for k in (
            "search", "petitioner", "patent_owner", "patent", "application",
            "type", "status", "filed_after", "filed_before", "offset", "limit",
            "sort_field", "sort_order")}
        self.search_vars["offset"].set("0")
        self.search_vars["limit"].set(self._config.get("limit", "25"))
        self.search_vars["sort_field"].set(self._config.get("sort_field", _DEFAULTS["sort_field"]))
        self.search_vars["sort_order"].set(self._config.get("sort_order", "desc"))

        def field(row, col, label, key, width=20, hint="", combo=None, readonly=False):
            ttk.Label(form, text=label).grid(row=row, column=col, sticky="e", padx=(8, 3), pady=3)
            if combo is not None:
                w = ttk.Combobox(form, textvariable=self.search_vars[key], width=width - 2,
                                 values=combo, state="readonly" if readonly else "normal")
            else:
                w = ttk.Entry(form, textvariable=self.search_vars[key], width=width)
            w.grid(row=row, column=col + 1, sticky="w", padx=(0, 8), pady=3)
            if hint:
                Tooltip(w, hint)
            return w

        field(0, 0, "Free text:", "search", width=28,
              hint="Searched across the proceeding (trial number, patent, party names).")
        field(0, 2, "Type:", "type", width=10, combo=["", "IPR", "PGR", "CBM", "DER"], readonly=True,
              hint="Inter Partes Review / Post-Grant / Covered Business Method / Derivation.")
        field(0, 4, "Status:", "status", width=24,
              combo=[""] + list(ptab.PROCEEDING_STATUSES), readonly=True,
              hint="ODP trialStatusCategory value.")

        field(1, 0, "Petitioner:", "petitioner", width=28, hint="Company or party name, e.g. Apple Inc.")
        field(1, 2, "Patent owner:", "patent_owner", width=28, hint="Company or party name.")

        field(2, 0, "Patent #:", "patent", width=18, hint="e.g. 10123456 (exact match).")
        field(2, 2, "Application #:", "application", width=18, hint="e.g. 17123456 (exact match).")

        field(3, 0, "Filed after:", "filed_after", width=18, hint="Petition filed on/after (YYYY-MM-DD).")
        field(3, 2, "Filed before:", "filed_before", width=18, hint="Petition filed on/before (YYYY-MM-DD).")

        field(4, 0, "Sort by:", "sort_field", width=30, combo=list(ptab.PROCEEDING_SORT_FIELDS),
              readonly=True, hint="ODP sort field.")
        field(4, 2, "Order:", "sort_order", width=8, combo=["desc", "asc"], readonly=True)
        ttk.Label(form, text="Limit:").grid(row=4, column=4, sticky="e", padx=(8, 3))
        limit_e = ttk.Entry(form, textvariable=self.search_vars["limit"], width=8)
        limit_e.grid(row=4, column=5, sticky="w", padx=(0, 8))
        Tooltip(limit_e, "Results per page (page size).")

        actions = ttk.Frame(tab)
        actions.pack(fill="x", padx=8)
        self.search_btn = ttk.Button(actions, text="Search", command=self._new_search)
        self.search_btn.pack(side="left")
        ttk.Button(actions, text="Clear filters", command=self._clear_search).pack(side="left", padx=6)
        ttk.Button(actions, text="Bulk names…", command=self._open_ptab_bulk).pack(side="left")

        self.prev_btn = ttk.Button(actions, text="◀ Prev", command=self._prev_page, state="disabled")
        self.prev_btn.pack(side="left", padx=(12, 2))
        self.next_btn = ttk.Button(actions, text="Next ▶", command=self._next_page, state="disabled")
        self.next_btn.pack(side="left", padx=2)
        self.page_var = tk.StringVar(value="")
        ttk.Label(actions, textvariable=self.page_var, foreground="#555").pack(side="left", padx=8)

        self.incl_filters_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(actions, text="Include applied filters in export",
                        variable=self.incl_filters_var).pack(side="right")
        ttk.Button(actions, text="Export JSON…", command=lambda: self._export_search("json")).pack(
            side="right", padx=(6, 8))
        ttk.Button(actions, text="Export CSV…", command=lambda: self._export_search("csv")).pack(side="right")

        ttk.Label(tab, foreground="#666",
                  text="Tip: double-click a result row to open it in the Lookup tab. Click a column "
                       "header to sort; right-click to copy. Multi-word party names are phrase-matched."
                  ).pack(fill="x", padx=8, pady=(4, 0))

        self.search_pane = ResultPane(tab, on_row_open=self._open_proceeding_from_row)
        self.search_pane.pack(fill="both", expand=True, padx=8, pady=(4, 8))

    def _build_litigation_tab(self, nb: ttk.Notebook):
        tab = ttk.Frame(nb)
        nb.add(tab, text="Litigation")

        form = ttk.LabelFrame(tab, text="Filters — source: CourtListener / RECAP (free court data)")
        form.pack(fill="x", padx=8, pady=8)

        self.lit_vars = {k: tk.StringVar() for k in (
            "source", "case", "court", "cause", "plaintiff", "defendant", "judge",
            "search", "filed_after", "filed_before", "status")}
        self.lit_vars["source"].set("District Court")
        self.lit_vars["cause"].set(litigation.PATENT_NATURE_OF_SUIT)
        self.lit_vars["status"].set("Any")

        def field(row, col, label, key, width=20, hint="", combo=None, readonly=False):
            ttk.Label(form, text=label).grid(row=row, column=col, sticky="e", padx=(8, 3), pady=3)
            if combo is not None:
                w = ttk.Combobox(form, textvariable=self.lit_vars[key], width=width - 2,
                                 values=combo, state="readonly" if readonly else "normal")
            else:
                w = ttk.Entry(form, textvariable=self.lit_vars[key], width=width)
            w.grid(row=row, column=col + 1, sticky="w", padx=(0, 8), pady=3)
            if hint:
                Tooltip(w, hint)
            return w

        field(0, 0, "Source:", "source", width=26, combo=list(litigation.SOURCES), readonly=True,
              hint="District Court relies on nature-of-suit; ITC 337 is not in CourtListener.")
        field(0, 2, "Status:", "status", width=10, combo=["Any", "Open", "Closed"], readonly=True,
              hint="Filtered client-side (Open = no termination date).")
        field(0, 4, "Cause of action:", "cause", width=16,
              hint="Nature-of-suit code (830 = Patent) or free-text cause.")

        field(1, 0, "Case #:", "case", width=26, hint="Docket number, e.g. 2:26-cv-00508.")
        ttk.Label(form, text="Court:").grid(row=1, column=2, sticky="e", padx=(8, 3), pady=3)
        court_cell = ttk.Frame(form)
        court_cell.grid(row=1, column=3, sticky="w", padx=(0, 8), pady=3)
        court_e = ttk.Entry(court_cell, textvariable=self.lit_vars["court"], width=9)
        court_e.pack(side="left")
        Tooltip(court_e, "Type a court id (e.g. txed), or click Pick… to choose by name.")
        ttk.Button(court_cell, text="Pick…", width=5, command=self._open_court_picker).pack(side="left", padx=3)
        field(1, 4, "Judge:", "judge", width=16, hint="Assigned judge name.")

        field(2, 0, "Plaintiff:", "plaintiff", width=26, hint="Party name (narrows on party).")
        field(2, 2, "Defendant:", "defendant", width=26, hint="Party name (narrows on party).")

        field(3, 0, "Filed after:", "filed_after", width=16, hint="YYYY-MM-DD.")
        field(3, 2, "Filed before:", "filed_before", width=16, hint="YYYY-MM-DD.")
        field(3, 4, "Free text:", "search", width=16, hint="Full-text search across the docket.")

        ttk.Label(form, text="(results paginate 20 per page — use Prev/Next)",
                  foreground="#888").grid(row=4, column=0, columnspan=4, sticky="w", padx=8, pady=(2, 0))

        actions = ttk.Frame(tab)
        actions.pack(fill="x", padx=8)
        self.lit_search_btn = ttk.Button(actions, text="Search cases", command=self.on_litigation_search)
        self.lit_search_btn.pack(side="left")
        ttk.Button(actions, text="Clear", command=self._clear_lit).pack(side="left", padx=6)
        ttk.Button(actions, text="Bulk names…", command=self._open_lit_bulk).pack(side="left")
        self.lit_prev_btn = ttk.Button(actions, text="◀ Prev", command=self._lit_prev, state="disabled")
        self.lit_prev_btn.pack(side="left", padx=(12, 2))
        self.lit_next_btn = ttk.Button(actions, text="Next ▶", command=self._lit_next, state="disabled")
        self.lit_next_btn.pack(side="left", padx=2)
        self.lit_page_var = tk.StringVar(value="")
        ttk.Label(actions, textvariable=self.lit_page_var, foreground="#555").pack(side="left", padx=8)

        ttk.Button(actions, text="Export JSON…",
                   command=lambda: self._export_pane(self.lit_pane, "json")).pack(side="right", padx=(6, 8))
        ttk.Button(actions, text="Export CSV…",
                   command=lambda: self._export_pane(self.lit_pane, "csv")).pack(side="right")

        ttk.Label(tab, foreground="#666",
                  text="Double-click a case for details (accurate parties by side + judge; needs a token). "
                       "Entity Type / Industry / NPE Aggregator / Financing are proprietary (Unified/Lex "
                       "Machina) and stay blank here."
                  ).pack(fill="x", padx=8, pady=(4, 0))

        self.lit_pane = ResultPane(tab, on_row_open=self._show_case_details)
        self.lit_pane.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self._lit_next_url: Optional[str] = None
        self._lit_prev_url: Optional[str] = None
        self._courts_cache: list[dict] = []

    def _build_logs_tab(self, nb: ttk.Notebook):
        tab = ttk.Frame(nb)
        nb.add(tab, text="Logs")

        bar = ttk.Frame(tab)
        bar.pack(fill="x", padx=8, pady=8)
        ttk.Label(bar, text="Level:").pack(side="left")
        self.log_level_var = tk.StringVar(value=self._config.get("log_level", "INFO"))
        lvl = ttk.Combobox(bar, textvariable=self.log_level_var, width=10, state="readonly",
                           values=["DEBUG", "INFO", "WARNING", "ERROR"])
        lvl.pack(side="left", padx=6)
        lvl.bind("<<ComboboxSelected>>", lambda _e: self._apply_log_level())
        self.autoscroll_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text="Autoscroll", variable=self.autoscroll_var).pack(side="left", padx=6)
        ttk.Button(bar, text="Clear", command=self._clear_log_view).pack(side="left", padx=6)
        ttk.Button(bar, text="Open log file", command=lambda: _open_path(LOG_PATH)).pack(side="right")
        ttk.Button(bar, text="Open logs folder", command=lambda: _open_path(DATA_DIR)).pack(
            side="right", padx=6)

        self.log_text = scrolledtext.ScrolledText(tab, wrap="word", state="disabled",
                                                  font=("Courier", 9))
        self.log_text.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        for lvl_name, color in (("WARNING", "#a06000"), ("ERROR", "#b00020"), ("CRITICAL", "#b00020")):
            self.log_text.tag_config(lvl_name, foreground=color)

    def _build_settings_tab(self, nb: ttk.Notebook):
        tab = ttk.Frame(nb)
        nb.add(tab, text="Settings")

        conn = ttk.LabelFrame(tab, text="ODP connection")
        conn.pack(fill="x", padx=8, pady=8)
        ttk.Label(conn, text="API key:").grid(row=0, column=0, sticky="w", padx=(8, 4), pady=6)
        self.api_key_var = tk.StringVar(value=os.environ.get("USPTO_ODP_API_KEY", ""))
        self.api_key_entry = ttk.Entry(conn, textvariable=self.api_key_var, show="•", width=46)
        self.api_key_entry.grid(row=0, column=1, columnspan=3, sticky="we", pady=6)
        Tooltip(self.api_key_entry, "Your USPTO ODP API key. Defaults from USPTO_ODP_API_KEY. "
                                    "NOT saved to disk — re-enter it or set the env var each session.")
        self.show_key_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(conn, text="show", variable=self.show_key_var,
                        command=self._toggle_key).grid(row=0, column=4, padx=6)

        ttk.Label(conn, text="Base URL:").grid(row=1, column=0, sticky="w", padx=(8, 4))
        self.base_url_var = tk.StringVar(value=self._config.get("base_url", ptab.DEFAULT_BASE_URL))
        ttk.Entry(conn, textvariable=self.base_url_var, width=46).grid(
            row=1, column=1, columnspan=3, sticky="we", pady=6)
        conn.columnconfigure(1, weight=1)
        self.api_key_var.trace_add("write", lambda *_: self._refresh_conn_state())

        cl = ttk.LabelFrame(tab, text="CourtListener (litigation)")
        cl.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Label(cl, text="API token:").grid(row=0, column=0, sticky="w", padx=(8, 4), pady=6)
        self.cl_token_var = tk.StringVar(value=os.environ.get("COURTLISTENER_API_TOKEN", ""))
        self.cl_token_entry = ttk.Entry(cl, textvariable=self.cl_token_var, show="•", width=46)
        self.cl_token_entry.grid(row=0, column=1, columnspan=3, sticky="we", pady=6)
        Tooltip(self.cl_token_entry, "Free CourtListener token from courtlistener.com/profile. "
                                     "Defaults from COURTLISTENER_API_TOKEN. NOT saved to disk.")
        self.cl_show_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(cl, text="show", variable=self.cl_show_var,
                        command=lambda: self.cl_token_entry.configure(
                            show="" if self.cl_show_var.get() else "•")).grid(row=0, column=4, padx=6)
        ttk.Label(cl, text="Base URL:").grid(row=1, column=0, sticky="w", padx=(8, 4))
        self.cl_base_url_var = tk.StringVar(value=litigation.DEFAULT_BASE_URL)
        ttk.Entry(cl, textvariable=self.cl_base_url_var, width=46).grid(
            row=1, column=1, columnspan=3, sticky="we", pady=6)
        cl.columnconfigure(1, weight=1)

        tune = ttk.LabelFrame(tab, text="Requests")
        tune.pack(fill="x", padx=8, pady=(0, 8))
        self.timeout_var = tk.StringVar(value=str(self._config.get("timeout", "30")))
        self.retries_var = tk.StringVar(value=str(self._config.get("max_retries", "3")))
        self.backoff_var = tk.StringVar(value=str(self._config.get("backoff_base", "2")))
        for c, (lbl, var, hint) in enumerate((
                ("Timeout (s):", self.timeout_var, "Per-request timeout in seconds."),
                ("Max retries:", self.retries_var, "Retries on HTTP 429 (rate limit)."),
                ("Backoff base (s):", self.backoff_var, "Exponential backoff base between retries."))):
            ttk.Label(tune, text=lbl).grid(row=0, column=c * 2, sticky="e", padx=(8, 3), pady=6)
            e = ttk.Entry(tune, textvariable=var, width=8)
            e.grid(row=0, column=c * 2 + 1, sticky="w", padx=(0, 8))
            Tooltip(e, hint)

        misc = ttk.LabelFrame(tab, text="Behavior")
        misc.pack(fill="x", padx=8, pady=(0, 8))
        self.open_pdf_var = tk.BooleanVar(value=bool(self._config.get("open_pdf", True)))
        ttk.Checkbutton(misc, text="Open PDFs automatically after download",
                        variable=self.open_pdf_var).grid(row=0, column=0, sticky="w", padx=8, pady=6)
        self.capability_var = tk.StringVar(value=self._probe_pdftotext())
        ttk.Label(misc, textvariable=self.capability_var, foreground="#555").grid(
            row=1, column=0, sticky="w", padx=8, pady=(0, 6))

        btns = ttk.Frame(tab)
        btns.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(btns, text="Save settings", command=self._save_config).pack(side="left")
        ttk.Label(tab, foreground="#666",
                  text=f"Non-secret settings are saved to {CONFIG_PATH}\nThe API key is never written "
                       f"to disk.").pack(anchor="w", padx=8)

    def _build_statusbar(self):
        self.status_var = tk.StringVar(value="Ready.")
        status = ttk.Frame(self.root)
        status.pack(fill="x", side="bottom")
        self.conn_var = tk.StringVar(value="")
        self.conn_label = ttk.Label(status, textvariable=self.conn_var)
        self.conn_label.pack(side="left", padx=8)
        ttk.Separator(status, orient="vertical").pack(side="left", fill="y", pady=2)
        self.progress = ttk.Progressbar(status, mode="indeterminate", length=120)
        self.progress.pack(side="right", padx=8, pady=4)
        ttk.Label(status, textvariable=self.status_var, anchor="w").pack(
            side="left", fill="x", expand=True, padx=8)
        self._refresh_conn_state()

    # ------------------------------------------------------------------ helpers
    def _toggle_key(self):
        self.api_key_entry.configure(show="" if self.show_key_var.get() else "•")

    def _refresh_conn_state(self):
        if self.api_key_var.get().strip():
            host = (self.base_url_var.get() or "").split("//")[-1].split("/")[0]
            self.conn_var.set(f"● API key set • {host}")
            self.conn_label.configure(foreground="#1a7a1a")
        else:
            self.conn_var.set("● No API key")
            self.conn_label.configure(foreground="#b00020")

    def _probe_pdftotext(self) -> str:
        try:
            subprocess.run(["pdftotext", "-v"], capture_output=True, timeout=5)
            return "Counsel extraction: pdftotext found ✓"
        except (FileNotFoundError, subprocess.SubprocessError):
            try:
                import pdfplumber  # noqa: F401
                return "Counsel extraction: using pdfplumber fallback"
            except Exception:
                return "Counsel extraction: no pdftotext/pdfplumber — install poppler-utils"

    def _client(self) -> ptab.OdpClient:
        def _int(var, default):
            try:
                return int(float(var.get()))
            except (ValueError, AttributeError):
                return default
        return ptab.OdpClient(
            api_key=self.api_key_var.get().strip(),
            base_url=self.base_url_var.get().strip(),
            timeout=_int(self.timeout_var, 30),
            max_retries=_int(self.retries_var, 3),
            backoff_base=_int(self.backoff_var, 2),
        )

    def _apply_log_level(self):
        level = getattr(logging, self.log_level_var.get(), logging.INFO)
        if getattr(self, "_queue_handler", None):
            self._queue_handler.setLevel(level)
        self.log.info("Log level set to %s", self.log_level_var.get())

    # -- busy + spinner --
    def _set_busy(self, busy: bool, msg: str = ""):
        self._busy = busy
        state = "disabled" if busy else "normal"
        for b in self._lookup_buttons:
            b.configure(state=state)
        self.search_btn.configure(state=state)
        if getattr(self, "lit_search_btn", None):
            self.lit_search_btn.configure(state=state)
        if busy:
            self.progress.start(12)
            self._busy_msg = msg or "Working…"
            if self._spin_after is None:
                self._spin()
        else:
            self.progress.stop()
            if self._spin_after is not None:
                self.root.after_cancel(self._spin_after)
                self._spin_after = None
            self.status_var.set(msg or "Ready.")

    def _spin(self):
        frame = self.SPINNER[self._spin_frame % len(self.SPINNER)]
        self.status_var.set(f"{frame} {self._busy_msg}")
        self._spin_frame += 1
        self._spin_after = self.root.after(120, self._spin)

    def _run_async(self, work: Callable[[], Any], on_done: Callable[[Any], None], busy_msg: str,
                   has_credential: Optional[bool] = None, credential_label: str = "ODP API key"):
        if self._busy:
            return
        missing = (not self.api_key_var.get().strip()) if has_credential is None else (not has_credential)
        if missing:
            if not messagebox.askyesno("No credential",
                                       f"No {credential_label} set — the request will likely fail.\n"
                                       "Continue anyway?"):
                return
        self.log.info(busy_msg)
        self._set_busy(True, busy_msg)

        def worker():
            try:
                result = work()
                self._results.put((self._deliver, (on_done, result, None)))
            except Exception as exc:  # noqa: BLE001 — surface any failure to the UI
                self._results.put((self._deliver, (on_done, None, exc)))

        threading.Thread(target=worker, daemon=True).start()

    def _deliver(self, on_done, result, exc):
        if exc is not None:
            self.log.error("Request failed: %s", exc)
            self._set_busy(False, "Error.")
            messagebox.showerror("Request failed", str(exc))
            return
        self._set_busy(False, "Done.")
        on_done(result)

    def _drain_queue(self):
        try:
            while True:
                fn, args = self._results.get_nowait()
                fn(*args)
        except queue.Empty:
            pass
        try:
            while True:
                msg, level = self._log_queue.get_nowait()
                self._append_log(msg, level)
        except queue.Empty:
            pass
        self.root.after(100, self._drain_queue)

    def _append_log(self, msg: str, level: str):
        self.log_text.configure(state="normal")
        tag = level if level in ("WARNING", "ERROR", "CRITICAL") else ""
        self.log_text.insert("end", msg + "\n", tag)
        if self.autoscroll_var.get():
            self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _clear_log_view(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _trial(self) -> str:
        t = self.trial_var.get().strip()
        if not t:
            messagebox.showwarning("Missing trial number", "Enter a trial number (e.g. IPR2026-00341).")
        return t

    # ------------------------------------------------------------------ lookup actions
    def on_proceeding(self):
        trial = self._trial()
        if not trial:
            return
        svc = ptab.TrialService(self._client())

        def done(proc):
            self.open_pdf_btn.configure(state="disabled")
            if not proc:
                self.lookup_pane.show_table(["field", "value"], [], None,
                                            count_label=f"No results for {trial}",
                                            empty_hint="Proceeding not found.")
                self.status_var.set(f"No results for {trial}.")
                self.log.info("No proceeding found for %s", trial)
                return
            flat = ptab.flatten_proceeding(proc)
            self.lookup_pane.show_table(["field", "value"], [[k, v] for k, v in flat.items()],
                                        proc, count_label=f"{trial}")

        self._run_async(lambda: svc.get_proceeding(trial), done, f"Fetching {trial}…")

    def on_documents(self):
        trial = self._trial()
        if not trial:
            return
        svc = ptab.TrialService(self._client())

        def done(resp):
            docs = (resp or {}).get("patentTrialDocumentDataBag") or []
            rows, meta = [], []
            for d in docs:
                dd = d.get("documentData") or {}
                rows.append([dd.get("documentFilingDate"), dd.get("documentCategory"),
                             dd.get("filingPartyCategory"),
                             dd.get("documentTitleText") or dd.get("documentName")])
                meta.append(dd)
            self.lookup_pane.show_table(["filed", "category", "party", "title"], rows, resp,
                                        row_meta=meta, count_label=f"{len(rows)} document(s)",
                                        empty_hint="No documents for this trial.")
            self.open_pdf_btn.configure(state="normal" if rows else "disabled")

        self._run_async(lambda: svc.get_trial_documents(trial), done, f"Fetching documents for {trial}…")

    def on_decisions(self):
        trial = self._trial()
        if not trial:
            return
        svc = ptab.TrialService(self._client())

        def done(resp):
            items = (resp or {}).get("patentTrialDocumentDataBag") \
                or (resp or {}).get("patentTrialDecisionDataBag") or []
            rows, meta = [], []
            for it in items:
                dd = it.get("documentData") or {}
                dec = it.get("decisionData") or {}
                rows.append([dd.get("documentFilingDate") or dec.get("decisionIssueDate"),
                             dd.get("documentTypeDescriptionText") or dec.get("decisionTypeCategory"),
                             dd.get("filingPartyCategory"),
                             dd.get("documentTitleText") or dd.get("documentName"),
                             dec.get("trialOutcomeCategory")])
                meta.append(dd)
            self.lookup_pane.show_table(["filed", "code", "party", "title", "outcome"], rows, resp,
                                        row_meta=meta, count_label=f"{len(rows)} decision(s)",
                                        empty_hint="No decisions for this trial.")
            has_pdf = any(m.get("fileDownloadURI") for m in meta)
            self.open_pdf_btn.configure(state="normal" if has_pdf else "disabled")

        self._run_async(lambda: svc.get_proceeding_decisions(trial), done, f"Fetching decisions for {trial}…")

    def on_counsel(self):
        trial = self._trial()
        if not trial:
            return
        svc = ptab.TrialService(self._client())

        def done(counsel):
            cols = ["side", "role", "name", "reg #", "firm", "email", "phone", "pro hac", "source"]
            rows, meta = [], []
            for c in counsel:
                rows.append([c["side"], c["role"], c["name"], c["registration_number"],
                             c["firm_name"], c["email"], c["phone"],
                             "yes" if c.get("pro_hac") else "",
                             c.get("source_document_name", "")])
                # Source doc only opens if a download URI is present in the counsel record.
                meta.append({"fileDownloadURI": c.get("source_document_uri"),
                             "documentName": c.get("source_document_name")})
            self.lookup_pane.show_table(cols, rows, counsel, row_meta=meta,
                                        count_label=f"{len(rows)} attorney(s)",
                                        empty_hint="No counsel extracted.")
            has_src = any(m.get("fileDownloadURI") for m in meta)
            self.open_pdf_btn.configure(state="normal" if has_src else "disabled")
            if not counsel:
                self.status_var.set("No counsel extracted (check pdftotext is installed).")
                self.log.warning("No counsel extracted for %s", trial)

        self._run_async(lambda: ptab.resolve_counsel(trial, svc), done,
                        f"Downloading & parsing PDFs for {trial}…")

    # ------------------------------------------------------------------ PDF open
    def _open_selected_pdf(self):
        sel = self.lookup_pane.tree.selection()
        if not sel:
            messagebox.showinfo("No selection", "Select a document/decision row first.")
            return
        idx = self.lookup_pane.tree.index(sel[0])
        metas = self.lookup_pane._row_meta
        if 0 <= idx < len(metas) and metas[idx]:
            self._open_pdf_from_meta(metas[idx])
        else:
            messagebox.showinfo("Not a document", "This row has no downloadable PDF.")

    def _open_pdf_from_meta(self, dd: Any):
        if not isinstance(dd, dict) or not dd.get("fileDownloadURI"):
            return
        uri = dd["fileDownloadURI"]
        name = (dd.get("documentName") or dd.get("documentIdentifier") or "document")
        safe = "".join(c if c.isalnum() or c in "-._" else "_" for c in str(name))[:80] or "document"
        ident = str(dd.get("documentIdentifier") or "")[:16]
        client = self._client()
        auto_open = self.open_pdf_var.get()

        def work():
            data = ptab.download_document_pdf(client, uri)
            if not self._pdf_tmpdir:
                self._pdf_tmpdir = tempfile.mkdtemp(prefix="ptab_pdfs_")
            path = os.path.join(self._pdf_tmpdir, f"{ident}_{safe}.pdf")
            with open(path, "wb") as fh:
                fh.write(data)
            return path

        def done(path):
            self.log.info("Downloaded PDF → %s", path)
            if auto_open:
                _open_path(path)
                self.status_var.set(f"Opened {path}")
            else:
                self.status_var.set(f"Saved {path}")

        self._run_async(work, done, f"Downloading {name}…")

    # ------------------------------------------------------------------ search
    def _build_search_body(self) -> dict:
        try:
            offset = max(0, int(self.search_vars["offset"].get() or 0))
            limit = int(self.search_vars["limit"].get() or 25)
        except ValueError:
            raise ValueError("Offset and Limit must be integers.")
        if limit < 1:
            raise ValueError("Limit must be at least 1.")
        return ptab.build_proceeding_search(
            search=self.search_vars["search"].get().strip(),
            petitioner_name=self.search_vars["petitioner"].get().strip(),
            patent_owner_name=self.search_vars["patent_owner"].get().strip(),
            patent_number=self.search_vars["patent"].get().strip(),
            application_number=self.search_vars["application"].get().strip(),
            proceeding_type=self.search_vars["type"].get().strip(),
            status=self.search_vars["status"].get().strip(),
            filed_after=self.search_vars["filed_after"].get().strip(),
            filed_before=self.search_vars["filed_before"].get().strip(),
            sort_field=self.search_vars["sort_field"].get().strip(),
            sort_order=self.search_vars["sort_order"].get().strip(),
            offset=offset, limit=limit,
        )

    def on_search(self):
        try:
            body = self._build_search_body()
        except ValueError as exc:
            messagebox.showwarning("Invalid input", str(exc))
            return
        self._last_search_body = body
        svc = ptab.TrialService(self._client())

        def done(resp):
            records = ptab.extract_proceedings(resp)
            self._last_result_count = len(records)
            cols = ["trial #", "type", "status", "patent #", "petitioner", "patent owner",
                    "filed", "institution", "decision"]
            rows, meta = [], []
            for rec in records:
                s = ptab.summarize_proceeding(rec)
                rows.append([s["trial_number"], s["type"], s["status"], s["patent_number"],
                             s["petitioner"], s["patent_owner"], s["filing_date"],
                             s["institution_date"], s["decision_date"]])
                meta.append(rec)
            self.search_pane.show_table(cols, rows, resp, row_meta=meta,
                                        count_label=f"{len(rows)} result(s)",
                                        empty_hint="No proceedings match these filters.")
            self._update_pagination()

        self._run_async(lambda: svc.search_proceedings(body), done, "Searching proceedings…")

    def _update_pagination(self):
        offset = int(self._last_search_body.get("pagination", {}).get("offset", 0))
        limit = int(self._last_search_body.get("pagination", {}).get("limit", 25))
        n = self._last_result_count
        if n:
            self.page_var.set(f"showing {offset + 1}–{offset + n}")
        else:
            self.page_var.set("no results")
        self.prev_btn.configure(state="normal" if offset > 0 else "disabled")
        # Full page → assume there may be more; short page → last page.
        self.next_btn.configure(state="normal" if n >= limit and n > 0 else "disabled")

    @staticmethod
    def _safe_int(value: str, default: int) -> int:
        try:
            return int(float(str(value).strip()))
        except (ValueError, TypeError):
            return default

    def _new_search(self):
        """Search button: start from page 1 so a changed filter doesn't inherit a stale offset."""
        self.search_vars["offset"].set("0")
        self.on_search()

    def _prev_page(self):
        offset = self._safe_int(self.search_vars["offset"].get(), 0)
        limit = self._safe_int(self.search_vars["limit"].get(), 25)
        self.search_vars["offset"].set(str(max(0, offset - limit)))
        self.on_search()

    def _next_page(self):
        offset = self._safe_int(self.search_vars["offset"].get(), 0)
        limit = self._safe_int(self.search_vars["limit"].get(), 25)
        self.search_vars["offset"].set(str(offset + limit))
        self.on_search()

    def _clear_search(self):
        defaults = {"offset": "0", "limit": self._config.get("limit", "25"),
                    "sort_field": self._config.get("sort_field", _DEFAULTS["sort_field"]),
                    "sort_order": self._config.get("sort_order", "desc")}
        for k, v in self.search_vars.items():
            v.set(defaults.get(k, ""))
        self.page_var.set("")
        self.prev_btn.configure(state="disabled")
        self.next_btn.configure(state="disabled")

    def _open_proceeding_from_row(self, record: Any):
        trial = str((record or {}).get("trialNumber")
                    or ptab.summarize_proceeding(record or {}).get("trial_number") or "").strip()
        if not trial:
            return
        self.trial_var.set(trial)
        self.nb.select(0)  # Lookup tab
        self.on_proceeding()

    # ------------------------------------------------------------------ bulk name runners
    def _open_ptab_bulk(self):
        def run_one(name, search_as, client):
            key = "petitioner_name" if search_as == "Petitioner" else "patent_owner_name"
            body = ptab.build_proceeding_search(limit=50, **{key: name})
            resp = ptab.TrialService(client).search_proceedings(body)
            return [ptab.summarize_proceeding(r) for r in ptab.extract_proceedings(resp)]

        BulkDialog(
            self, "Bulk PTAB proceeding search", ["Petitioner", "Patent owner"], run_one,
            [("Trial #", "trial_number"), ("Type", "type"), ("Status", "status"),
             ("Patent #", "patent_number"), ("Petitioner", "petitioner"),
             ("Patent owner", "patent_owner"), ("Filed", "filing_date")],
            client_factory=self._client, credential_label="ODP API key",
            has_credential=lambda: bool(self.api_key_var.get().strip()), pace_seconds=0)

    def _open_lit_bulk(self):
        # Capture the tab's source/cause now, on the main thread (run_one runs on a worker thread).
        source = self.lit_vars["source"].get()
        cause = self.lit_vars["cause"].get().strip()

        def run_one(name, search_as, client):
            # CourtListener free search can't distinguish party side, so the query narrows on the
            # party name and side is inferred from the "X v. Y" caption. When the caption doesn't
            # split into two sides we can't tell — keep the case (lenient) rather than silently drop it.
            query = litigation.build_case_query(source=source, cause_of_action=cause, plaintiff=name)
            resp = litigation.search_cases(query, client)
            litigation.strip_nested_documents(resp)
            cases = [litigation.summarize_case(c) for c in litigation.extract_cases(resp)]
            if search_as in ("Plaintiff", "Defendant"):
                low = name.lower()
                key = "plaintiff" if search_as == "Plaintiff" else "defendant"
                cases = [c for c in cases
                         if low in (c[key] or "").lower()
                         or not (c["plaintiff"] and c["defendant"])]  # caption side undetermined
            return cases

        BulkDialog(
            self, "Bulk litigation search (CourtListener)", ["Plaintiff", "Defendant", "Either party"],
            run_one,
            [("Case", "case_number"), ("Filed", "filing_date"), ("Status", "status"),
             ("Court", "court"), ("Plaintiff", "plaintiff"), ("Defendant", "defendant"),
             ("Cause", "cause_of_action")],
            client_factory=self._cl_client, credential_label="CourtListener API token",
            has_credential=lambda: bool(self.cl_token_var.get().strip()), pace_seconds=2)

    # ------------------------------------------------------------------ litigation
    def _cl_client(self) -> litigation.CourtListenerClient:
        def _int(var, default):
            try:
                return int(float(var.get()))
            except (ValueError, AttributeError):
                return default
        return litigation.CourtListenerClient(
            api_token=self.cl_token_var.get().strip(),
            base_url=self.cl_base_url_var.get().strip(),
            # CourtListener is slow; never go below 60s even if the shared ODP timeout is lower.
            timeout=max(_int(self.timeout_var, 60), 60),
            max_retries=_int(self.retries_var, 3),
            backoff_base=_int(self.backoff_var, 2),
        )

    def on_litigation_search(self):
        query = litigation.build_case_query(
            source=self.lit_vars["source"].get(),
            case_number=self.lit_vars["case"].get().strip(),
            court=self.lit_vars["court"].get().strip(),
            cause_of_action=self.lit_vars["cause"].get().strip(),
            plaintiff=self.lit_vars["plaintiff"].get().strip(),
            defendant=self.lit_vars["defendant"].get().strip(),
            judge=self.lit_vars["judge"].get().strip(),
            search=self.lit_vars["search"].get().strip(),
            filed_after=self.lit_vars["filed_after"].get().strip(),
            filed_before=self.lit_vars["filed_before"].get().strip(),
        )
        client = self._cl_client()
        token_present = bool(self.cl_token_var.get().strip())
        self._run_async(lambda: litigation.search_cases(query, client), self._render_litigation,
                        "Searching litigation cases…",
                        has_credential=token_present, credential_label="CourtListener API token")

    def _follow_lit_url(self, url: str):
        client = self._cl_client()
        token_present = bool(self.cl_token_var.get().strip())
        self._run_async(lambda: client.get_url(url), self._render_litigation, "Loading page…",
                        has_credential=token_present, credential_label="CourtListener API token")

    def _render_litigation(self, resp):
        litigation.strip_nested_documents(resp)  # lighter JSON view + export (search ignores field-select)
        records = litigation.extract_cases(resp)
        want = self.lit_vars["status"].get()
        cols = ["Case", "Filed", "Status", "Court", "Plaintiff", "Defendant",
                "Cause of Action", "Pl. Entity Type", "Industry", "Judge"]
        rows, meta = [], []
        for rec in records:
            s = litigation.summarize_case(rec)
            if want in ("Open", "Closed") and s["status"] != want:
                continue
            rows.append([s["case_number"], s["filing_date"], s["status"], s["court"],
                         s["plaintiff"], s["defendant"], s["cause_of_action"],
                         s["plaintiff_entity_type"], s["industry"], s["judge"]])
            meta.append(s)
        self.lit_pane.show_table(cols, rows, resp, row_meta=meta,
                                 count_label=f"{len(rows)} case(s)",
                                 empty_hint="No cases match these filters.")
        self._lit_next_url = (resp or {}).get("next")
        self._lit_prev_url = (resp or {}).get("previous")
        total = (resp or {}).get("count")
        self.lit_page_var.set(f"{total} total match(es)" if total is not None else "")
        self.lit_prev_btn.configure(state="normal" if self._lit_prev_url else "disabled")
        self.lit_next_btn.configure(state="normal" if self._lit_next_url else "disabled")

    def _lit_prev(self):
        if self._lit_prev_url:
            self._follow_lit_url(self._lit_prev_url)

    def _lit_next(self):
        if self._lit_next_url:
            self._follow_lit_url(self._lit_next_url)

    def _clear_lit(self):
        defaults = {"source": "District Court", "cause": litigation.PATENT_NATURE_OF_SUIT,
                    "status": "Any"}
        for k, v in self.lit_vars.items():
            v.set(defaults.get(k, ""))
        self.lit_page_var.set("")
        self.lit_prev_btn.configure(state="disabled")
        self.lit_next_btn.configure(state="disabled")

    def _open_docket_url(self, s: Any):
        url = (s or {}).get("docket_url") or ""
        if not url:
            messagebox.showinfo("No docket link", "This case has no CourtListener docket URL.")
            return
        if url.startswith("/"):
            url = "https://www.courtlistener.com" + url
        webbrowser.open(url)
        self.log.info("Opened docket %s", url)
        self.status_var.set("Opened docket in browser.")

    # -- court picker (courts/ endpoint) --
    def _open_court_picker(self):
        if self._courts_cache:
            self._show_court_picker()
            return
        client = self._cl_client()  # courts/ is an open endpoint (no token needed)

        def done(courts):
            self._courts_cache = courts or []
            if self._courts_cache:
                self._show_court_picker()
            else:
                messagebox.showinfo("No courts", "Could not load the court list.")

        self._run_async(lambda: litigation.list_courts(client), done, "Loading court list…",
                        has_credential=True)  # don't nag about token for this open endpoint

    def _show_court_picker(self):
        win = tk.Toplevel(self.root)
        win.title("Pick a court")
        win.geometry("460x420")
        win.transient(self.root)
        ttk.Label(win, text="Filter:").pack(anchor="w", padx=8, pady=(8, 0))
        filt = tk.StringVar()
        ent = ttk.Entry(win, textvariable=filt)
        ent.pack(fill="x", padx=8)
        ent.focus_set()
        lb = tk.Listbox(win, activestyle="dotbox")
        lb.pack(fill="both", expand=True, padx=8, pady=8)

        shown: list[dict] = []

        def refresh(*_):
            needle = filt.get().lower()
            lb.delete(0, "end")
            shown.clear()
            for c in self._courts_cache:
                if needle in c["full_name"].lower() or needle in c["id"].lower():
                    shown.append(c)
                    lb.insert("end", f'{c["full_name"]}  ({c["id"]})')

        def choose(_evt=None):
            sel = lb.curselection()
            if sel:
                self.lit_vars["court"].set(shown[sel[0]]["id"])
                win.destroy()

        filt.trace_add("write", refresh)
        lb.bind("<Double-1>", choose)
        ttk.Button(win, text="Select", command=choose).pack(side="right", padx=8, pady=(0, 8))
        refresh()

    # -- case details (parties/ + people/ endpoints) --
    def _show_case_details(self, s: Any):
        if not isinstance(s, dict):
            return
        docket_id = s.get("docket_id")
        person_id = s.get("assigned_to_id")
        client = self._cl_client()
        token = bool(self.cl_token_var.get().strip())

        def work():
            parties, judge, err = None, "", ""
            if docket_id:
                try:
                    parties = litigation.get_parties(client, docket_id)
                except litigation.LitigationError as exc:
                    err = ("Parties need a CourtListener token (Settings)."
                           if "401" in str(exc) else str(exc))
            if person_id:
                try:
                    judge = litigation.get_judge(client, person_id)
                except litigation.LitigationError:
                    judge = ""
            return parties, judge, err

        self._run_async(work, lambda res: self._render_case_dialog(s, *res),
                        f"Loading case {s.get('case_number', '')}…",
                        has_credential=token, credential_label="CourtListener API token")

    def _render_case_dialog(self, s: dict, parties, judge, err):
        win = tk.Toplevel(self.root)
        win.title(f"Case {s.get('case_number', '')}")
        win.geometry("560x520")
        win.transient(self.root)
        head = ttk.Frame(win)
        head.pack(fill="x", padx=10, pady=8)
        for i, (k, v) in enumerate((
                ("Case", s.get("case_number")), ("Court", s.get("court")),
                ("Filed", s.get("filing_date")), ("Status", s.get("status")),
                ("Cause", s.get("cause_of_action")),
                ("Judge", judge or s.get("judge") or "—"))):
            ttk.Label(head, text=f"{k}:", foreground="#555").grid(row=i, column=0, sticky="e", padx=(0, 6))
            ttk.Label(head, text=str(v or "—"), wraplength=430, justify="left").grid(row=i, column=1, sticky="w")

        body = ttk.Frame(win)
        body.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        if parties:
            for title, key in (("Plaintiffs", "Plaintiff"), ("Defendants", "Defendant"), ("Other parties", "Other")):
                names = parties.get(key) or []
                if not names:
                    continue
                lf = ttk.LabelFrame(body, text=f"{title} ({len(names)})")
                lf.pack(fill="x", pady=3)
                ttk.Label(lf, text="\n".join(names), justify="left", wraplength=520).pack(anchor="w", padx=6, pady=3)
        else:
            msg = err or ("No party data returned." if s.get("docket_id") else "No docket id for party lookup.")
            ttk.Label(body, text=msg + "\n\nFalling back to case-name parties:", foreground="#a06000",
                      justify="left").pack(anchor="w", pady=(4, 2))
            ttk.Label(body, text=f"Plaintiff: {s.get('plaintiff') or '—'}\nDefendant: {s.get('defendant') or '—'}",
                      justify="left").pack(anchor="w")

        foot = ttk.Frame(win)
        foot.pack(fill="x", padx=10, pady=(0, 10))
        ttk.Button(foot, text="Open docket in browser",
                   command=lambda: self._open_docket_url(s)).pack(side="left")
        ttk.Button(foot, text="Close", command=win.destroy).pack(side="right")

    # ------------------------------------------------------------------ export / save
    def _export_pane(self, pane: ResultPane, fmt: str):
        rows = pane.rows
        if not rows and pane.payload is None:
            messagebox.showinfo("Nothing to export", "Run a search first.")
            return
        if fmt == "csv":
            path = filedialog.asksaveasfilename(defaultextension=".csv",
                                                filetypes=[("CSV", "*.csv"), ("All files", "*.*")])
            if not path:
                return
            with open(path, "w", newline="", encoding="utf-8") as fh:
                writer = csv.writer(fh)
                writer.writerow(pane.columns)
                for r in rows:
                    writer.writerow(["" if v is None else v for v in r])
            self.log.info("Exported %d row(s) → %s", len(rows), path)
            self.status_var.set(f"Exported {len(rows)} row(s) → {path}")
        else:
            path = filedialog.asksaveasfilename(defaultextension=".json",
                                                filetypes=[("JSON", "*.json"), ("All files", "*.*")])
            if not path:
                return
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(pane.payload, fh, indent=2, ensure_ascii=False)
            self.log.info("Exported JSON → %s", path)
            self.status_var.set(f"Exported → {path}")


    def _filter_summary_lines(self) -> list[str]:
        body = self._last_search_body or {}
        lines = ["# PTAB proceedings search — applied filters"]
        if body.get("q"):
            lines.append(f"# q: {body['q']}")
        for f in body.get("filters", []):
            lines.append(f"# filter: {f['name']} = {', '.join(f.get('value', []))}")
        sort = (body.get("sort") or [{}])[0]
        if sort:
            lines.append(f"# sort: {sort.get('field')} {sort.get('order')}")
        pg = body.get("pagination", {})
        lines.append(f"# pagination: offset={pg.get('offset')} limit={pg.get('limit')}")
        return lines

    def _export_search(self, fmt: str):
        rows = self.search_pane.rows
        if not rows and self.search_pane.payload is None:
            messagebox.showinfo("Nothing to export", "Run a search first.")
            return
        include = self.incl_filters_var.get()

        if fmt == "csv":
            path = filedialog.asksaveasfilename(defaultextension=".csv",
                                                filetypes=[("CSV", "*.csv"), ("All files", "*.*")])
            if not path:
                return
            with open(path, "w", newline="", encoding="utf-8") as fh:
                if include:
                    for line in self._filter_summary_lines():
                        fh.write(line + "\n")
                writer = csv.writer(fh)
                writer.writerow(self.search_pane.columns)
                for r in rows:
                    writer.writerow(["" if v is None else v for v in r])
            self.log.info("Exported %d row(s) → %s", len(rows), path)
            self.status_var.set(f"Exported {len(rows)} row(s) → {path}")
        else:  # json
            path = filedialog.asksaveasfilename(defaultextension=".json",
                                                filetypes=[("JSON", "*.json"), ("All files", "*.*")])
            if not path:
                return
            payload = ({"query": self._last_search_body, "count": len(rows),
                        "results": self.search_pane.payload}
                       if include else self.search_pane.payload)
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            self.log.info("Exported search JSON → %s", path)
            self.status_var.set(f"Exported → {path}")

    def _save_json(self, payload: Any):
        if payload is None:
            messagebox.showinfo("Nothing to save", "Run a request first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                            filetypes=[("JSON", "*.json"), ("All files", "*.*")])
        if not path:
            return
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        self.log.info("Saved JSON → %s", path)
        self.status_var.set(f"Saved {path}")


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("clam")
    except tk.TclError:
        pass
    PtabApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
