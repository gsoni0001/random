---
name: python-gui
description: >-
  Build professional-grade Python GUIs — desktop, mobile, and web. Covers
  PySide6/PyQt6, Flet, NiceGUI, and Kivy, with a framework-selection guide plus
  deep patterns for clean architecture, non-blocking/async UIs, styling and
  theming, packaging, and testing. Use this whenever the user wants to build,
  design, refactor, or package any Python GUI, desktop app, or cross-platform
  interface — even when they name a specific library (PyQt, PySide, Flet,
  NiceGUI, Kivy, Tkinter) instead of saying "GUI", or when a Python script needs
  a windowed front-end instead of a CLI. Reach for it for windows, dashboards,
  control panels, touchscreen/kiosk UIs, and cross-platform apps alike.
---

# Python GUI

Build Python GUIs the way a professional would: pick the right framework for the
deployment target, separate the interface from the logic, keep the UI responsive
under load, style it deliberately, and ship it tested and packaged. This skill
gives you a selection guide, framework-agnostic patterns, a design subagent, and
a scaffolder that emits a runnable project with the architecture already wired
in.

Approach every non-trivial app in three moves: **choose the framework → design
before you build → scaffold, then flesh out.** Rushing straight to widget code is
the most common way GUI projects rot — logic tangles into the view, long tasks
freeze the window, and styling gets copy-pasted everywhere.

## 1. Choose the framework

Deployment target drives the choice more than anything else. Match the project to
a row, then read that framework's reference file.

| If the app is…                                                        | Use            | Why |
|-----------------------------------------------------------------------|----------------|-----|
| Complex / enterprise **desktop**; 100+ widgets, native feel, tables, multimedia | **Qt (PySide6)** | Industry standard, deepest widget set, mature Model/View + QSS styling |
| One codebase to **desktop + mobile + web**, Material look             | **Flet**       | Flutter engine renders all targets from pure Python |
| **Data-science / AI / background-task** tooling; dashboards, control panels, long jobs | **NiceGUI** | Async-native, non-blocking; runs in the browser *or* a native window |
| **Touch / mobile / kiosk / gestures**, custom GPU-drawn canvas        | **Kivy**       | Built-in multi-touch and gestures on an OpenGL canvas |

Notes that change real decisions:
- **PySide6 vs PyQt6:** prefer **PySide6** — its **LGPL** license lets you ship
  closed-source commercial apps freely. Choose PyQt6 only if the team already
  standardizes on it (**GPL/commercial**). APIs are ~95% identical.
- **If unsure, default to Qt/PySide6.** It's the safest choice for a serious
  desktop app and the hardest to outgrow.
- Confirm the pick against the *hard* requirement in the brief (must run on
  phones? → Flet/Kivy, not Qt. Must embed in a browser / stream to remote users?
  → NiceGUI). Don't let a framework preference override a deployment constraint.

## 2. Design before you build

For anything beyond a single dialog, plan the screens, component tree, state
ownership, and async boundaries *before* writing code. Retrofitting architecture
onto live GUI code is expensive; a short spec up front is cheap.

Spawn the bundled **`ui-designer`** subagent for this — read `agents/ui-designer.md`
and run it with the Agent tool, passing the brief. It returns a concrete design
spec (screens, ASCII wireframes, the state store, where threading/async sits, a
theme direction, and the exact scaffold command) that the next steps execute
against. For a genuinely trivial app you can skip it, but say so deliberately.

## 3. Scaffold, then flesh out

Don't hand-write boilerplate. The bundled generator emits a runnable, correctly
structured project for any of the four frameworks:

```bash
python -m scripts.scaffold --framework qt --name myapp --out ./myapp
#           frameworks: qt | flet | nicegui | kivy
```

Each skeleton already applies the professional patterns below — a state store,
a UI layer with no business logic, a worker that keeps slow work off the event
loop, a theme module, a test stub, `requirements.txt`, and a README with run /
test / package commands. Build the real feature *on top of* the skeleton rather
than replacing its structure. (Run `--help` for options; it refuses to overwrite
a non-empty directory without `--force`.)

## 4. Professional patterns (framework-agnostic)

These are the four things that separate a toy from a shippable app. Each
framework's reference file shows the concrete API.

**Architecture — separate the UI from the logic.** Keep application data and
rules in a single **state store** (the source of truth). The UI renders that
state and forwards user intent back to it; it owns no business rules. The store
notifies the UI of changes through the framework's observer mechanism — Qt
signals, a subscribe/notify store (Flet/NiceGUI), or Kivy properties. This seam
is what makes the app testable and lets the interface change without rewriting
logic. (MVVM/MVC are names for this split.)

**Responsive UI — never block the event loop.** A GUI is a loop that must return
to painting and input many times a second. Any slow work on that thread —
network, disk, heavy compute — freezes the window. Move it off: a worker
thread/pool (Qt, Kivy) or `async`/`await` with `to_thread` for blocking calls
(Flet, NiceGUI). Results must return to the UI thread through the framework's
safe channel (signals, `@mainthread`, awaited coroutines) — never touch widgets
from a worker thread. Assume any I/O can be slow and design the action as
non-blocking from the start.

**Styling & theming — centralize the tokens.** Put colors, spacing, and type in
one theme module and apply it at the app level, so styling stays out of widget
code and dark mode is a single switch. Use the framework's system — QSS
(Qt, CSS-like), Material themes (Flet), Tailwind/Quasar props (NiceGUI), kv +
KivyMD (Kivy). Support dark mode and HiDPI, and lay out with layouts/flex rather
than fixed coordinates so the UI survives resizing and different displays.

**Packaging & testing — a real app ships and is tested.** Distribute with
PyInstaller (Qt/NiceGUI/Kivy desktop), `flet build` (Flet, incl. mobile), or
Buildozer (Kivy Android). Test the **state store** with plain `pytest` for fast
logic coverage — keeping it framework-independent pays off here — and add
UI/interaction tests with the framework's tooling (`pytest-qt`, NiceGUI's
`user` fixture, Kivy's test bases). Set an offscreen/headless platform in CI.

## 5. Go deep

Once the framework is chosen, read its reference — each is self-contained with
its own table of contents and the same four emphasis areas:

| Framework | Read | For |
|-----------|------|-----|
| Qt (PySide6/PyQt6) | `references/qt.md` | Signals/slots, Model/View, QThread/QThreadPool, QSS, PyInstaller, pytest-qt |
| Flet | `references/flet.md` | Controls, async handlers, Material theming, `flet build` |
| NiceGUI | `references/nicegui.md` | Native vs browser, async/background tasks, Tailwind styling |
| Kivy | `references/kivy.md` | kv language, properties, `@mainthread`, touch/gestures, Buildozer |

Bundled resources: `scripts/scaffold.py` (project generator),
`agents/ui-designer.md` (design subagent), `references/` (per-framework depth).
