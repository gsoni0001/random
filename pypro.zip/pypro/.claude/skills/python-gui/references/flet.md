# Flet — one codebase to desktop + mobile + web

Flet renders your Python UI with Google's **Flutter** engine, so the same code
ships as a native desktop app, an Android/iOS app, and a web app, with modern
Material Design out of the box. Reach here when *true* cross-platform reach
(especially mobile) matters more than a deep native-desktop widget set.

## Contents
1. Model — page and controls
2. State & re-rendering
3. Responsive UI — async handlers
4. Styling & theming (Material, dark mode)
5. Packaging (`flet build`)
6. Testing

The bundled scaffold (`python -m scripts.scaffold --framework flet`) emits a
runnable project applying sections 2–6.

## 1. Model — page and controls
A Flet app is a function that receives a `Page` and adds **controls** (the
widget tree). `page.update()` flushes changes to the Flutter renderer.
```python
import flet as ft

def main(page: ft.Page):
    page.title = "My App"
    page.add(ft.Text("Hello"), ft.FilledButton("Click"))

ft.app(target=main)                       # native desktop window
# ft.app(target=main, view=ft.AppView.WEB_BROWSER)   # serve in the browser
```

## 2. State & re-rendering
Flet is retained-mode: you mutate control properties, then call `page.update()`.
Keep app data in a small store the views subscribe to, so the UI stays free of
business rules.
```python
class AppState:
    def __init__(self): self._count = 0; self._subs = []
    def subscribe(self, fn): self._subs.append(fn)
    def increment(self):
        self._count += 1
        for fn in self._subs: fn()
    @property
    def count(self): return self._count
```
A view registers a `render()` callback that reads the store and updates control
`.value`s, then calls `page.update()`.

## 3. Responsive UI — async handlers
Flet runs on **asyncio**. Make event handlers `async` and `await` slow I/O so
the UI never freezes; push blocking/CPU work to a thread with
`asyncio.to_thread`.
```python
import asyncio

async def do_work(e):
    status.value = "Working..."; page.update()
    await asyncio.sleep(3)                 # non-blocking; or: await asyncio.to_thread(blocking_fn)
    status.value = "Done"; page.update()

page.add(ft.FilledButton("Run", on_click=do_work))
```

## 4. Styling & theming (Material, dark mode)
```python
page.theme_mode = ft.ThemeMode.DARK
page.theme = ft.Theme(color_scheme_seed="blue")   # seed strings are version-stable
```
Material components (`ft.FilledButton`, `ft.Card`, `ft.NavigationBar`, ...) come
pre-styled; adjust with a seed color + per-control props (`bgcolor`, `padding`,
`border_radius`). Note the color **enum** API has shifted across Flet versions
(`ft.colors` vs `ft.Colors`); a `color_scheme_seed` string avoids that churn.

## 5. Packaging (`flet build`)
```bash
flet build macos      # or: windows | linux | apk | ipa | web
```
`flet build` produces a real native bundle per target (it drives Flutter's
toolchain — Android builds need the Android SDK, iOS needs Xcode, etc.). For a
quick desktop package you can also use PyInstaller, but `flet build` is the
supported path and the only one that reaches mobile.

## 6. Testing
Keep the store framework-independent so its logic is plain-`pytest` testable
without a running Flutter engine:
```python
def test_increment():
    s = AppState(); seen = []
    s.subscribe(lambda: seen.append(s.count))
    s.increment()
    assert s.count == 1 and seen == [1]
```
For end-to-end UI flows, drive the app through Flet's integration testing or a
browser driver against the web target; most regressions are caught by testing
the store plus small pure render helpers.
