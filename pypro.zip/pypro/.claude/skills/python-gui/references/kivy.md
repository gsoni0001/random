# Kivy — touch, gestures, and mobile / GPU canvas

Kivy draws its own UI on a GPU-accelerated canvas (OpenGL), with built-in
multi-touch and gesture support. Reach here for **touchscreen kiosks, mobile
apps (Android/iOS), games, and custom-drawn interfaces** where native desktop
chrome is not the goal. For a Material look on top of Kivy, use **KivyMD**.

## Contents
1. Model — widgets and the kv language
2. Architecture — properties & bindings
3. Responsive UI — threads, Clock, @mainthread
4. Touch & gestures
5. Styling & theming
6. Packaging (Buildozer / PyInstaller) & testing

The bundled scaffold (`python -m scripts.scaffold --framework kivy`) emits a
runnable project applying sections 2, 3, and 6.

## 1. Model — widgets and the kv language
An app subclasses `App` and returns a root widget. Layout and bindings are best
declared in the **kv language** (a declarative DSL) to keep Python logic clean.
```python
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout

KV = """
<Root>:
    orientation: "vertical"
    Label:
        text: "Count: {}".format(app.state.count)   # auto-binds to the property
    Button:
        text: "Increment"
        on_release: app.state.increment()
"""

class Root(BoxLayout): pass

class MyApp(App):
    def build(self):
        self.state = AppState()
        Builder.load_string(KV)
        return Root()
```

## 2. Architecture — properties & bindings
Kivy **Properties** are the observer seam. Put app data on an `EventDispatcher`
with typed properties; the kv UI that references them re-renders automatically,
so the view holds no business logic.
```python
from kivy.event import EventDispatcher
from kivy.properties import NumericProperty, StringProperty

class AppState(EventDispatcher):
    count = NumericProperty(0)
    status = StringProperty("Ready")
    def increment(self):
        self.count += 1                 # any kv/label bound to `count` updates
```
Referencing `app.state.count` inside a kv expression creates the binding for
you. In Python, bind manually with `state.bind(count=on_count)`.

## 3. Responsive UI — threads, Clock, @mainthread
Kivy's event loop is single-threaded; blocking it freezes rendering and touch.
Run slow work in a background `threading.Thread`, then marshal UI updates back
to the main thread with `@mainthread` (never mutate widgets/properties from the
worker thread directly).
```python
import threading, time
from kivy.clock import mainthread

def run_task(on_progress, on_done):
    @mainthread
    def progress(p): on_progress(p)
    @mainthread
    def done(): on_done()
    def work():
        for i in range(3):
            time.sleep(1)               # stand-in for real work
            progress(i + 1)
        done()
    threading.Thread(target=work, daemon=True).start()
```
Use `Clock.schedule_interval(cb, dt)` for periodic UI updates and
`Clock.schedule_once` to defer work to the next frame.

## 4. Touch & gestures
Widgets receive `on_touch_down/move/up` with multi-touch dispatch built in.
`ScrollView`, `Carousel`, and `Scatter` (drag/rotate/zoom) give you common
touch interactions for free; use them before hand-rolling gesture math.

## 5. Styling & theming
Style in kv via `canvas` instructions (`Color`, `Rectangle`) and widget
properties; set the window background with `Window.clearcolor = (r,g,b,a)` (0–1
range). For a full design system, adopt **KivyMD**, which provides Material
components, theming, and dark mode on top of Kivy.

## 6. Packaging (Buildozer / PyInstaller) & testing
- **Mobile (Android):** `pip install buildozer && buildozer init && buildozer -v android debug`. iOS uses `kivy-ios`.
- **Desktop:** `pip install pyinstaller && pyinstaller --windowed main.py` (bundle any `.kv` files and assets).
- **Testing:** keep state on the `EventDispatcher` so its logic is plain-`pytest`
  testable without a window:
  ```python
  def test_increment():
      s = AppState(); s.increment()
      assert s.count == 1
  ```
  For UI, Kivy provides `UnitTestTouch` and a headless `GraphicUnitTest` base;
  set `KIVY_WINDOW=mock`/an offscreen provider in CI.
