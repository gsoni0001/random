# NiceGUI — web-based UI with a native desktop mode

NiceGUI renders your UI as modern web components (Vue/Quasar) served by a Python
backend, and can also launch a standalone native desktop window. It handles
asyncio gracefully, so it shines for **data science, AI, and background-task
tooling** — dashboards and control panels that run long jobs without freezing.

## Contents
1. Model — pages and elements
2. Native window vs browser
3. Responsive UI — async & background tasks
4. State & re-rendering
5. Styling (Tailwind / Quasar props)
6. Packaging & testing

The bundled scaffold (`python -m scripts.scaffold --framework nicegui`) emits a
runnable project applying sections 2–4 and 6.

## 1. Model — pages and elements
You build UI by calling element functions; each returns an object you can update
later. `@ui.page("/")` scopes UI to a route (and gives each browser client its
own instance).
```python
from nicegui import ui

@ui.page("/")
def index():
    label = ui.label("Hello")
    ui.button("Click", on_click=lambda: label.set_text("clicked"))

ui.run()                       # serve in the browser
```

## 2. Native window vs browser
The same code runs either way — this dual target is NiceGUI's core versatility:
```python
ui.run(native=True, title="My App", dark=True)   # standalone desktop window (needs pywebview)
ui.run()                                          # browser at http://localhost:8080
```
For native mode install the extra: `pip install "nicegui[native]"`.

## 3. Responsive UI — async & background tasks
NiceGUI is async-native. Make handlers `async` and `await` I/O; for
blocking/CPU work use `run.io_bound` / `run.cpu_bound` (or `asyncio.to_thread`)
so the event loop and every connected client stay live. This non-blocking
behavior is the main reason to pick NiceGUI for long-running work.
```python
from nicegui import ui
import asyncio

async def do_work():
    status.set_text("Working...")
    await asyncio.sleep(3)                  # non-blocking
    status.set_text("Done")

status = ui.label("Ready")
ui.button("Run", on_click=do_work)
```
Use `ui.timer(interval, callback)` for periodic refresh (live metrics, polling).

## 4. State & re-rendering
Update elements by calling their setters (`.set_text`, `.set_value`) or use
`ui.refreshable` to re-render a whole fragment when data changes. Keep app data
in a small observer store the UI subscribes to, so views hold no business rules
(the scaffold's `app/state.py` shows the pattern) — this also keeps the store
plain-`pytest` testable.

## 5. Styling (Tailwind / Quasar props)
Every element takes `.classes(...)` (Tailwind utility classes), `.style(...)`
(raw CSS), and `.props(...)` (Quasar component props):
```python
ui.label("Title").classes("text-2xl font-bold text-primary")
ui.button("Save").props("color=positive rounded")
```
Set a global theme with `ui.colors(primary="#5b8def", ...)` and dark mode via
`ui.run(dark=True)` or `ui.dark_mode()`.

## 6. Packaging & testing
**Package** the native app with PyInstaller — NiceGUI's docs give a ready
`*.spec` under "Package for Installation" (it must bundle NiceGUI's static
assets); follow it rather than a bare `pyinstaller main.py`.
**Test** the store logic with plain `pytest`; for UI/interaction NiceGUI ships a
pytest plugin with a `user`/`screen` fixture that drives the app in-process:
```python
async def test_click(user):
    await user.open("/")
    await user.should_see("Ready")
    user.find("Run").click()
```
