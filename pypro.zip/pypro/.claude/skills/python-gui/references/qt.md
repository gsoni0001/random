# Qt — PySide6 / PyQt6 (primary reference)

The professional default for heavy-duty desktop software: 100+ native widgets,
Model/View, a mature styling system (QSS), multimedia, and a web engine. Reach
here for complex, long-lived, enterprise-grade desktop apps.

**PySide6 vs PyQt6.** They are ~95% API-identical. Prefer **PySide6** (official
Qt binding, **LGPL** — ship closed-source commercial apps freely). Choose
**PyQt6** only if the team already standardizes on it (**GPL/commercial**
license). The one syntax gotcha: signals are `Signal`/`Slot` in PySide6 vs
`pyqtSignal`/`pyqtSlot` in PyQt6, and you `import PyQt6`. Everything below is
PySide6; the PyQt6 delta is noted where it matters.

## Contents
1. Bootstrap & the event loop
2. Layouts and widgets
3. Architecture — signals/slots and Model/View
4. Responsive UI — threads and workers
5. Styling & theming (QSS, dark mode, HiDPI)
6. Packaging (PyInstaller)
7. Testing (pytest-qt)

The bundled scaffold (`python -m scripts.scaffold --framework qt`) emits a
runnable project that already applies sections 3–7. Start from it.

## 1. Bootstrap & the event loop
```python
import sys
from PySide6.QtWidgets import QApplication, QWidget

app = QApplication(sys.argv)   # exactly one, created first
window = QWidget()
window.show()
sys.exit(app.exec())           # runs the event loop until the last window closes
```
Everything in Qt happens *inside* `app.exec()`. Any code that blocks this thread
freezes the whole UI (section 4).

## 2. Layouts and widgets
Compose UI with layouts, never absolute coordinates — they handle resizing,
HiDPI, and i18n text growth for free.
```python
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QPushButton, QLabel

layout = QVBoxLayout(parent_widget)
layout.addWidget(QLabel("Title"))
row = QHBoxLayout()
row.addWidget(QPushButton("OK"))
row.addStretch()               # pushes following widgets to the right
layout.addLayout(row)
```
Common widgets: `QLabel`, `QPushButton`, `QLineEdit`, `QComboBox`, `QCheckBox`,
`QTableView`/`QListView`/`QTreeView` (Model/View — section 3), `QTabWidget`,
`QStackedWidget` (multi-screen navigation), `QMainWindow` (menus/toolbars/status
bar/docks for full apps).

## 3. Architecture — signals/slots and Model/View
Signals/slots are Qt's observer mechanism and the seam that keeps UI separate
from logic. A widget emits a signal on user intent; a slot (any callable)
reacts. Keep business state in a plain `QObject` store that emits signals; let
views connect to it and hold no rules of their own.
```python
from PySide6.QtCore import QObject, Signal   # PyQt6: pyqtSignal

class AppState(QObject):
    count_changed = Signal(int)
    def __init__(self):
        super().__init__(); self._count = 0
    def increment(self):
        self._count += 1
        self.count_changed.emit(self._count)

state = AppState()
button.clicked.connect(state.increment)                 # intent -> state
state.count_changed.connect(lambda n: label.setText(str(n)))  # state -> view
```
For tabular/tree/list data, use **Model/View** rather than stuffing rows into a
widget: subclass `QAbstractTableModel`/`QAbstractListModel` and bind it to a
`QTableView`. The view renders whatever the model exposes, sorting/filtering via
`QSortFilterProxyModel`, and scales to large datasets without you managing
per-cell widgets.

## 4. Responsive UI — threads and workers
The golden rule: **never do slow work on the GUI thread.** Networking, file I/O,
heavy computation → run on a worker and report back via signals, which Qt
delivers safely onto the GUI thread.

Preferred pattern — `QRunnable` + `QThreadPool` (a signals object because
`QRunnable` is not a `QObject`):
```python
from PySide6.QtCore import QObject, QRunnable, Signal, Slot, QThreadPool

class Signals(QObject):
    progress = Signal(int)
    finished = Signal(str)

class Worker(QRunnable):
    def __init__(self):
        super().__init__(); self.signals = Signals()
    @Slot()
    def run(self):
        ... # slow work here; emit self.signals.progress(...) as you go
        self.signals.finished.emit("done")

worker = Worker()
worker.setAutoDelete(False)      # critical, see below
self._worker = worker            # keep a reference
worker.signals.finished.connect(on_done)
QThreadPool.globalInstance().start(worker)
```
**Lifetime gotcha (bites everyone):** by default the pool destroys the runnable
the instant `run()` returns — which can drop the queued `finished` signal before
its slot fires. Call `setAutoDelete(False)` and hold a Python reference until the
`finished` slot runs, then release it. The scaffold's `main_window.py` shows the
full pattern and a headless test proves the loop stays responsive.

Alternative — the "worker object moved to a QThread" pattern — is also valid;
use it when a worker needs to live long and receive signals. Prefer the
thread-pool approach for one-shot tasks. Never touch widgets from a worker
thread; communicate only via signals.

## 5. Styling & theming (QSS, dark mode, HiDPI)
QSS behaves almost like CSS. Keep every color/token in one module and set the
sheet on the `QApplication` so theming is one switch and logic stays clean.
```python
app.setStyleSheet("""
    QWidget { background: #1e1f26; color: #e6e6e6; font-size: 14px; }
    QPushButton { background: #5b8def; color: white; border-radius: 6px;
                  padding: 8px 16px; }
    QPushButton:hover { background: #6f9bf2; }
    QLabel#heading { font-size: 22px; font-weight: 600; }   /* setObjectName("heading") */
""")
```
Selectors: type (`QPushButton`), object name (`#heading`), and property/state
(`:hover`, `:disabled`, `[flat="true"]`). Pair QSS with a `QPalette` for
scrollbars/native chrome QSS doesn't reach. Dark mode = swap the token set and
re-apply. **HiDPI** is automatic on Qt6 (per-monitor scaling on by default); use
`sp`/logical pixels via layouts and vector icons (SVG) so everything scales.

## 6. Packaging (PyInstaller)
```bash
pip install pyinstaller
pyinstaller --noconfirm --windowed --name MyApp main.py
```
`--windowed` suppresses the console on Windows/macOS. PySide6's PyInstaller hook
bundles Qt plugins automatically. For an installer, wrap the output with Inno
Setup (Windows) or create a `.app`/`.dmg` (macOS). `--onefile` yields a single
binary at the cost of slower startup.

## 7. Testing (pytest-qt)
```bash
pip install pytest pytest-qt
```
`pytest-qt` gives you a `qtbot` fixture to drive widgets and, crucially,
`waitSignal` to test asynchronous worker code deterministically.
```python
def test_increment_emits(qtbot):
    state = AppState()
    with qtbot.waitSignal(state.count_changed) as blocker:
        state.increment()
    assert blocker.args == [1]

def test_button_click(qtbot):
    w = MainWindow(AppState()); qtbot.addWidget(w)
    qtbot.mouseClick(w.some_button, Qt.LeftButton)
    ...
```
Test the state store directly (no widgets needed) for fast logic coverage, and
use `qtbot` for the view/interaction layer. In headless CI set
`QT_QPA_PLATFORM=offscreen`.
