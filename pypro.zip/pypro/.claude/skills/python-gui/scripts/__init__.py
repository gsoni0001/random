"""Bundled scripts for the python-gui skill.

Run the scaffolder as a module from the skill root:

    python -m scripts.scaffold --framework qt --name myapp --out ./myapp
"""
