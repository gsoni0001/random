#!/usr/bin/env python3
"""Scaffold a runnable, professionally-structured Python GUI project.

Every skeleton bakes in the same architecture the skill teaches:
  * a single source of truth (state store) that the UI observes,
  * a UI layer that holds no business logic,
  * a worker layer that keeps slow work off the event loop, and
  * a centralized theme/tokens module.

Usage:
    python -m scripts.scaffold --framework qt --name myapp --out ./myapp

Frameworks: qt (PySide6) | flet | nicegui | kivy

Standard library only, so it runs anywhere Python does. It writes source
files; you install the chosen GUI framework afterwards (see the generated
README.md and requirements.txt).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

FRAMEWORKS = ("qt", "flet", "nicegui", "kivy")

# Token replacement is used instead of str.format so the templates below can
# contain literal { } braces (QSS, .format calls) without escaping.
#   ___TITLE___     human-facing app title
#   ___PKGCLASS___  CamelCase class name (Kivy App subclass)


# --------------------------------------------------------------------------- #
# Qt (PySide6)                                                                 #
# --------------------------------------------------------------------------- #
def qt_files() -> dict[str, str]:
    return {
        "main.py": '''"""Entry point for ___TITLE___ (PySide6)."""
from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from app.state import AppState
from app.theme import apply_theme
from app.ui.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("___TITLE___")
    apply_theme(app)

    state = AppState()           # single source of truth
    window = MainWindow(state)   # the view observes state; it owns no logic
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
''',
        "app/__init__.py": "",
        "app/state.py": '''"""Application state: the single source of truth.

The UI never mutates data directly and holds no business rules. It calls
methods here and listens to signals. This seam keeps the app testable and
lets you swap the UI without touching logic.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal


class AppState(QObject):
    count_changed = Signal(int)
    status_changed = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._count = 0

    @property
    def count(self) -> int:
        return self._count

    def increment(self) -> None:
        self._count += 1
        self.count_changed.emit(self._count)

    def set_status(self, message: str) -> None:
        self.status_changed.emit(message)
''',
        "app/theme.py": '''"""Centralized theming via Qt Style Sheets (QSS).

Keep every visual token here so styling stays out of widget logic and dark
mode is a one-line switch.
"""
from __future__ import annotations

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication

TOKENS = {
    "bg": "#1e1f26",
    "surface": "#2a2c36",
    "text": "#e6e6e6",
    "accent": "#5b8def",
}

QSS = """
QWidget {{ background: {bg}; color: {text}; font-size: 14px; }}
QPushButton {{
    background: {accent}; color: white; border: none;
    padding: 8px 16px; border-radius: 6px;
}}
QPushButton:hover {{ background: #6f9bf2; }}
QLabel#heading {{ font-size: 22px; font-weight: 600; }}
""".format(**TOKENS)


def apply_theme(app: QApplication) -> None:
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(TOKENS["bg"]))
    pal.setColor(QPalette.WindowText, QColor(TOKENS["text"]))
    app.setPalette(pal)
    app.setStyleSheet(QSS)
''',
        "app/workers.py": '''"""Background work, kept off the UI thread.

Blocking the event loop freezes the window. Run slow work in a QRunnable and
report results via signals, which Qt delivers safely on the UI thread.
"""
from __future__ import annotations

import time

from PySide6.QtCore import QObject, QRunnable, Signal, Slot


class WorkerSignals(QObject):
    progress = Signal(int)
    finished = Signal(str)


class Worker(QRunnable):
    def __init__(self, seconds: int = 3) -> None:
        super().__init__()
        self.seconds = seconds
        self.signals = WorkerSignals()

    @Slot()
    def run(self) -> None:
        for i in range(self.seconds):
            time.sleep(1)  # stand-in for real slow work
            self.signals.progress.emit(i + 1)
        self.signals.finished.emit("done")
''',
        "app/ui/__init__.py": "",
        "app/ui/main_window.py": '''"""Main window: observes AppState, dispatches slow work to a thread pool.

The view renders state and forwards user intent. It contains no business
logic of its own.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget

from app.state import AppState
from app.workers import Worker


class MainWindow(QWidget):
    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self.pool = QThreadPool.globalInstance()
        self._worker: Worker | None = None
        self.setWindowTitle("___TITLE___")
        self.resize(420, 260)

        heading = QLabel("___TITLE___")
        heading.setObjectName("heading")
        self.count_label = QLabel("Count: 0")
        self.status_label = QLabel("Ready")
        inc = QPushButton("Increment")
        work = QPushButton("Run background task")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)
        for w in (heading, self.count_label, self.status_label, inc, work):
            layout.addWidget(w)
        layout.setAlignment(Qt.AlignTop)

        # intent -> state
        inc.clicked.connect(self.state.increment)
        work.clicked.connect(self._start_work)
        # state -> view
        self.state.count_changed.connect(
            lambda n: self.count_label.setText("Count: {}".format(n))
        )
        self.state.status_changed.connect(self.status_label.setText)

    def _start_work(self) -> None:
        self.state.set_status("Working... (UI stays responsive)")
        # Keep a reference and disable auto-delete: the pool would otherwise
        # destroy the runnable (and its signals) the instant run() returns,
        # dropping the queued `finished` signal before its slot can fire.
        worker = Worker(seconds=3)
        worker.setAutoDelete(False)
        self._worker = worker
        worker.signals.progress.connect(
            lambda p: self.state.set_status("Working... {}/3".format(p))
        )
        worker.signals.finished.connect(self._on_work_finished)
        self.pool.start(worker)

    def _on_work_finished(self, _result: str) -> None:
        self.state.set_status("Done")
        self._worker = None  # release the worker now that we are done with it
''',
        "tests/test_smoke.py": '''"""Smoke test using pytest-qt. Run: pytest"""
from app.state import AppState


def test_state_increment_emits(qtbot):
    state = AppState()
    with qtbot.waitSignal(state.count_changed) as blocker:
        state.increment()
    assert blocker.args == [1]
    assert state.count == 1
''',
        "requirements.txt": "PySide6>=6.6\npytest>=8.0\npytest-qt>=4.4\n",
        "README.md": '''# ___TITLE___

A professional PySide6 desktop app skeleton, generated by the `python-gui` skill.

## Architecture
- `app/state.py` - single source of truth (signals). The UI holds no business logic.
- `app/ui/` - views that observe state and forward user intent.
- `app/workers.py` - slow work runs off the UI thread; results return via signals.
- `app/theme.py` - centralized QSS/tokens for styling and dark mode.

## Run
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python main.py

## Test
    pytest

## Package (single-file executable)
    pip install pyinstaller
    pyinstaller --noconfirm --windowed --name ___TITLE___ main.py
''',
    }


# --------------------------------------------------------------------------- #
# Flet                                                                         #
# --------------------------------------------------------------------------- #
def flet_files() -> dict[str, str]:
    return {
        "main.py": '''"""Entry point for ___TITLE___ (Flet). Runs as a native desktop window."""
from __future__ import annotations

import flet as ft

from app.state import AppState
from app.theme import apply_theme
from app.views import build


def main(page: ft.Page) -> None:
    apply_theme(page)
    state = AppState()
    build(page, state)


if __name__ == "__main__":
    # Native desktop window by default. For the browser, pass
    # view=ft.AppView.WEB_BROWSER to ft.app().
    ft.app(target=main)
''',
        "app/__init__.py": "",
        "app/state.py": '''"""Single source of truth. Views subscribe; they do not own data."""
from __future__ import annotations

from typing import Callable


class AppState:
    def __init__(self) -> None:
        self._count = 0
        self._status = "Ready"
        self._subs: list[Callable[[], None]] = []

    def subscribe(self, fn: Callable[[], None]) -> None:
        self._subs.append(fn)

    def _notify(self) -> None:
        for fn in self._subs:
            fn()

    @property
    def count(self) -> int:
        return self._count

    @property
    def status(self) -> str:
        return self._status

    def increment(self) -> None:
        self._count += 1
        self._notify()

    def set_status(self, message: str) -> None:
        self._status = message
        self._notify()
''',
        "app/theme.py": '''"""Material theme tokens for Flet. Seed strings are stable across versions."""
from __future__ import annotations

import flet as ft


def apply_theme(page: ft.Page) -> None:
    page.title = "___TITLE___"
    page.theme_mode = ft.ThemeMode.DARK
    page.theme = ft.Theme(color_scheme_seed="blue")
    page.padding = 24
''',
        "app/workers.py": '''"""Long work without freezing the UI.

Use async and await asyncio.sleep for I/O, or asyncio.to_thread to push
CPU/blocking work to a thread. Either way the event loop keeps rendering.
"""
from __future__ import annotations

import asyncio
from typing import Callable


async def run_task(seconds: int, on_progress: Callable[[int], None]) -> str:
    for i in range(seconds):
        await asyncio.sleep(1)  # non-blocking
        on_progress(i + 1)
    return "done"
''',
        "app/views.py": '''"""Builds the UI and wires intent to state. Views own no business logic."""
from __future__ import annotations

import flet as ft

from app.state import AppState
from app.workers import run_task


def build(page: ft.Page, state: AppState) -> None:
    heading = ft.Text("___TITLE___", size=22, weight=ft.FontWeight.BOLD)
    count_label = ft.Text()
    status_label = ft.Text()

    def render() -> None:
        count_label.value = "Count: {}".format(state.count)
        status_label.value = state.status
        page.update()

    state.subscribe(render)

    async def do_work(_e) -> None:
        state.set_status("Working... (UI stays responsive)")
        await run_task(3, lambda p: state.set_status("Working... {}/3".format(p)))
        state.set_status("Done")

    page.add(
        heading,
        count_label,
        status_label,
        ft.FilledButton("Increment", on_click=lambda _e: state.increment()),
        ft.FilledButton("Run background task", on_click=do_work),
    )
    render()
''',
        "tests/test_smoke.py": '''"""Smoke test for state logic (framework-independent). Run: pytest"""
from app.state import AppState


def test_increment_and_notify():
    state = AppState()
    seen = []
    state.subscribe(lambda: seen.append(state.count))
    state.increment()
    assert state.count == 1
    assert seen == [1]
''',
        "requirements.txt": "flet>=0.24\npytest>=8.0\n",
        "README.md": '''# ___TITLE___

Cross-platform (desktop/mobile/web) app skeleton built with Flet, generated by the `python-gui` skill.

## Architecture
- `app/state.py` - single source of truth with subscribe/notify. Views hold no data.
- `app/views.py` - builds UI, forwards intent, re-renders on state change.
- `app/workers.py` - async tasks (and `asyncio.to_thread`) keep the UI responsive.
- `app/theme.py` - Material theme tokens and dark mode.

## Run (native desktop window)
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python main.py

Run in the browser instead: `ft.app(target=main, view=ft.AppView.WEB_BROWSER)`.

## Test
    pytest

## Package
    flet build macos   # or windows / linux / apk / ipa / web
''',
    }


# --------------------------------------------------------------------------- #
# NiceGUI                                                                      #
# --------------------------------------------------------------------------- #
def nicegui_files() -> dict[str, str]:
    return {
        "main.py": '''"""Entry point for ___TITLE___ (NiceGUI).

Launches a native desktop window. Set native=False in ui.run to serve in the
browser instead.
"""
from __future__ import annotations

from nicegui import ui

from app.state import AppState
from app.workers import run_task

state = AppState()


@ui.page("/")
def index() -> None:
    ui.label("___TITLE___").classes("text-2xl font-bold")
    count_label = ui.label()
    status_label = ui.label()

    def render() -> None:
        count_label.text = "Count: {}".format(state.count)
        status_label.text = state.status

    state.subscribe(render)

    async def do_work() -> None:
        state.set_status("Working... (UI stays responsive)")
        await run_task(3, lambda p: state.set_status("Working... {}/3".format(p)))
        state.set_status("Done")

    ui.button("Increment", on_click=state.increment)
    ui.button("Run background task", on_click=do_work)
    render()


ui.run(native=True, title="___TITLE___", dark=True)
''',
        "app/__init__.py": "",
        "app/state.py": '''"""Single source of truth. Views subscribe; they do not own data."""
from __future__ import annotations

from typing import Callable


class AppState:
    def __init__(self) -> None:
        self._count = 0
        self._status = "Ready"
        self._subs: list[Callable[[], None]] = []

    def subscribe(self, fn: Callable[[], None]) -> None:
        self._subs.append(fn)

    def _notify(self) -> None:
        for fn in self._subs:
            fn()

    @property
    def count(self) -> int:
        return self._count

    @property
    def status(self) -> str:
        return self._status

    def increment(self) -> None:
        self._count += 1
        self._notify()

    def set_status(self, message: str) -> None:
        self._status = message
        self._notify()
''',
        "app/workers.py": '''"""Long work without freezing the UI.

NiceGUI runs on asyncio: await asyncio.sleep for I/O, or asyncio.to_thread
for blocking/CPU work, and the UI stays live.
"""
from __future__ import annotations

import asyncio
from typing import Callable


async def run_task(seconds: int, on_progress: Callable[[int], None]) -> str:
    for i in range(seconds):
        await asyncio.sleep(1)  # non-blocking
        on_progress(i + 1)
    return "done"
''',
        "tests/test_smoke.py": '''"""Smoke test for state logic (framework-independent). Run: pytest"""
from app.state import AppState


def test_increment_and_notify():
    state = AppState()
    seen = []
    state.subscribe(lambda: seen.append(state.count))
    state.increment()
    assert state.count == 1
    assert seen == [1]
''',
        "requirements.txt": "nicegui[native]>=2.0\npytest>=8.0\n",
        "README.md": '''# ___TITLE___

Web/native hybrid app built with NiceGUI - strong for data and background-task tooling. Generated by the `python-gui` skill.

## Architecture
- `app/state.py` - observer store; the UI subscribes and re-renders.
- `main.py` - the page and event wiring; async handlers keep the UI responsive.
- `app/workers.py` - async background tasks (use `asyncio.to_thread` for blocking work).

## Run (native desktop window)
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python main.py

Serve in the browser instead: change `ui.run(native=True, ...)` to `ui.run()`.

## Test
    pytest

## Package
    pip install pyinstaller
    # See the NiceGUI docs section "Package for Installation" for the spec file.
''',
    }


# --------------------------------------------------------------------------- #
# Kivy                                                                         #
# --------------------------------------------------------------------------- #
def kivy_files() -> dict[str, str]:
    return {
        "main.py": '''"""Entry point for ___TITLE___ (Kivy)."""
from __future__ import annotations

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout

from app.state import AppState
from app.theme import BG
from app.workers import run_task

KV = """
<Root>:
    orientation: "vertical"
    padding: 24
    spacing: 12
    Label:
        text: "___TITLE___"
        font_size: "22sp"
        bold: True
        size_hint_y: None
        height: 40
    Label:
        text: "Count: {}".format(app.state.count)
    Label:
        text: app.state.status
    Button:
        text: "Increment"
        on_release: app.state.increment()
    Button:
        text: "Run background task"
        on_release: app.start_work()
"""


class Root(BoxLayout):
    pass


class ___PKGCLASS___App(App):
    def build(self):
        from kivy.core.window import Window

        Window.clearcolor = BG
        self.state = AppState()
        Builder.load_string(KV)
        return Root()

    def start_work(self):
        self.state.set_status("Working... (UI stays responsive)")
        run_task(
            3,
            lambda p: self.state.set_status("Working... {}/3".format(p)),
            lambda: self.state.set_status("Done"),
        )


if __name__ == "__main__":
    ___PKGCLASS___App().run()
''',
        "app/__init__.py": "",
        "app/state.py": '''"""Single source of truth using Kivy properties.

The kv UI binds to these properties, so the view holds no business logic and
updates automatically when state changes.
"""
from __future__ import annotations

from kivy.event import EventDispatcher
from kivy.properties import NumericProperty, StringProperty


class AppState(EventDispatcher):
    count = NumericProperty(0)
    status = StringProperty("Ready")

    def increment(self) -> None:
        self.count += 1

    def set_status(self, message: str) -> None:
        self.status = message
''',
        "app/theme.py": '''"""Color tokens for Kivy (RGBA, 0-1 range)."""
BG = (0.118, 0.122, 0.149, 1)      # #1e1f26
ACCENT = (0.357, 0.553, 0.937, 1)  # #5b8def
''',
        "app/workers.py": '''"""Slow work off the UI thread.

Kivy's event loop is single-threaded, so run blocking work in a background
thread and marshal every UI update back with @mainthread.
"""
from __future__ import annotations

import threading
import time
from typing import Callable

from kivy.clock import mainthread


def run_task(seconds: int, on_progress: Callable[[int], None],
             on_done: Callable[[], None]) -> None:
    @mainthread
    def progress(p: int) -> None:
        on_progress(p)

    @mainthread
    def done() -> None:
        on_done()

    def work() -> None:
        for i in range(seconds):
            time.sleep(1)
            progress(i + 1)
        done()

    threading.Thread(target=work, daemon=True).start()
''',
        "tests/test_smoke.py": '''"""Smoke test for state properties. Run: pytest"""
from app.state import AppState


def test_increment():
    state = AppState()
    state.increment()
    assert state.count == 1
''',
        "requirements.txt": "kivy>=2.3\npytest>=8.0\n",
        "README.md": '''# ___TITLE___

Touch/GPU app skeleton built with Kivy (desktop + Android/iOS), generated by the `python-gui` skill.

## Architecture
- `app/state.py` - single source of truth via Kivy properties; the kv UI binds to them.
- `main.py` - the kv layout and event wiring; the view holds no business logic.
- `app/workers.py` - blocking work runs in a background thread; UI updates return via `@mainthread`.
- `app/theme.py` - color tokens.

## Run
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python main.py

## Test
    pytest

## Package
    # Desktop:  pip install pyinstaller && pyinstaller --windowed main.py
    # Android:  pip install buildozer && buildozer init && buildozer -v android debug
''',
    }


BUILDERS = {
    "qt": qt_files,
    "flet": flet_files,
    "nicegui": nicegui_files,
    "kivy": kivy_files,
}


# --------------------------------------------------------------------------- #
# Driver                                                                       #
# --------------------------------------------------------------------------- #
def to_class_name(name: str) -> str:
    parts = re.split(r"[^0-9a-zA-Z]+", name)
    cleaned = "".join(p[:1].upper() + p[1:] for p in parts if p)
    if not cleaned or not cleaned[0].isalpha():
        cleaned = "App" + cleaned
    return cleaned


def render(template: str, title: str, class_name: str) -> str:
    return template.replace("___TITLE___", title).replace(
        "___PKGCLASS___", class_name
    )


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="scaffold",
        description="Scaffold a professionally-structured Python GUI project.",
    )
    parser.add_argument("--framework", required=True, choices=FRAMEWORKS,
                        help="GUI framework to scaffold")
    parser.add_argument("--name", required=True, help="application name/title")
    parser.add_argument("--out", required=True, help="output directory")
    parser.add_argument("--force", action="store_true",
                        help="write into a non-empty directory")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])

    out = Path(args.out).expanduser()
    if out.exists() and any(out.iterdir()) and not args.force:
        print(
            "error: {} exists and is not empty. Pass --force to write into it.".format(
                out
            ),
            file=sys.stderr,
        )
        return 1

    title = args.name.strip()
    class_name = to_class_name(title)
    files = BUILDERS[args.framework]()

    written: list[Path] = []
    for rel, template in files.items():
        dest = out / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(render(template, title, class_name), encoding="utf-8")
        written.append(dest)

    print("Scaffolded {} project '{}' into {}".format(args.framework, title, out))
    for path in written:
        print("  created {}".format(path.relative_to(out)))
    print("\nNext steps:")
    print("  cd {}".format(out))
    print("  python -m venv .venv && source .venv/bin/activate")
    print("  pip install -r requirements.txt")
    print("  python main.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
