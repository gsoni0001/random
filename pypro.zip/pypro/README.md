# PDF Combiner

A professional desktop app for combining PDFs, built with PySide6. Add files or a
whole folder, drag to set the merge order, pick page ranges and rotation per file,
preview each one, and merge — with optional bookmarks and AES-256 encryption. The
merge runs on a background thread so the window never freezes.

Built with the project's `python-gui` skill (framework selection, design agent,
and scaffolder under `.claude/skills/python-gui/`).

## Features
- **Add files** and **Add whole folder** (imports every PDF in it)
- **Drag-and-drop reordering** — the list order *is* the merge order (plus Up/Down/Remove)
- **Per-file page ranges** — `1-3,5,8-` style, order preserved
- **Per-file rotation** — 0 / 90 / 180 / 270°
- **Uniform page size** — scale every page to fit A4 / Letter / Legal (aspect preserved,
  centered, orientation matched), or keep each page's original size
- **Preview panel** — first-page thumbnail (pypdfium2), page count, size, encryption status
- **Bookmarks** — one outline entry per source file (optional)
- **Encrypted inputs** — detected and unlocked via a password prompt before merging
- **Encrypted output** — optional AES-256 password on the merged file
- **Non-blocking** — metadata reads, thumbnails, and the merge all run on workers

## Architecture
- `app/pdf_engine.py` — pure, Qt-free PDF operations (pypdf + pypdfium2); fully unit-tested.
- `app/state.py` — the single source of truth (`AppState`); UI holds no PDF logic.
- `app/workers.py` — `QRunnable` workers that keep slow pypdf work off the UI thread.
- `app/ui/` — `main_window.py`, `preview_panel.py`, `dialogs.py` (views only).
- `app/theme.py` — centralized QSS tokens (light default, dark variant available).

## Run
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python main.py

## Test
    QT_QPA_PLATFORM=offscreen pytest        # engine unit tests + headless GUI/worker tests

## Package (single-file executable)
    pip install pyinstaller
    pyinstaller --noconfirm --windowed --name "PDF Combiner" main.py

## Libraries & licenses
All permissive — safe to distribute a closed-source build:
`pypdf` (BSD-3), `pypdfium2` (BSD/Apache), `pillow` (HPND), `cryptography` (Apache/BSD),
`PySide6` (LGPL). Deliberately avoids PyMuPDF (AGPL) and Poppler (GPL) for rendering.

## Known limits
- Rotation is in 90° steps (PDF spec).
- No image/DPI down-sampling: pypdf "compression" is lossless-only, so real size
  reduction of scan-heavy PDFs is out of scope for now (would need Ghostscript, which
  is AGPL/commercial). Deferred with page numbers, watermarks, and split to a later pass.
  
  
  
  This is a PySide6 desktop app (a PDF Combiner). The README's run commands use Linux/macOS syntax â here's the Windows equivalent.

Prerequisites

- Install Python 3.9+ from python.org. During install, check "Add python.exe to PATH".

Run on Windows

Open PowerShell (or Command Prompt) in the project folder and run:

# 1. Create a virtual environment
python -m venv .venv

# 2. Activate it  (PowerShell)
.\.venv\Scripts\Activate.ps1
#   ...or in Command Prompt (cmd.exe):
#   .venv\Scripts\activate.bat

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
python main.py

That opens the PDF Combiner window.

If PowerShell blocks the activate script

You may see "running scripts is disabled on this system". Fix it once with:
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
Then re-run the activate command. (Alternatively, just use cmd.exe with the .bat file.)
