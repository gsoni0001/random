"""PDF engine: pure, framework-free operations built on pypdf (+ pypdfium2).

No Qt imports here so every function is unit-testable with plain pytest and can
run on a worker thread. The UI and workers call into this module; it never
calls back into them.

Gotchas handled here (surfaced by research):
- Encrypted inputs must be decrypted *before* merging, or pypdf raises
  FileNotDecryptedError. We detect encryption and decrypt with a supplied
  password.
- Rotation is only meaningful in 90-degree steps.
- Thumbnail rendering (pypdfium2 + Pillow) is optional; if either import or the
  render fails we return None and the UI shows an info-only preview.
"""
from __future__ import annotations

import io
import os
import threading
from dataclasses import dataclass

from pypdf import PdfReader, PdfWriter, Transformation

# PDFium (pypdfium2) is NOT thread-safe. Metadata workers run in parallel, so
# every pypdfium2 call must hold this process-wide lock or the library corrupts
# memory (double-free) when two threads render at once.
_PDFIUM_LOCK = threading.Lock()

# pypdf's AES-256 identifier; fall back if this build uses the older name.
_ENCRYPT_ALGORITHM = "AES-256-R5"

# Target page sizes in PDF points (1 pt = 1/72"), given portrait (w < h).
# "original" keeps each page as-is. Landscape pages use the swapped dimensions.
PAGE_SIZES: dict[str, tuple[float, float] | None] = {
    "original": None,
    "a4": (595.0, 842.0),
    "letter": (612.0, 792.0),
    "legal": (612.0, 1008.0),
}


@dataclass
class PdfInfo:
    """Result of inspecting a single PDF."""

    page_count: int
    size_bytes: int
    is_encrypted: bool
    unlocked: bool  # True if we could read the pages (not encrypted, or decrypted)


@dataclass
class MergeItem:
    """One source file's contribution to the merge."""

    path: str
    password: str | None = None
    page_range: str = "all"
    rotation: int = 0  # 0 / 90 / 180 / 270


def parse_page_range(spec: str, page_count: int) -> list[int]:
    """Parse a 1-based page-range spec into 0-based page indices.

    Accepts forms like "1-3,5,8-", "-3" (from start), "8-" (to end), a bare
    page number, or "" / "all" for every page. Order is preserved as written,
    so "5,1-2" yields [4, 0, 1]. Raises ValueError on anything out of bounds.
    """
    text = (spec or "").strip().lower()
    if text in ("", "all"):
        return list(range(page_count))

    indices: list[int] = []
    for raw in text.split(","):
        token = raw.strip()
        if not token:
            continue
        try:
            if "-" in token:
                a, _, b = token.partition("-")
                start = int(a) if a.strip() else 1
                end = int(b) if b.strip() else page_count
            else:
                start = end = int(token)
        except ValueError:
            raise ValueError("'{}' is not a valid page range".format(token))
        if start < 1 or end > page_count or start > end:
            raise ValueError(
                "range '{}' is out of bounds for {} page(s)".format(token, page_count)
            )
        indices.extend(range(start - 1, end))

    if not indices:
        raise ValueError("empty page range")
    return indices


def read_metadata(path: str, password: str | None = None) -> PdfInfo:
    """Read page count, size, and encryption status of a PDF.

    If the file is encrypted and no (or a wrong) password is given, returns
    unlocked=False with page_count=0 so the caller can prompt for a password.
    """
    size = os.path.getsize(path)
    reader = PdfReader(path)
    if reader.is_encrypted:
        if not password or not reader.decrypt(password):
            return PdfInfo(0, size, is_encrypted=True, unlocked=False)
        return PdfInfo(len(reader.pages), size, is_encrypted=True, unlocked=True)
    return PdfInfo(len(reader.pages), size, is_encrypted=False, unlocked=True)


def verify_password(path: str, password: str) -> bool:
    """Return True if `password` unlocks the (encrypted) PDF at `path`."""
    reader = PdfReader(path)
    if not reader.is_encrypted:
        return True
    return bool(reader.decrypt(password))


def render_thumbnail(
    path: str, password: str | None = None, max_px: int = 320
) -> bytes | None:
    """Render page 1 to PNG bytes, scaled to fit `max_px`. None if unavailable.

    Kept Qt-free: returns encoded PNG the UI turns into a QPixmap. Any missing
    dependency or render error degrades to None rather than raising.
    """
    try:
        import pypdfium2 as pdfium  # optional dependency
    except Exception:
        return None
    # Serialize all PDFium access — the library is not thread-safe (see the lock
    # definition above). Rendering is fast, so holding the lock is cheap.
    with _PDFIUM_LOCK:
        pdf = None
        try:
            pdf = pdfium.PdfDocument(path, password=password)
            page = pdf[0]
            width, height = page.get_size()
            scale = max_px / max(width, height) if max(width, height) else 1.0
            bitmap = page.render(scale=scale)
            pil_image = bitmap.to_pil()
            buf = io.BytesIO()
            pil_image.save(buf, format="PNG")
            return buf.getvalue()
        except Exception:
            return None
        finally:
            if pdf is not None:
                try:
                    pdf.close()
                except Exception:
                    pass


def _add_normalized_page(
    writer: PdfWriter, src, rotation: int, target: tuple[float, float]
):
    """Scale `src` to fit a target-size page (aspect preserved, centered).

    Any rotation — the file's inherent /Rotate plus the user's chosen rotation —
    is baked into the transform, and the target page's orientation is matched to
    the (rotated) content so portrait stays portrait and landscape stays
    landscape. Returns the new page.
    """
    w = float(src.mediabox.width)
    h = float(src.mediabox.height)
    total = (int(getattr(src, "rotation", 0) or 0) + rotation) % 360

    # rotated content size + the translation that brings it back into the
    # positive quadrant after rotating about the origin
    if total in (90, 270):
        rw, rh = h, w
    else:
        rw, rh = w, h
    shift = {0: (0.0, 0.0), 90: (h, 0.0), 180: (w, h), 270: (0.0, w)}[total]

    pw, ph = target  # portrait dims (pw < ph)
    # match target to content orientation; ties (square) default to portrait
    tw, th = (ph, pw) if rw > rh else (pw, ph)

    scale = min(tw / rw, th / rh)
    tx = (tw - rw * scale) / 2.0
    ty = (th - rh * scale) / 2.0

    op = (
        Transformation()
        .rotate(total)
        .translate(shift[0], shift[1])
        .scale(scale)
        .translate(tx, ty)
    )
    dest = writer.add_blank_page(width=tw, height=th)
    dest.merge_transformed_page(src, op)
    return dest


def merge(
    items: list[MergeItem],
    output_path: str,
    add_bookmarks: bool = False,
    output_password: str | None = None,
    page_size: str = "original",
    progress_cb=None,
) -> str:
    """Merge `items` into a single PDF at `output_path`.

    Applies each item's page range and rotation in list order, optionally adds
    one bookmark per source file, and optionally AES-256-encrypts the output.
    `progress_cb(percent, label)` is called before each file and at completion.
    Returns the output path.
    """
    if not items:
        raise ValueError("no files to merge")

    target = PAGE_SIZES.get((page_size or "original").lower())

    writer = PdfWriter()
    total = len(items)
    for i, item in enumerate(items):
        if progress_cb:
            progress_cb(int(i / total * 100), os.path.basename(item.path))

        reader = PdfReader(item.path)
        if reader.is_encrypted:
            if not item.password or not reader.decrypt(item.password):
                raise ValueError(
                    "'{}' is password-protected; the correct password is "
                    "required to merge it".format(os.path.basename(item.path))
                )

        indices = parse_page_range(item.page_range, len(reader.pages))
        start_index = len(writer.pages)
        for idx in indices:
            page = reader.pages[idx]
            if target is None:
                # keep original size; rotation via the page's /Rotate flag
                if item.rotation:
                    page.rotate(item.rotation)
                writer.add_page(page)
            else:
                # scale-to-fit a uniform page; rotation baked into the transform
                _add_normalized_page(writer, page, item.rotation, target)

        if add_bookmarks:
            title = os.path.splitext(os.path.basename(item.path))[0]
            writer.add_outline_item(title, start_index)

    if output_password:
        try:
            writer.encrypt(output_password, algorithm=_ENCRYPT_ALGORITHM)
        except (TypeError, ValueError):
            writer.encrypt(output_password, algorithm="AES-256")

    with open(output_path, "wb") as fh:
        writer.write(fh)

    if progress_cb:
        progress_cb(100, "Done")
    return output_path
