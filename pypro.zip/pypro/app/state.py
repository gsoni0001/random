"""Application state: the single source of truth for PDF Combiner.

Holds the ordered list of source files plus their per-file settings and the
output options. The UI renders this and forwards intent; it holds no PDF logic.
Slow work (reading metadata, rendering thumbnails, merging) is dispatched to
workers here, and their results are relayed outward as Qt signals.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from PySide6.QtCore import QObject, QThreadPool, QTimer, Signal

from app import pdf_engine
from app.pdf_engine import MergeItem, PdfInfo
from app.workers import MergeWorker, MetadataWorker


@dataclass
class SourceFile:
    path: str
    filename: str
    page_count: int = 0
    size_bytes: int = 0
    is_encrypted: bool = False
    unlocked: bool = True
    password: str | None = None
    page_range: str = "all"
    rotation: int = 0            # 0 / 90 / 180 / 270
    thumbnail_png: bytes | None = None
    loading: bool = True
    error: str | None = None


@dataclass
class OutputOptions:
    output_path: str = ""
    add_bookmarks: bool = True
    encrypt_output: bool = False
    output_password: str = ""
    page_size: str = "original"   # original | a4 | letter | legal


class AppState(QObject):
    filesChanged = Signal()             # add / remove / reorder
    fileUpdated = Signal(int)           # metadata or per-file settings changed
    selectionChanged = Signal(int)      # -1 when nothing selected
    needPassword = Signal(int)          # an encrypted file needs unlocking
    outputOptionsChanged = Signal()
    mergeProgress = Signal(int, str)
    mergeFinished = Signal(str)
    mergeFailed = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self.files: list[SourceFile] = []
        self.output = OutputOptions()
        self._selected = -1
        self._pool = QThreadPool.globalInstance()
        self._workers: set[object] = set()   # keep workers alive until done

    # ----- selection ------------------------------------------------------ #
    @property
    def selected(self) -> int:
        return self._selected

    def select(self, index: int) -> None:
        self._selected = index if 0 <= index < len(self.files) else -1
        self.selectionChanged.emit(self._selected)

    def selected_file(self) -> SourceFile | None:
        return self.files[self._selected] if 0 <= self._selected < len(self.files) else None

    # ----- adding files --------------------------------------------------- #
    def add_paths(self, paths: list[str]) -> None:
        existing = {f.path for f in self.files}
        new_indices: list[int] = []
        for path in paths:
            if not path.lower().endswith(".pdf") or path in existing:
                continue
            self.files.append(SourceFile(path=path, filename=os.path.basename(path)))
            existing.add(path)
            new_indices.append(len(self.files) - 1)
        if new_indices:
            self.filesChanged.emit()
            for i in new_indices:      # read metadata only for the freshly added rows
                self._load_metadata(i)

    def add_folder(self, folder: str) -> None:
        try:
            names = sorted(os.listdir(folder))
        except OSError:
            return
        self.add_paths([os.path.join(folder, n) for n in names if n.lower().endswith(".pdf")])

    def _load_metadata(self, index: int) -> None:
        f = self.files[index]
        f.loading = True
        worker = MetadataWorker(index, f.path, f.password)
        worker.setAutoDelete(False)
        self._workers.add(worker)
        worker.signals.loaded.connect(self._on_metadata)
        worker.signals.failed.connect(self._on_metadata_failed)
        worker.signals.loaded.connect(lambda *_: self._retire(worker))
        worker.signals.failed.connect(lambda *_: self._retire(worker))
        self._pool.start(worker)

    def _on_metadata(self, index: int, info: PdfInfo, thumb: object) -> None:
        if not (0 <= index < len(self.files)):
            return
        f = self.files[index]
        f.page_count = info.page_count
        f.size_bytes = info.size_bytes
        f.is_encrypted = info.is_encrypted
        f.unlocked = info.unlocked
        f.thumbnail_png = thumb if isinstance(thumb, (bytes, bytearray)) else None
        f.loading = False
        f.error = None
        self.fileUpdated.emit(index)
        if info.is_encrypted and not info.unlocked:
            self.needPassword.emit(index)

    def _on_metadata_failed(self, index: int, message: str) -> None:
        if 0 <= index < len(self.files):
            self.files[index].loading = False
            self.files[index].error = message
            self.fileUpdated.emit(index)

    # ----- per-file mutations --------------------------------------------- #
    def unlock(self, index: int, password: str) -> None:
        """Supply a password for an encrypted file and re-read its metadata."""
        if 0 <= index < len(self.files):
            self.files[index].password = password
            self._load_metadata(index)
            self.fileUpdated.emit(index)

    def set_range(self, index: int, spec: str) -> str | None:
        """Set a file's page range. Returns an error string if invalid, else None."""
        if not (0 <= index < len(self.files)):
            return None
        f = self.files[index]
        if f.unlocked and f.page_count:
            try:
                pdf_engine.parse_page_range(spec, f.page_count)
            except ValueError as exc:
                return str(exc)
        f.page_range = spec.strip() or "all"
        self.fileUpdated.emit(index)
        return None

    def set_rotation(self, index: int, degrees: int) -> None:
        if 0 <= index < len(self.files):
            self.files[index].rotation = degrees % 360
            self.fileUpdated.emit(index)

    def remove(self, index: int) -> None:
        if 0 <= index < len(self.files):
            del self.files[index]
            if self._selected >= len(self.files):
                self._selected = len(self.files) - 1
            self.filesChanged.emit()

    def move(self, index: int, delta: int) -> None:
        j = index + delta
        if 0 <= index < len(self.files) and 0 <= j < len(self.files):
            self.files[index], self.files[j] = self.files[j], self.files[index]
            self._selected = j
            self.filesChanged.emit()

    def set_order(self, paths: list[str]) -> None:
        """Reorder the list to match `paths` (used after drag-and-drop)."""
        by_path = {f.path: f for f in self.files}
        new = [by_path[p] for p in paths if p in by_path]
        if len(new) == len(self.files):
            self.files = new
            self.filesChanged.emit()

    # ----- output options ------------------------------------------------- #
    def set_output_path(self, path: str) -> None:
        self.output.output_path = path
        self.outputOptionsChanged.emit()

    def set_bookmarks(self, enabled: bool) -> None:
        self.output.add_bookmarks = enabled
        self.outputOptionsChanged.emit()

    def set_encrypt(self, enabled: bool, password: str = "") -> None:
        self.output.encrypt_output = enabled
        self.output.output_password = password
        self.outputOptionsChanged.emit()

    def set_page_size(self, page_size: str) -> None:
        self.output.page_size = page_size
        self.outputOptionsChanged.emit()

    # ----- merge ---------------------------------------------------------- #
    def can_merge(self) -> bool:
        if not self.output.output_path:
            return False
        if self.output.encrypt_output and not self.output.output_password:
            return False
        usable = [f for f in self.files if f.unlocked and f.page_count > 0]
        if not usable:
            return False
        return not any(f.loading or f.error for f in self.files)

    def blocking_reason(self) -> str:
        if not self.files:
            return "Add at least one PDF."
        if any(f.loading for f in self.files):
            return "Still reading file info…"
        if any(f.is_encrypted and not f.unlocked for f in self.files):
            return "Unlock all encrypted files first."
        if not self.output.output_path:
            return "Choose an output file."
        if self.output.encrypt_output and not self.output.output_password:
            return "Set a password for the encrypted output."
        return ""

    def request_merge(self) -> None:
        items = [
            MergeItem(
                path=f.path,
                password=f.password,
                page_range=f.page_range,
                rotation=f.rotation,
            )
            for f in self.files
            if f.unlocked and f.page_count > 0
        ]
        worker = MergeWorker(
            items,
            self.output.output_path,
            self.output.add_bookmarks,
            self.output.output_password if self.output.encrypt_output else None,
            self.output.page_size,
        )
        worker.setAutoDelete(False)
        self._workers.add(worker)
        worker.signals.progress.connect(self.mergeProgress)
        worker.signals.finished.connect(self._on_merge_finished)
        worker.signals.failed.connect(self._on_merge_failed)
        worker.signals.finished.connect(lambda *_: self._retire(worker))
        worker.signals.failed.connect(lambda *_: self._retire(worker))
        self._pool.start(worker)

    def _on_merge_finished(self, path: str) -> None:
        self.mergeFinished.emit(path)

    def _on_merge_failed(self, message: str) -> None:
        self.mergeFailed.emit(message)

    def _retire(self, worker: object) -> None:
        # Drop our reference *after* the current emission returns, so we never
        # delete a signal sender mid-emit or a still-running sibling worker.
        QTimer.singleShot(0, lambda: self._workers.discard(worker))
