"""Centralized theming via Qt Style Sheets (QSS).

Every color/token lives here so styling stays out of widget logic. The palette
matches the design spec; switching LIGHT to DARK is a one-line change.
"""
from __future__ import annotations

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication

LIGHT = {
    "bg": "#F5F6F8",
    "surface": "#FFFFFF",
    "ink": "#1E2430",
    "muted": "#6B7280",
    "accent": "#2F6FED",
    "accent_hover": "#4581F2",
    "warn": "#E0A100",
    "border": "#D8DCE3",
}

DARK = {
    "bg": "#1B1E24",
    "surface": "#242832",
    "ink": "#E8EAED",
    "muted": "#9AA1AC",
    "accent": "#2F6FED",
    "accent_hover": "#4581F2",
    "warn": "#E0A100",
    "border": "#343A45",
}

_QSS = """
QWidget {{ background: {bg}; color: {ink}; font-size: 14px; }}
QLabel#heading {{ font-size: 18px; font-weight: 600; }}
QLabel#muted {{ color: {muted}; }}
QLabel#thumb {{
    background: {surface}; border: 1px solid {border}; border-radius: 8px;
}}
QListWidget, QLineEdit, QComboBox {{
    background: {surface}; border: 1px solid {border}; border-radius: 6px;
    padding: 4px 6px;
}}
QListWidget::item {{ padding: 6px 4px; }}
QListWidget::item:selected {{ background: {accent}; color: white; border-radius: 4px; }}
QPushButton {{
    background: {surface}; color: {ink};
    border: 1px solid {border}; border-radius: 6px; padding: 6px 12px;
}}
QPushButton:hover {{ border-color: {accent}; }}
QPushButton:disabled {{ color: {muted}; }}
QPushButton#primary {{
    background: {accent}; color: white; border: none; font-weight: 600;
    padding: 8px 20px;
}}
QPushButton#primary:hover {{ background: {accent_hover}; }}
QPushButton#primary:disabled {{ background: {border}; color: {muted}; }}
QPushButton#rotate:checked {{ background: {accent}; color: white; border: none; }}
QProgressBar {{
    border: 1px solid {border}; border-radius: 6px; text-align: center;
    background: {surface};
}}
QProgressBar::chunk {{ background: {accent}; border-radius: 5px; }}
QFrame#card {{
    background: {surface}; border: 1px solid {border}; border-radius: 8px;
}}
"""


def apply_theme(app: QApplication, dark: bool = False) -> None:
    tokens = DARK if dark else LIGHT
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(tokens["bg"]))
    pal.setColor(QPalette.WindowText, QColor(tokens["ink"]))
    pal.setColor(QPalette.Base, QColor(tokens["surface"]))
    pal.setColor(QPalette.Text, QColor(tokens["ink"]))
    app.setPalette(pal)
    app.setStyleSheet(_QSS.format(**tokens))
