"""Small modal dialogs: the encrypted-input password prompt."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QLineEdit,
    QVBoxLayout,
)


class PasswordDialog(QDialog):
    """Prompt for the password of an encrypted input PDF."""

    def __init__(self, filename: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Encrypted PDF")
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel('"{}" is password-protected.\nEnter its password to include '
                   "it in the merge.".format(filename))
        )
        self.field = QLineEdit()
        self.field.setEchoMode(QLineEdit.Password)
        self.field.setPlaceholderText("Password")
        layout.addWidget(self.field)

        show = QCheckBox("Show password")
        show.toggled.connect(
            lambda on: self.field.setEchoMode(
                QLineEdit.Normal if on else QLineEdit.Password
            )
        )
        layout.addWidget(show)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Unlock")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def password(self) -> str:
        return self.field.text()
