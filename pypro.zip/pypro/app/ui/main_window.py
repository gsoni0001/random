"""Main window: the master-detail merge canvas.

Left: a drag-to-reorder source list whose order *is* the merge order.
Right: the preview/settings panel. Bottom: the output + merge action bar.
The window renders store state and forwards intent; it holds no PDF logic.
"""
from __future__ import annotations

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressDialog,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from app.state import AppState
from app.ui.dialogs import PasswordDialog
from app.ui.preview_panel import PreviewPanel


class ReorderList(QListWidget):
    """A list whose rows can be reordered by drag-and-drop."""

    orderChanged = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.setDragDropMode(QAbstractItemView.InternalMove)
        self.setSelectionMode(QAbstractItemView.SingleSelection)

    def dropEvent(self, event) -> None:
        super().dropEvent(event)
        self.orderChanged.emit()


class MainWindow(QMainWindow):
    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self._rebuilding = False
        self._progress: QProgressDialog | None = None
        self.setWindowTitle("PDF Combiner")
        self.resize(900, 620)
        self.setMinimumSize(660, 520)

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_left())
        self.preview = PreviewPanel(state)
        splitter.addWidget(self.preview)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)

        central = QWidget()
        outer = QVBoxLayout(central)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(10)
        outer.addWidget(splitter, stretch=1)
        outer.addLayout(self._build_action_bar())
        self.setCentralWidget(central)
        self.status = self.statusBar()

        # store -> view
        state.filesChanged.connect(self._rebuild_list)
        state.fileUpdated.connect(self._refresh_row)
        state.outputOptionsChanged.connect(self._refresh_status)
        state.needPassword.connect(self._prompt_password)
        state.mergeProgress.connect(self._on_progress)
        state.mergeFinished.connect(self._on_merge_finished)
        state.mergeFailed.connect(self._on_merge_failed)

        self._refresh_status()

    # ----- construction --------------------------------------------------- #
    def _build_left(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        toolbar = QHBoxLayout()
        add_files = QPushButton("+ Add Files")
        add_folder = QPushButton("+ Add Folder")
        add_files.clicked.connect(self._add_files)
        add_folder.clicked.connect(self._add_folder)
        toolbar.addWidget(add_files)
        toolbar.addWidget(add_folder)
        toolbar.addStretch()
        layout.addLayout(toolbar)

        self.list = ReorderList()
        self.list.currentRowChanged.connect(self._on_row_changed)
        self.list.orderChanged.connect(self._on_reordered)
        layout.addWidget(self.list, stretch=1)

        reorder = QHBoxLayout()
        up = QPushButton("▲ Up")
        down = QPushButton("▼ Down")
        remove = QPushButton("Remove")
        up.clicked.connect(lambda: self._move(-1))
        down.clicked.connect(lambda: self._move(1))
        remove.clicked.connect(self._remove)
        reorder.addWidget(up)
        reorder.addWidget(down)
        reorder.addStretch()
        reorder.addWidget(remove)
        layout.addLayout(reorder)
        return panel

    def _build_action_bar(self) -> QVBoxLayout:
        # Two rows so the output path always has room, even on narrow windows:
        #   row 1: Output: [ path ....................... ] [Browse…]
        #   row 2: [Bookmarks] [Encrypt] [password]  ......  [Merge PDFs]
        bar = QVBoxLayout()
        bar.setSpacing(8)

        top = QHBoxLayout()
        top.addWidget(QLabel("Output:"))
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("Choose where to save the merged PDF…")
        self.output_edit.textChanged.connect(self.state.set_output_path)
        top.addWidget(self.output_edit, stretch=1)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._choose_output)
        top.addWidget(browse)
        bar.addLayout(top)

        bottom = QHBoxLayout()
        bottom.addWidget(QLabel("Page size:"))
        self.size_combo = QComboBox()
        for label, key in (
            ("Original", "original"),
            ("A4", "a4"),
            ("Letter", "letter"),
            ("Legal", "legal"),
        ):
            self.size_combo.addItem(label, key)
        self.size_combo.setToolTip(
            "Scale every page to a uniform size (fit, centered), or keep each "
            "page's original dimensions."
        )
        self.size_combo.currentIndexChanged.connect(
            lambda: self.state.set_page_size(self.size_combo.currentData())
        )
        bottom.addWidget(self.size_combo)
        bottom.addSpacing(12)

        self.bookmarks_cb = QCheckBox("Bookmarks")
        self.bookmarks_cb.setChecked(True)
        self.bookmarks_cb.toggled.connect(self.state.set_bookmarks)
        bottom.addWidget(self.bookmarks_cb)

        self.encrypt_cb = QCheckBox("Encrypt")
        self.encrypt_cb.toggled.connect(self._on_encrypt_toggled)
        bottom.addWidget(self.encrypt_cb)

        self.pw_edit = QLineEdit()
        self.pw_edit.setEchoMode(QLineEdit.Password)
        self.pw_edit.setPlaceholderText("Output password")
        self.pw_edit.setVisible(False)
        self.pw_edit.setMinimumWidth(160)
        self.pw_edit.textChanged.connect(self._on_password_typed)
        bottom.addWidget(self.pw_edit)

        bottom.addStretch()
        self.merge_btn = QPushButton("Merge PDFs")
        self.merge_btn.setObjectName("primary")
        self.merge_btn.clicked.connect(self._merge)
        bottom.addWidget(self.merge_btn)
        bar.addLayout(bottom)
        return bar

    # ----- list sync ------------------------------------------------------ #
    def _rebuild_list(self) -> None:
        self._rebuilding = True
        self.list.clear()
        for f in self.state.files:
            item = QListWidgetItem(self._row_text(f))
            item.setData(Qt.UserRole, f.path)
            self.list.addItem(item)
        if 0 <= self.state.selected < self.list.count():
            self.list.setCurrentRow(self.state.selected)
        self._rebuilding = False
        self._refresh_status()

    def _row_text(self, f) -> str:
        if f.loading:
            meta = "reading…"
        elif f.error:
            meta = "error"
        elif f.is_encrypted and not f.unlocked:
            meta = "🔒 locked"
        else:
            rng = "all" if f.page_range == "all" else f.page_range
            meta = "{}p · {}".format(f.page_count, rng)
            if f.rotation:
                meta += " · {}°".format(f.rotation)
        return "{}.  {}   ({})".format(self.state.files.index(f) + 1, f.filename, meta)

    def _refresh_row(self, index: int) -> None:
        if 0 <= index < self.list.count():
            self.list.item(index).setText(self._row_text(self.state.files[index]))
        self._refresh_status()

    def _on_row_changed(self, row: int) -> None:
        if not self._rebuilding:
            self.state.select(row)

    def _on_reordered(self) -> None:
        paths = [self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())]
        self.state.set_order(paths)

    # ----- intent --------------------------------------------------------- #
    def _add_files(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Add PDF files", "", "PDF files (*.pdf)"
        )
        if paths:
            self.state.add_paths(paths)

    def _add_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Add all PDFs in folder")
        if folder:
            self.state.add_folder(folder)

    def _move(self, delta: int) -> None:
        if self.state.selected >= 0:
            self.state.move(self.state.selected, delta)

    def _remove(self) -> None:
        if self.state.selected >= 0:
            self.state.remove(self.state.selected)

    def _choose_output(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save merged PDF as", "merged.pdf", "PDF files (*.pdf)"
        )
        if path:
            if not path.lower().endswith(".pdf"):
                path += ".pdf"
            self.output_edit.setText(path)

    def _on_encrypt_toggled(self, on: bool) -> None:
        self.pw_edit.setVisible(on)
        self.state.set_encrypt(on, self.pw_edit.text() if on else "")

    def _on_password_typed(self, text: str) -> None:
        if self.encrypt_cb.isChecked():
            self.state.set_encrypt(True, text)

    def _prompt_password(self, index: int) -> None:
        f = self.state.files[index]
        dlg = PasswordDialog(f.filename, self)
        if dlg.exec() and dlg.password():
            self.state.unlock(index, dlg.password())

    # ----- merge ---------------------------------------------------------- #
    def _merge(self) -> None:
        if not self.state.can_merge():
            reason = self.state.blocking_reason() or "Cannot merge yet."
            QMessageBox.information(self, "Not ready", reason)
            return
        if os.path.exists(self.state.output.output_path):
            resp = QMessageBox.question(
                self, "Overwrite?",
                "{} already exists. Overwrite it?".format(
                    os.path.basename(self.state.output.output_path)
                ),
            )
            if resp != QMessageBox.Yes:
                return
        # No cancel button: the write is a single final step, so a mid-merge
        # cancel could not safely stop it. Progress reflects per-file work.
        self._progress = QProgressDialog("Preparing…", None, 0, 100, self)
        self._progress.setWindowTitle("Merging")
        self._progress.setWindowModality(Qt.WindowModal)
        self._progress.setMinimumDuration(0)
        self._progress.setValue(0)
        self.merge_btn.setEnabled(False)
        self.state.request_merge()

    def _on_progress(self, pct: int, label: str) -> None:
        if self._progress:
            self._progress.setValue(pct)
            self._progress.setLabelText("Processing: {}".format(label))

    def _on_merge_finished(self, path: str) -> None:
        if self._progress:
            self._progress.setValue(100)
            self._progress.close()
            self._progress = None
        self.merge_btn.setEnabled(True)
        QMessageBox.information(
            self, "Merge complete", "Saved merged PDF to:\n{}".format(path)
        )
        self._refresh_status()

    def _on_merge_failed(self, message: str) -> None:
        if self._progress:
            self._progress.close()
            self._progress = None
        self.merge_btn.setEnabled(True)
        QMessageBox.critical(self, "Merge failed", message)

    # ----- status --------------------------------------------------------- #
    def _refresh_status(self) -> None:
        usable = [f for f in self.state.files if f.unlocked and f.page_count > 0]
        total_pages = sum(f.page_count for f in usable)
        self.merge_btn.setEnabled(self.state.can_merge())
        reason = self.state.blocking_reason()
        if reason:
            self.status.showMessage(reason)
        else:
            self.status.showMessage(
                "{} file(s) · {} page(s) ready to merge".format(len(usable), total_pages)
            )
