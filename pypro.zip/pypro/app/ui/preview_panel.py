"""Right-hand detail panel: thumbnail + info + per-file range/rotation controls.

Renders whatever SourceFile is selected and forwards edits to the store. It
holds no PDF logic of its own.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QButtonGroup,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.state import AppState, SourceFile

_ROTATIONS = (0, 90, 180, 270)


def _human_size(n: int) -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return "{:.0f} {}".format(size, unit) if unit == "B" else "{:.1f} {}".format(size, unit)
        size /= 1024
    return "{:.1f} GB".format(size)


class PreviewPanel(QWidget):
    def __init__(self, state: AppState) -> None:
        super().__init__()
        self.state = state
        self._pixmap: QPixmap | None = None   # full-res thumbnail, rescaled on resize

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        self.header = QLabel("No file selected")
        self.header.setObjectName("heading")
        self.header.setWordWrap(True)
        root.addWidget(self.header)

        self.thumb = QLabel("Preview")
        self.thumb.setObjectName("thumb")
        self.thumb.setAlignment(Qt.AlignCenter)
        self.thumb.setMinimumHeight(200)
        root.addWidget(self.thumb, stretch=1)

        info = QFormLayout()
        self.pages_lbl = QLabel("-")
        self.size_lbl = QLabel("-")
        self.enc_lbl = QLabel("-")
        info.addRow(self._muted("Pages:"), self.pages_lbl)
        info.addRow(self._muted("Size:"), self.size_lbl)
        info.addRow(self._muted("Encryption:"), self.enc_lbl)
        root.addLayout(info)

        self.range_edit = QLineEdit()
        self.range_edit.setPlaceholderText("e.g. 1-3,5,8-  (blank = all pages)")
        self.range_edit.editingFinished.connect(self._commit_range)
        root.addWidget(self._muted("Page range:"))
        root.addWidget(self.range_edit)

        self.range_error = QLabel("")
        self.range_error.setObjectName("muted")
        self.range_error.setWordWrap(True)
        root.addWidget(self.range_error)

        root.addWidget(self._muted("Rotation:"))
        rot_row = QHBoxLayout()
        self.rot_group = QButtonGroup(self)
        self.rot_group.setExclusive(True)
        for deg in _ROTATIONS:
            btn = QPushButton("{}°".format(deg))
            btn.setObjectName("rotate")
            btn.setCheckable(True)
            self.rot_group.addButton(btn, deg)
            rot_row.addWidget(btn)
        self.rot_group.idClicked.connect(self._commit_rotation)
        root.addLayout(rot_row)
        root.addStretch()

        self.setEnabled(False)
        state.selectionChanged.connect(self._render)
        state.fileUpdated.connect(self._on_file_updated)

    def _muted(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("muted")
        return lbl

    # ----- rendering ------------------------------------------------------ #
    def _on_file_updated(self, index: int) -> None:
        if index == self.state.selected:
            self._render(index)

    def _render(self, index: int) -> None:
        f = self.state.selected_file()
        if f is None:
            self.setEnabled(False)
            self.header.setText("No file selected")
            self.thumb.setPixmap(QPixmap())
            self.thumb.setText("Preview")
            self.pages_lbl.setText("-")
            self.size_lbl.setText("-")
            self.enc_lbl.setText("-")
            self.range_error.setText("")
            return

        self.setEnabled(True)
        self.header.setText(f.filename)
        self._set_thumb(f)
        self.pages_lbl.setText("Loading…" if f.loading else str(f.page_count))
        self.size_lbl.setText(_human_size(f.size_bytes) if f.size_bytes else "-")
        if f.error:
            self.enc_lbl.setText("Error: {}".format(f.error))
        elif f.is_encrypted and not f.unlocked:
            self.enc_lbl.setText("🔒 Locked — password needed")
        elif f.is_encrypted:
            self.enc_lbl.setText("🔓 Unlocked (AES)")
        else:
            self.enc_lbl.setText("None")

        # reflect settings without re-triggering commits
        self.range_edit.blockSignals(True)
        self.range_edit.setText("" if f.page_range == "all" else f.page_range)
        self.range_edit.blockSignals(False)
        btn = self.rot_group.button(f.rotation)
        if btn:
            btn.setChecked(True)
        self.range_error.setText("")

    def _set_thumb(self, f: SourceFile) -> None:
        if f.thumbnail_png:
            pix = QPixmap()
            if pix.loadFromData(f.thumbnail_png, "PNG"):
                self._pixmap = pix
                self._rescale_thumb()
                return
        self._pixmap = None
        self.thumb.setPixmap(QPixmap())
        self.thumb.setText("Loading…" if f.loading else "Preview unavailable")

    def _rescale_thumb(self) -> None:
        """Scale the stored thumbnail to fill the current box (called on resize)."""
        if self._pixmap is None or self._pixmap.isNull():
            return
        target_w = max(self.thumb.width() - 16, 16)
        target_h = max(self.thumb.height() - 16, 16)
        self.thumb.setPixmap(
            self._pixmap.scaled(
                target_w, target_h, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
        )

    def resizeEvent(self, event) -> None:  # noqa: N802 (Qt override)
        super().resizeEvent(event)
        self._rescale_thumb()

    # ----- intent --------------------------------------------------------- #
    def _commit_range(self) -> None:
        idx = self.state.selected
        if idx < 0:
            return
        error = self.state.set_range(idx, self.range_edit.text())
        self.range_error.setText(error or "")

    def _commit_rotation(self, degrees: int) -> None:
        if self.state.selected >= 0:
            self.state.set_rotation(self.state.selected, degrees)
