"""Background workers. Every slow pypdf/pypdfium2 call runs here, off the UI
thread, and reports back through Qt signals — never by touching widgets.

QRunnables are auto-deleted by the thread pool the instant run() returns, which
can drop a queued signal before its slot fires. The store keeps a reference to
each worker and calls setAutoDelete(False); see app/state.py.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from app import pdf_engine
from app.pdf_engine import MergeItem


class MetadataSignals(QObject):
    # index, PdfInfo, thumbnail PNG bytes or None
    loaded = Signal(int, object, object)
    failed = Signal(int, str)


class MetadataWorker(QRunnable):
    """Read a file's page count / size / encryption and render its thumbnail."""

    def __init__(self, index: int, path: str, password: str | None) -> None:
        super().__init__()
        self.index = index
        self.path = path
        self.password = password
        self.signals = MetadataSignals()

    @Slot()
    def run(self) -> None:
        try:
            info = pdf_engine.read_metadata(self.path, self.password)
            thumb = None
            if info.unlocked:
                thumb = pdf_engine.render_thumbnail(self.path, self.password)
            self.signals.loaded.emit(self.index, info, thumb)
        except Exception as exc:  # surface any read error to the row
            self.signals.failed.emit(self.index, str(exc))


class MergeSignals(QObject):
    progress = Signal(int, str)  # percent, current-file label
    finished = Signal(str)       # output path
    failed = Signal(str)         # error message


class MergeWorker(QRunnable):
    """Run the full merge, streaming progress back to the UI."""

    def __init__(
        self,
        items: list[MergeItem],
        output_path: str,
        add_bookmarks: bool,
        output_password: str | None,
        page_size: str = "original",
    ) -> None:
        super().__init__()
        self.items = items
        self.output_path = output_path
        self.add_bookmarks = add_bookmarks
        self.output_password = output_password
        self.page_size = page_size
        self.signals = MergeSignals()

    @Slot()
    def run(self) -> None:
        try:
            pdf_engine.merge(
                self.items,
                self.output_path,
                add_bookmarks=self.add_bookmarks,
                output_password=self.output_password,
                page_size=self.page_size,
                progress_cb=lambda pct, label: self.signals.progress.emit(pct, label),
            )
            self.signals.finished.emit(self.output_path)
        except Exception as exc:
            self.signals.failed.emit(str(exc))
