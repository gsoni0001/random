"""Entry point for PDF Combiner (PySide6)."""
from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from app.state import AppState
from app.theme import apply_theme
from app.ui.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("PDF Combiner")
    apply_theme(app)                 # light theme; pass dark=True for dark mode

    state = AppState()               # single source of truth
    window = MainWindow(state)       # the view observes state; it owns no logic
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
