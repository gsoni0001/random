"""Shared test fixtures: build small real PDFs on disk with pypdf."""
from __future__ import annotations

import os

import pytest
from pypdf import PdfWriter


def _make_pdf(path: str, pages: int, password: str | None = None) -> str:
    writer = PdfWriter()
    for _ in range(pages):
        writer.add_blank_page(width=200, height=300)
    if password:
        writer.encrypt(password, algorithm="AES-256-R5")
    with open(path, "wb") as fh:
        writer.write(fh)
    return path


@pytest.fixture
def pdfs(tmp_path):
    """Return a factory that writes a PDF with N pages into the temp dir."""
    def factory(name: str, pages: int, password: str | None = None) -> str:
        return _make_pdf(os.path.join(tmp_path, name), pages, password)
    return factory
