"""Unit tests for the pure PDF engine (no Qt)."""
from __future__ import annotations

import pytest
from pypdf import PdfReader

from app import pdf_engine as E


def test_parse_page_range_forms():
    assert E.parse_page_range("", 5) == [0, 1, 2, 3, 4]
    assert E.parse_page_range("all", 3) == [0, 1, 2]
    assert E.parse_page_range("1-3,5", 5) == [0, 1, 2, 4]
    assert E.parse_page_range("8-", 10) == [7, 8, 9]
    assert E.parse_page_range("-3", 10) == [0, 1, 2]
    assert E.parse_page_range("5,1-2", 5) == [4, 0, 1]  # order preserved


@pytest.mark.parametrize("bad", ["0", "6", "3-1", "abc", "1-99"])
def test_parse_page_range_rejects(bad):
    with pytest.raises(ValueError):
        E.parse_page_range(bad, 5)


def test_metadata(pdfs):
    info = E.read_metadata(pdfs("a.pdf", 3))
    assert info.page_count == 3 and not info.is_encrypted and info.unlocked


def test_merge_ranges_rotation_bookmarks(pdfs, tmp_path):
    a = pdfs("a.pdf", 3)
    b = pdfs("b.pdf", 12)
    c = pdfs("c.pdf", 4)
    out = str(tmp_path / "merged.pdf")
    progress = []
    E.merge(
        [
            E.MergeItem(a, page_range="all"),
            E.MergeItem(b, page_range="1-3,5", rotation=90),  # 4 pages
            E.MergeItem(c, page_range="all"),
        ],
        out,
        add_bookmarks=True,
        progress_cb=lambda p, l: progress.append((p, l)),
    )
    reader = PdfReader(out)
    assert len(reader.pages) == 3 + 4 + 4
    assert len(reader.outline) == 3
    assert progress[-1] == (100, "Done")


def test_encrypted_input_flow(pdfs, tmp_path):
    locked = pdfs("locked.pdf", 2, password="secret")
    assert E.verify_password(locked, "secret")
    assert not E.verify_password(locked, "nope")

    info = E.read_metadata(locked)
    assert info.is_encrypted and not info.unlocked and info.page_count == 0

    # merging without the password fails clearly
    with pytest.raises(ValueError, match="password"):
        E.merge([E.MergeItem(locked)], str(tmp_path / "x.pdf"))

    # with the password it succeeds
    out = str(tmp_path / "ok.pdf")
    E.merge([E.MergeItem(locked, password="secret")], out)
    assert len(PdfReader(out).pages) == 2


def test_encrypt_output(pdfs, tmp_path):
    out = str(tmp_path / "enc.pdf")
    E.merge([E.MergeItem(pdfs("a.pdf", 1))], out, output_password="pw")
    assert PdfReader(out).is_encrypted


def _dims(page):
    return (round(float(page.mediabox.width)), round(float(page.mediabox.height)))


def test_page_size_original_preserves_dimensions(tmp_path):
    from pypdf import PdfWriter

    def sized(name, w, h):
        wr = PdfWriter()
        wr.add_blank_page(width=w, height=h)
        p = str(tmp_path / name)
        with open(p, "wb") as fh:
            wr.write(fh)
        return p

    out = str(tmp_path / "orig.pdf")
    E.merge([E.MergeItem(sized("a.pdf", 300, 500)),
             E.MergeItem(sized("b.pdf", 800, 400))], out, page_size="original")
    assert [_dims(p) for p in PdfReader(out).pages] == [(300, 500), (800, 400)]


def test_page_size_normalizes_and_matches_orientation(tmp_path):
    from pypdf import PdfWriter

    def sized(name, w, h):
        wr = PdfWriter()
        wr.add_blank_page(width=w, height=h)
        p = str(tmp_path / name)
        with open(p, "wb") as fh:
            wr.write(fh)
        return p

    portrait = sized("p.pdf", 400, 900)
    landscape = sized("l.pdf", 900, 400)
    out = str(tmp_path / "a4.pdf")
    E.merge([E.MergeItem(portrait), E.MergeItem(landscape)], out, page_size="a4")
    dims = [_dims(p) for p in PdfReader(out).pages]
    assert dims == [(595, 842), (842, 595)]  # portrait->A4 portrait, landscape->A4 landscape

    for target, exp in [("letter", (612, 792)), ("legal", (612, 1008))]:
        o = str(tmp_path / (target + ".pdf"))
        E.merge([E.MergeItem(portrait)], o, page_size=target)
        assert _dims(PdfReader(o).pages[0]) == exp
