"""GUI-level smoke tests: drive the store + workers headlessly (offscreen).

These prove the whole pipeline — add files, read metadata on a worker, and
merge on a worker — works end to end without blocking, using the same signals
the UI listens to. Run with: QT_QPA_PLATFORM=offscreen pytest
"""
from __future__ import annotations

from pypdf import PdfReader

from app.state import AppState


def test_add_files_loads_metadata(qtbot, pdfs):
    state = AppState()
    a = pdfs("a.pdf", 3)
    b = pdfs("b.pdf", 7)
    state.add_paths([a, b])
    assert len(state.files) == 2

    # metadata is read on a worker thread; wait for both rows to finish loading
    qtbot.waitUntil(lambda: all(not f.loading for f in state.files), timeout=5000)
    assert [f.page_count for f in state.files] == [3, 7]
    assert all(f.unlocked for f in state.files)


def test_reorder_and_range_then_merge(qtbot, pdfs, tmp_path):
    state = AppState()
    a = pdfs("a.pdf", 3)
    b = pdfs("b.pdf", 12)
    state.add_paths([a, b])
    qtbot.waitUntil(lambda: all(not f.loading for f in state.files), timeout=5000)

    # put b first, take only pages 1-2 of it
    state.set_order([b, a])
    assert state.set_range(0, "1-2") is None      # valid -> no error
    assert state.set_range(0, "99") is not None    # invalid -> error string

    state.set_output_path(str(tmp_path / "out.pdf"))
    assert state.can_merge()

    with qtbot.waitSignal(state.mergeFinished, timeout=5000) as sig:
        state.request_merge()
    out = sig.args[0]
    # b[1-2] (2) + a[all] (3) = 5 pages, in that order
    assert len(PdfReader(out).pages) == 2 + 3


def test_merge_with_uniform_page_size(qtbot, pdfs, tmp_path):
    from pypdf import PdfWriter, PdfReader

    def sized(name, w, h):
        wr = PdfWriter(); wr.add_blank_page(width=w, height=h)
        p = str(tmp_path / name)
        with open(p, "wb") as fh:
            wr.write(fh)
        return p

    state = AppState()
    state.add_paths([sized("p.pdf", 400, 900), sized("l.pdf", 900, 400)])
    qtbot.waitUntil(lambda: all(not f.loading for f in state.files), timeout=5000)
    state.set_page_size("a4")
    state.set_output_path(str(tmp_path / "uniform.pdf"))
    with qtbot.waitSignal(state.mergeFinished, timeout=5000) as sig:
        state.request_merge()
    dims = [(round(float(p.mediabox.width)), round(float(p.mediabox.height)))
            for p in PdfReader(sig.args[0]).pages]
    assert dims == [(595, 842), (842, 595)]  # normalized to A4, orientation matched


def test_many_files_render_thumbnails_without_crashing(qtbot, pdfs):
    """Regression: pypdfium2 is not thread-safe; adding many files at once must
    not corrupt memory while thumbnails render on parallel workers."""
    state = AppState()
    state.add_paths([pdfs("f{}.pdf".format(i), 1 + i) for i in range(8)])
    qtbot.waitUntil(lambda: all(not f.loading for f in state.files), timeout=8000)
    assert [f.page_count for f in state.files] == [1, 2, 3, 4, 5, 6, 7, 8]


def test_encrypted_file_requests_password(qtbot, pdfs):
    state = AppState()
    locked = pdfs("locked.pdf", 2, password="secret")
    with qtbot.waitSignal(state.needPassword, timeout=5000) as sig:
        state.add_paths([locked])
    idx = sig.args[0]
    assert state.files[idx].is_encrypted and not state.files[idx].unlocked

    # supplying the password unlocks it (re-reads metadata on a worker)
    state.unlock(idx, "secret")
    qtbot.waitUntil(lambda: state.files[idx].unlocked, timeout=5000)
    assert state.files[idx].page_count == 2
